
const $ = id => document.getElementById(id);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const store = {
  get(k, d){ try { const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v){ try { localStorage.setItem(k, JSON.stringify(v)); } catch {} }
};
let S = { hday: "all", view: "home", compId: null, raw: [], rawHist: [], fixtures: [], history: [], hidden: new Set(store.get("hiddenHist", [])), leagues: [], lastSync: null, lastFinal: null, msg: null, loading: true, tab: "all", comp: "", day: "",
  tz: Intl.DateTimeFormat().resolvedOptions().timeZone,
  theme: store.get("theme", "auto"), drawer: false, search: false, q: "",
  na: { home: "", away: "", league: "" }, favs: store.get("favSearch", []), ext: null };

/* MODEL:BEGIN (gerado a partir de model.ts) */
const MODEL = (() => {
// Modelo estatístico "poisson-v2": puro, sem dependências, testável.
const MODEL_VERSION = "poisson-v2";
const MIN_MATCHES = 5;      // abaixo disto a análise continua a ser feita, mas marcada como de baixa fiabilidade
const SHRINK_K = 5;         // jogos "virtuais" da média da amostra (reduz extremos)
const HOME_ADV = 1.1;       // fator casa: λ_casa × 1.1, λ_fora ÷ 1.1
const HT_SHARE = 0.45;      // fração aproximada dos golos na 1.ª parte
const MIN10_SHARE = 0.10;   // fração aproximada dos golos nos primeiros 10 minutos
const MAXG = 10;
const fact = (n) => { let r = 1; for (let i = 2; i <= n; i++) r *= i; return r; };
const pois = (k, l) => Math.exp(-l) * Math.pow(l, k) / fact(k);
const clamp = (x, a, b) => Math.min(b, Math.max(a, x));
function grid(lh, la) {
  const g= []; let tot = 0;
  for (let i = 0; i <= MAXG; i++) { g[i] = []; for (let j = 0; j <= MAXG; j++) { g[i][j] = pois(i, lh) * pois(j, la); tot += g[i][j]; } }
  for (const row of g) for (let j = 0; j <= MAXG; j++) row[j] /= tot; // normaliza a truncagem
  return g;
}
function result1x2(g) {
  let h = 0, d = 0, a = 0;
  g.forEach((row, i) => row.forEach((p, j) => { if (i > j) h += p; else if (i === j) d += p; else a += p; }));
  return { home: h, draw: d, away: a };
}
function analyze(inp){
  const valid = (m) => Number.isFinite(m.gf) && Number.isFinite(m.ga) && m.gf >= 0 && m.ga >= 0;
  const dt = (m) => Date.parse(m.date ?? m.utcDate ?? m.kickoff_utc ?? "") || 0;
  const last5 = (ms) => (ms || []).filter(valid).map((m, i) => [m, i]).sort((x, y) => (dt(y[0]) - dt(x[0])) || (x[1] - y[1])).slice(0, 5).map(x => x[0]); // as 5 mais recentes
  const H = last5(inp.home), A = last5(inp.away), X = last5(inp.h2h); // X = confrontos diretos (gf = golos da equipa da casa de agora)
  const all = [...H, ...A];
  const mu = all.length ? Math.max(0.3, all.reduce((s, m) => s + m.gf, 0) / all.length) : 1.35; // média de golos por equipa/jogo na amostra
  const str = (ms) => {
    const n = ms.length, gf = ms.reduce((s, m) => s + m.gf, 0), ga = ms.reduce((s, m) => s + m.ga, 0);
    return { att: (gf + SHRINK_K * mu) / (n + SHRINK_K) / mu, def: (ga + SHRINK_K * mu) / (n + SHRINK_K) / mu };
  };
  const h = str(H), a = str(A);
  const ha = (H.length >= MIN_MATCHES && A.length >= MIN_MATCHES) ? HOME_ADV : 1; // com poucos jogos, só contam os dados reais (sem fator casa)
  let lh0 = mu * h.att * a.def * ha, la0 = mu * a.att * h.def / ha;
  if (X.length){ // confrontos diretos: peso até 30% (cresce com o número de jogos, máx. 5)
    const w = 0.3 * X.length / 5, xh = X.reduce((s, m) => s + m.gf, 0) / X.length, xa = X.reduce((s, m) => s + m.ga, 0) / X.length;
    lh0 = (1 - w) * lh0 + w * xh; la0 = (1 - w) * la0 + w * xa;
  }
  const lh = clamp(lh0, 0.2, 4.5);
  const la = clamp(la0, 0.2, 4.5);
  const g = grid(lh, la);
  const total = (k, over) => { let p = 0; g.forEach((r, i) => r.forEach((q, j) => { if ((i + j > k) === over) p += q; })); return p; };
  const totals= {};
  for (const k of [0.5, 1.5, 2.5, 3.5]) totals[`over_${String(k).replace(".", "_")}`] = total(k, true);
  for (const k of [1.5, 2.5, 3.5]) totals[`under_${String(k).replace(".", "_")}`] = total(k, false);
  let yes = 0; g.forEach((r, i) => r.forEach((q, j) => { if (i > 0 && j > 0) yes += q; }));
  const tg = (l) => { const p0 = pois(0, l), p1 = pois(1, l), p2 = pois(2, l); return { "0": p0, "1": p1, "2": p2, "3+": 1 - p0 - p1 - p2 }; };
  const scores= [];
  g.forEach((r, i) => r.forEach((q, j) => scores.push({ score: `${i}-${j}`, p: q })));
  scores.sort((x, y) => y.p - x.p);
  const none = g[0][0];
  // Parte mais produtiva: golos da 1.ª vs 2.ª parte (Poisson independentes, taxa total × fração da parte)
  const lt = lh + la, h1 = HT_SHARE, h2 = 1 - HT_SHARE;
  let pf = 0, pd = 0, ps = 0, ptot = 0;
  for (let i = 0; i <= MAXG; i++) for (let j = 0; j <= MAXG; j++) {
    const p = pois(i, lt * h1) * pois(j, lt * h2); ptot += p;
    if (i > j) pf += p; else if (i === j) pd += p; else ps += p;
  }
  // Uma equipa marca nas duas partes: P(≥1 na 1.ª) × P(≥1 na 2.ª)
  const both = (l) => { const y = (1 - Math.exp(-l * h1)) * (1 - Math.exp(-l * h2)); return { yes: y, no: 1 - y }; };
  // Alcance de golos: P(total ≥ n)
  const ge = (n) => { let p = 0; g.forEach((r, i) => r.forEach((q, j) => { if (i + j >= n) p += q; })); return p; };
  const nm = Math.min(H.length, A.length);
  return {
    ok: true, model: MODEL_VERSION, lambda: { home: lh, away: la },
    result: result1x2(g), totals, btts: { yes, no: 1 - yes },
    halftime: result1x2(grid(lh * HT_SHARE, la * HT_SHARE)),
    teamGoals: { home: tg(lh), away: tg(la) },
    exactScores: scores.slice(0, 5),
    productiveHalf: { first: pf / ptot, draw: pd / ptot, second: ps / ptot },
    bothHalves: { home: both(lh), away: both(la) },
    reach: { ge3: ge(3), ge4: ge(4), ge5: ge(5), ge6: ge(6) },
    min10: result1x2(grid(lh * MIN10_SHARE, la * MIN10_SHARE)),
    firstToScore: { home: (1 - none) * lh / (lh + la), away: (1 - none) * la / (lh + la), none },
    quality: { homeMatches: H.length, awayMatches: A.length, h2h: X.length, level: nm >= 10 ? "boa" : nm >= 7 ? "razoavel" : "baixa" },
  };
}
return { analyze, MODEL_VERSION };
})();
/* MODEL:END */

/* Fonte de dados para ligas FORA das 10 (ainda não ligada).
   Contrato: find({home, away, league, from, to}) -> { event:{id, home, away, league, kickoff_utc, time_confirmed}, homeHistory:[{gf,ga}], awayHistory:[{gf,ga}] }
   Em caso de erro lança Error com .code = "notfound" | "league" | "offline". */
const EXTRA_SOURCE = null;

/* ---------- Tema ---------- */
function applyTheme(){ const r = document.documentElement; if (S.theme === "auto") r.removeAttribute("data-theme"); else r.setAttribute("data-theme", S.theme); }
const isDark = () => S.theme === "dark" || (S.theme === "auto" && !!(window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches));
function setTheme(t){ S.theme = t; store.set("theme", t); applyTheme(); drawerHtml(); }

/* ---------- Dados ---------- */
/* ---------- Sem internet: ecrã escuro ---------- */
const offEl = document.createElement("div"); offEl.id = "off"; offEl.setAttribute("role", "alert"); offEl.textContent = "Conecte-se à internet.";
document.body.appendChild(offEl);
let offTimer = null;
function setOnline(ok){
  offEl.classList.toggle("on", !ok); clearInterval(offTimer);
  if (!ok) offTimer = setInterval(async () => { if (await fetchData()) render(); }, 3000);
}
window.addEventListener("offline", () => setOnline(false));
window.addEventListener("online", async () => { if (await fetchData()) render(); });
if (navigator.onLine === false) setOnline(false);
async function fetchData(){
  try {
    const d = DEMO_DATA;
    S.fetchedAt = Date.now(); S.raw = d.matches ?? []; S.rawHist = d.history ?? []; S.leagues = d.leagues ?? [];
    S.lastSync = d.lastSuccessAt ?? null; S.lastFinal = d.lastFinalAt ?? null;
    const bad = S.leagues.filter(l => !l.ok);
    S.msg = bad.length ? `Sem atualização recente em: ${bad.map(l => l.name).join(", ")}. Os jogos já guardados foram mantidos.` : null;
    if (offEl.classList.contains("on")) setOnline(true);
    return true;
  } catch (e) { if (!navigator.onLine || e instanceof TypeError) setOnline(false); S.msg = "Sem ligação ao servidor. O app precisa de internet para mostrar os jogos e as análises."; return false; }
}
async function load(){ S.loading = true; render(); await fetchData(); await fetchLive(); S.loading = false; render(); }

/* ---------- Formatação ---------- */
const STATUS = { NS:"Agendada", TBD:"Hora por confirmar", "1H":"Ao vivo", HT:"Ao vivo", "2H":"Ao vivo", ET:"Ao vivo", P:"Ao vivo", LIVE:"Ao vivo",
  FT:"Terminada", AWD:"Resultado atribuído", PST:"Adiada", CANC:"Cancelada", SUSP:"Suspensa" };
const isLive = s => ["1H","HT","2H","ET","P","LIVE"].includes(s);
const isDone = s => ["FT","AWD"].includes(s);
const LIVE_MAX = 110 * 60000; // 45+3 + intervalo 15 + 45+2 = 110 min: depois disto o jogo termina e passa ao histórico
// estado real do jogo: começa sozinho à hora marcada e termina sozinho, mesmo antes do servidor atualizar
function effStatus(f){
  const st = f.status, t = Date.parse(f.kickoff_utc), now = Date.now();
  if (!Number.isFinite(t)) return st;
  if (isLive(st)) return now - t > LIVE_MAX ? "FT" : st;
  if (st === "NS" && f.time_confirmed !== false && now >= t) return now - t < LIVE_MAX ? "LIVE" : "FT";
  return st;
}
/* Fonte em tempo real (opcional): endereço do live-worker.js (Cloudflare Worker). Sem endereço, usam-se só os dados do fixtures.json. */
const LIVE_URL = null;
S.liveMap = new Map(); S.liveKeys = new Map();
const lkey = (h, a, iso) => norm(h) + "|" + norm(a) + "|" + dayKey(iso);
async function fetchLive(){
  if (!LIVE_URL) return false;
  try {
    const r = await fetch(LIVE_URL, { cache: "no-store" }); if (!r.ok) return false;
    const d = await r.json(), at = Date.now(), byId = new Map(), byKey = new Map();
    for (const x of d.matches ?? []){ const o = { ...x, at }; byId.set(String(x.id), o); if (x.home && x.away && x.kickoff) byKey.set(lkey(x.home, x.away, x.kickoff), o); }
    S.liveMap = byId; S.liveKeys = byKey; return true;
  } catch { return false; }
}
const liveOf = f => S.liveMap.get(String(f.id)) || S.liveMap.get(String(f.id).replace(/\D/g, "")) || S.liveKeys.get(lkey(f.home_team, f.away_team, f.kickoff_utc));
// minuto REAL (vindo do servidor). Nunca se calcula a partir da hora do jogo: sem dado fresco, não mostra minuto.
function liveMinute(f){
  if (f.status === "HT") return "Intervalo";
  const m = Number(f.minute), at = f._at || Date.parse(S.lastSync) || 0, age = Math.floor((Date.now() - at) / 60000);
  if (Number.isFinite(m) && m > 0 && at && age <= 3){ // minuto REAL da fonte de dados
    const mm = m + Math.max(0, age);
    if (f.status === "1H" && mm > 45) return "45+'";
    if (mm > 90 && f.status !== "ET") return "90+'";
    return mm + "'";
  }
  // sem minuto real: relógio aproximado a partir do apito inicial (marcado com ~), com intervalo de 15 min
  const e = Math.floor((Date.now() - Date.parse(f.kickoff_utc)) / 60000);
  if (!(e >= 0)) return "";
  if (e < 46) return "~" + Math.max(1, e + 1) + "'";
  if (e < 48) return "~45+'";
  if (e < 63) return "Intervalo";
  const t = 46 + (e - 63);
  return t > 90 ? "~90+'" : "~" + t + "'";
}
const EYE = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1.5 12S5.5 5 12 5s10.5 7 10.5 7-4 7-10.5 7S1.5 12 1.5 12z"/><circle cx="12" cy="12" r="3"/></svg>';
const EYE_OFF = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1.5 12S5.5 5 12 5s10.5 7 10.5 7-4 7-10.5 7S1.5 12 1.5 12z"/><circle cx="12" cy="12" r="3"/><path d="M3 3l18 18"/></svg>';
const eyeWrap = h => `<div class="pwbox">${h}<button type="button" class="eye" data-s="eye" aria-label="Mostrar palavra-passe">${EYE}</button></div>`;
const withEff = f => {
  const lv = liveOf(f);
  const b = lv ? { ...f, status: lv.status || f.status, home_goals: lv.home_goals ?? f.home_goals, away_goals: lv.away_goals ?? f.away_goals,
    home_ht: lv.home_ht ?? f.home_ht, away_ht: lv.away_ht ?? f.away_ht, minute: lv.minute ?? null, _at: lv.at } : f;
  const st = effStatus(b); return st === b.status ? b : { ...b, status: st, _est: true };
};
const fmtDay = iso => new Intl.DateTimeFormat("pt", { timeZone: S.tz, weekday:"long", day:"numeric", month:"long" }).format(new Date(iso));
const fmtHour = iso => new Intl.DateTimeFormat("pt", { timeZone: S.tz, hour:"2-digit", minute:"2-digit" }).format(new Date(iso));
const fmtFull = iso => new Intl.DateTimeFormat("pt", { timeZone: S.tz, dateStyle:"short", timeStyle:"short" }).format(new Date(iso));
const dayKey = iso => new Intl.DateTimeFormat("en-CA", { timeZone: S.tz }).format(new Date(iso));
const ORDER = ["CL","PL","PD","ELC","BL1","SA","DED","PPL","BSA","FL1"];
const LABEL = { CL:["Clubes internacionais","Liga dos campeões UEFA"], PL:["Inglaterra","Premier League"], PD:["Espanha","La Liga"],
  ELC:["Inglaterra 2","Championship"], BL1:["Alemanha","Bundesliga"], SA:["Itália","Série A"], DED:["Países Baixos","Eredivisie"],
  PPL:["Portugal","Primeira Liga"], BSA:["Brasil","Brasileirão Série A"], FL1:["França","Ligue 1"] };
const labelById = (id, name, country) => LABEL[id] ?? [country || "", name || id];
const countOf = id => S.fixtures.filter(f => f.competition_id === id).length;
const norm = s => String(s ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();

/* ---------- Componentes ---------- */
const ICON = {
  menu: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M3 6h18M3 12h18M3 18h18"/></svg>',
  search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><circle cx="10.5" cy="10.5" r="6.5"/><path d="M15.5 15.5L21 21"/></svg>',
  home: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/></svg>',
  live: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="12" cy="12" r="2.6" fill="currentColor"/><path d="M7.5 7.5a6.4 6.4 0 0 0 0 9M16.5 7.5a6.4 6.4 0 0 1 0 9M4.5 4.5a10.6 10.6 0 0 0 0 15M19.5 4.5a10.6 10.6 0 0 1 0 15"/></svg>',
  cal: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/><circle cx="8" cy="14" r=".8" fill="currentColor"/><circle cx="12" cy="14" r=".8" fill="currentColor"/><circle cx="16" cy="14" r=".8" fill="currentColor"/></svg>',
  star: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.5l2.9 6.1 6.6.9-4.8 4.6 1.2 6.6L12 17.5 6.1 20.7l1.2-6.6L2.5 9.5l6.6-.9z"/></svg>',
  tips: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.7.6 1 1.3 1 2.1h5c0-.8.3-1.5 1-2.1A6 6 0 0 0 12 3z"/></svg>',
  warn: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3.5L2.8 19.5h18.4z"/><path d="M12 10v4.5M12 17.4v.1"/></svg>',
  hist: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3.5 12a8.5 8.5 0 1 0 2.6-6.1L3.5 8.5M3.5 4v4.5H8"/><path d="M12 7.5V12l3 2"/></svg>'
};
function header(){
  return `<header class="top"><button class="ib" data-act="drawer" aria-label="Definições">${ICON.menu}</button>
    <div class="brand"><span class="mark" aria-hidden="true">🦁</span><span>Elephalpit <em>Bet</em></span></div>
    <div style="width:40px" aria-hidden="true"></div></header>`;
}
function nav(){
  const it = [["home","Home",ICON.home],["aviso","Aviso",ICON.warn],["cal","Calendário",ICON.cal],["fav","Favoritos",ICON.star],["hist","Histórico",ICON.hist]];
  return `<nav class="bot">${it.map(([k,l,i]) => `<button data-nav="${k}" ${S.view === k || (k === "home" && S.view === "comp") ? 'aria-current="page"' : ""}>${i}<span>${l}</span></button>`).join("")}</nav>`;
}
/* ---------- Ajuda e assistente ---------- */
const ASSISTANT_URL = null; // endereço do assistant-worker.js (assistente com IA real). null = assistente integrado
S.tips = { msgs: [], busy: false };
const upcoming = () => S.fixtures.filter(f => f.analysis && ["NS", "TBD"].includes(f.status) && !vipLocked(f));
function topPick(f){
  const secs = sections(f.analysis.result, { h: f.home_team, a: f.away_team }); let best = null;
  for (const sec of secs) for (const g of sec.groups){ const n = ints(sec, g); g.forEach((x, i) => { if (x.pick && x.v !== "Não" && !sec.noTop && x.l !== "Mais de 0,5" && (!best || x.p > best.x.p)) best = { x, n: n[i], sec }; }); }
  return best;
}
function gameSummary(f){
  const secs = sections(f.analysis.result, { h: f.home_team, a: f.away_team }), line = t => { const sec = secs.find(x => x.title === t); if (!sec) return ""; const g = sec.groups[0], n = ints(sec, g); return g.map((x, i) => `${x.l}${x.v ? " " + x.v : ""} ${n[i]}%`).join("; "); };
  return `${f.home_team} vs ${f.away_team} (${fmtDay(f.kickoff_utc)}, ${fmtHour(f.kickoff_utc)})\n• 1X2: ${line("Resultado final")}\n• Ambas marcam: ${line("Ambas as equipas marcam")}\n• Golos: ${line("Total de golos").split("; ").filter(x => !x.startsWith("Mais de 0,5")).slice(0, 5).join("; ")}`;
}
const GEN = new Set(["united", "city", "real", "club", "football", "futbol", "town", "sporting", "athletic", "atletico", "sport"]);
function assistLocal(q){
  const n = norm(q), words = n.split(/[^a-z0-9]+/).filter(Boolean);
  const has = (...k) => k.some(x => n.includes(x));
  const hit = f => [f.home_team, f.away_team].some(t => norm(t).split(/[^a-z0-9]+/).some(w => w.length >= 4 && !GEN.has(w) && words.includes(w)));
  const games = [...S.fixtures, ...S.history].filter(f => f.analysis && hit(f) && !vipLocked(f)).slice(0, 3);
  if (games.length) return games.map(gameSummary).join("\n\n") + "\n\nSão estimativas estatísticas, não garantias. Para ver tudo, abre o jogo e carrega em “Analisar com IA”.";
  if (has("melhor", "segura", "mais provavel", "top") || (has("hoje") && has("jogo", "aposta", "previs", "dica"))){
    const l = upcoming().map(f => ({ f, b: topPick(f) })).filter(x => x.b).sort((a, b) => b.b.x.p - a.b.x.p).slice(0, 5);
    if (l.length) return "As previsões mais prováveis dos próximos jogos:\n" + l.map(({ f, b }) => `• ${f.home_team} vs ${f.away_team}: ${b.x.l}${b.x.v ? " " + b.x.v : ""} ${b.n}%`).join("\n") + "\n\nNenhuma previsão é garantida. Aposta só o que podes perder.";
    return "Ainda não há análises dos próximos jogos. Volta daqui a pouco.";
  }
  if (has("empata/vence", "vence/empata", "empate/vence", "talvez", "qualquer vence", "nao vence")) return "• “Qualquer vence”: as equipas estão muito parecidas (menos de 5% de diferença). A percentagem é a chance de não haver empate.\n• “Vence/Empata” (equipa da casa) e “Empate/Vence” (equipa de fora): jogo equilibrado (5% a 10% de diferença). A favorita ganha ou empata.\n• “Talvez Sim” aparece só no Empate, quando é mais provável do que a vitória da equipa em desvantagem.\n• “Não vence” é a equipa em desvantagem.";
  if (has("circulo", "verde", "vermelho", "bolinha", "cinzento")) return "Depois do jogo acabar, cada linha mostra um círculo: verde = a previsão estava certa, vermelho = errada, cinzento = sem dados para avaliar (por exemplo, um mercado que só vale se a equipa ganhar e ela não ganhou).";
  if (has("percent", "%", "barra") || (has("sim") && has("nao"))) return "Cada linha tem Sim/Não (ou Vence/Empata…) e uma percentagem. A percentagem é a chance estimada de aquilo acontecer. “Não 25%” quer dizer que há 25% de chance de acontecer e, por isso, o modelo não o escolhe. Nos mercados que não podem acontecer ao mesmo tempo (1X2, intervalo) somam 100%.";
  if (has("analisar", "como uso", "como usar", "como vejo", "passo", "como funciona o app", "como faco")) return "Para ver uma análise: 1) abre Home ou Calendário e escolhe o jogo; 2) carrega em “Analisar com IA”; 3) no topo vês a hora do apito, quanto falta e os últimos jogos das equipas; 4) mais abaixo estão as probabilidades de resultado, golos, ambas marcam, intervalo e outras. Também podes pesquisar um jogo na lupa.";
  if (has("modelo", "poisson", "como calcula", "calculo", "como sao feitas", "fiab", "confi", "precis", "como funciona")) return "As análises usam um modelo estatístico (Poisson): olha para os golos marcados e sofridos nos últimos 5 jogos de cada equipa e nos confrontos diretos, estima quantos golos cada equipa deve marcar e daí tira as probabilidades de resultado, golos, ambas marcam, etc. É uma estimativa, não uma garantia: o futebol tem muita surpresa.";
  if (has("calendario", "liga", "selecionar")) return "No Calendário vês os próximos 30 dias. Em “Selecionar ligas” escolhes até 3 das 10 ligas. O dia que passa sai e entra um novo automaticamente.";
  if (has("limpar historico", "apagar historico")) return "No separador Histórico há o botão “Limpar histórico”, que apaga todos os jogos terminados da lista. Também podes apagar um só jogo no ✕ do cartão.";
  if (has("historico")) return "O Histórico guarda os jogos terminados, com o resultado e os círculos verde/vermelho a mostrar se a previsão acertou. Os jogos passam para lá assim que terminam e ficam guardados no teu aparelho.";
  if (has("ultimos jogos", "confronto", "h2h", "forma")) return "No topo da análise aparecem os últimos 5 jogos de cada equipa (V = vitória, E = empate, D = derrota) e os 2 últimos confrontos entre elas.";
  if (has("conta", "senha", "palavra-passe", "palavra passe", "recuper", "login", "entrar", "ban")) return "Para entrar usas e-mail (ou nome) e palavra-passe. Se te esqueceste, “Esqueci a palavra-passe” envia um código de 6 dígitos ao e-mail. Se a tua conta foi banida, só podes voltar a entrar quando o tempo do ban acabar.";
  if (has("banca", "quanto apostar", "gestao", "stake")) return "Gestão de banca: define um valor total só para apostar (que possas perder) e aposta uma parte pequena em cada jogo, por exemplo 1% a 2%. Não aumentes o valor para recuperar perdas.";
  if (has("garant", "certeza", "ganhar sempre", "vou ganhar")) return "Não existe garantia. Mesmo uma previsão de 80% falha 1 vez em cada 5. Usa as análises como ajuda, nunca como certeza, e aposta só o que podes perder.";
  if (has("apostar", "aposta", "dica")) return "Dicas para seguir as previsões: procura percentagens altas (a partir de 65%), desconfia de jogos equilibrados, escolhe poucos jogos, confirma as equipas e os desfalques perto do apito e consulta o Histórico para ver onde o modelo acerta mais. Aposta só o que podes perder e só se tiveres 18 anos ou mais.";
  if (has("ola", "bom dia", "boa tarde", "boa noite", "oi", "ajuda", "o que podes")) return "Olá! Posso explicar o app, as palavras das análises, como ler as percentagens, e mostrar a análise de um jogo se escreveres o nome de uma equipa.";
  return "Não tenho a certeza de ter percebido. Podes perguntar, por exemplo: “melhores previsões de hoje”, “o que é Talvez Sim?”, “como é calculada a análise?”, “como recupero a conta?” ou escrever o nome de uma equipa para ver a análise.";
}
const assistCtx = () => upcoming().slice(0, 12).map(gameSummary).join("\n\n");
const wait = ms => new Promise(r => setTimeout(r, ms));
async function askAssistant(text){
  const q = String(text || "").trim(); if (!q || S.tips.busy) return;
  S.tips.msgs.push({ r: "me", t: q.slice(0, 500) }); S.tips.busy = true; render(); helpScroll();
  const t0 = Date.now(); let reply = "";
  if (ASSISTANT_URL){
    try {
      const r = await fetch(ASSISTANT_URL, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ messages: S.tips.msgs.slice(-10).map(m => ({ role: m.r === "me" ? "user" : "assistant", content: m.t })), context: assistCtx() }) });
      if (r.ok){ const d = await r.json(); reply = String(d.reply || ""); }
    } catch {}
  }
  if (!reply) reply = assistLocal(q);
  await wait(Math.max(0, 1300 + Math.min(1800, reply.length * 6) - (Date.now() - t0))); // o assistente "pensa" antes de responder
  const m = { r: "bot", t: "" }; S.tips.msgs.push(m); S.tips.busy = false; render();
  const toks = reply.split(/(\s+)/); // escreve palavra a palavra
  for (let i = 0; i < toks.length; i++){
    m.t += toks[i];
    if (i % 2 === 0 || i === toks.length - 1){
      const el = $("lastbub"); if (!el) break; el.innerHTML = esc(m.t).replace(/\n/g, "<br>"); helpScroll(true); await wait(45);
    }
  }
  m.t = reply; helpScroll();
}
function helpScroll(keep){ const c = $("chat"); if (c) c.scrollTop = c.scrollHeight; const i = $("tq"); if (i && !keep && i.focus) i.focus(); }
function helpView(){
  const ms = S.tips.msgs, last = ms.length - 1;
  const body = ms.length ? ms.map((m, i) => `<div class="bub ${m.r === "me" ? "me" : ""}" ${i === last && m.r === "bot" ? 'id="lastbub"' : ""}>${esc(m.t).replace(/\n/g, "<br>")}</div>`).join("") + (S.tips.busy ? `<div class="bub dots"><span></span><span></span><span></span></div>` : "") : `<div class="hq">Em que posso ajudar?</div>`;
  const chips = ms.length ? "" : `<div class="chips">${["Melhores previsões de hoje", "O que é Talvez Sim?", "Como é calculada a análise?", "Como analisar um jogo?"].map(c => `<button type="button" data-s="tipq" data-q="${esc(c)}">${esc(c)}</button>`).join("")}</div>`;
  return `<div class="help"><button class="hb" data-act="back" aria-label="Voltar">←</button><div class="hm" id="chat" aria-live="polite">${body}</div>${chips}
    <form novalidate data-sf="ask" class="hbar"><span class="hp" aria-hidden="true">+</span><input id="tq" name="tq" type="text" maxlength="300" placeholder="Pergunta ao assistente" autocomplete="off" aria-label="Pergunta ao assistente"><button aria-label="Enviar">➤</button></form></div>`;
}
const tipsView = helpView;
function matchCard(f, mode){
  const logo = u => u ? `<img src="${esc(u)}" alt="" loading="lazy" referrerpolicy="no-referrer">` : "";
  const done = isDone(f.status);
  const has = f.home_goals != null && f.away_goals != null && isDone(f.status);
  const score = has ? `${f.home_goals} - ${f.away_goals}` : (done ? "– –" : "vs");
  const top = f.time_confirmed ? `${dayKey(f.kickoff_utc)} ${fmtHour(f.kickoff_utc)}` : `${dayKey(f.kickoff_utc)} · hora por confirmar`;
  let action;
  const gated = S.view !== "vip" && S.view !== "svip" && !!vipPick(f) && !(mode === "hist" && done && vipLost(f)); // jogo do VIP fora das áreas VIP: só diz "VIP", sem mostrar nada
  if (gated) action = `<button class="btn" style="background:#b8860b;color:#fff" data-an="${esc(f.id)}">VIP</button>`;
  else if (done && mode === "hist" && vipPick(f) && vipLost(f) && S.view !== "vip" && S.view !== "svip") action = `<button class="btn amber" data-an="${esc(f.id)}">Analisar com IA</button>`;
  else if (done) action = `<button class="btn" data-an="${esc(f.id)}">Ver estatísticas</button>`;
  else action = `<button class="btn amber" data-an="${esc(f.id)}" ${["NS","TBD"].includes(f.status) || isLive(f.status) ? "" : "disabled"}>Analisar com IA</button>`;
  let mk = ""; // histórico normal: ✓ ou ✗ por baixo do placar (a escolha do modelo no "Resultado final" acertou?)
  if (mode === "hist" && has && f.analysis && (!vipPick(f) || vipOpen(f) || vipLost(f))){
    try { const fin = finalOf(f), sec = sections(f.analysis.result, { h: f.home_team, a: f.away_team })[0], ok = sec && fin ? groupHit(sec.groups[0], fin) : null;
      if (ok !== null) mk = `<div class="mk" style="color:var(${ok ? "--ok" : "--bad"})" aria-label="${ok ? "Acertou" : "Falhou"}">${ok ? "✓" : "✗"}</div>`; } catch (e) {}
  }
  const del = mode === "hist" ? `<button class="x" data-del="${esc(f.id)}" aria-label="Remover este jogo do histórico">✕</button>` : "";
  return `<article class="match">${del}<div class="dt">${esc(top)}</div><div class="teams">
    <div class="t">${logo(f.home_logo)}<span>${esc(f.home_team)}</span></div><div class="vsw"><div class="vs">${esc(score)}</div>${mk}</div>
    <div class="t r"><span>${esc(f.away_team)}</span>${logo(f.away_logo)}</div></div>
    <div class="meta"><span><span class="st ${isLive(f.status) ? "live" : ""}">${esc(STATUS[f.status] ?? f.status)}</span></span>
    <span class="row">${favStar(f)}${action}</span></div></article>`;
}
function grouped(list, mode){
  let h = "", ld = "", lc = "";
  for (const f of list){
    const d = dayKey(f.kickoff_utc), c = f.competitions?.name ?? "Outros";
    if (d !== ld){ h += `<h2 class="day">${esc(fmtDay(f.kickoff_utc))}</h2>`; ld = d; lc = ""; }
    if (c !== lc){ h += `<div class="cn">${esc(c)}${f.competitions?.country ? " · " + esc(f.competitions.country) : ""}</div>`; lc = c; }
    h += matchCard(f, mode);
  }
  return h;
}
const updLine = () => "";
const msgHtml = () => S.msg ? `<div class="msg" role="alert">${esc(S.msg)}</div>` : "";

/* ---------- Vistas ---------- */
function homeView(){
  const ids = [...ORDER, ...S.leagues.map(l => l.id).filter(id => !ORDER.includes(id))];
  const cards = ids.map(id => {
    const l = S.leagues.find(x => x.id === id) ?? {};
    const [a, b] = labelById(id, l.name, l.country), n = countOf(id);
    const num = S.loading && !S.leagues.length ? "…" : n;
    return `<button class="comp" data-comp="${esc(id)}"><span class="ball" aria-hidden="true">⚽</span>
      <span class="ct"><b>${esc(a)}</b><i><span aria-hidden="true">🌍</span>${esc(b)}</i></span><span class="cnt"><b>${num}</b> ${n === 1 ? "jogo" : "jogos"}</span></button>`;
  }).join("");
  return `<h1 class="ttl">Melhores Competições</h1>${updLine()}${msgHtml()}${cards}`;
}
function compView(){
  const l = S.leagues.find(x => x.id === S.compId) ?? {};
  const list = S.fixtures.filter(f => f.competition_id === S.compId);
  const name = labelById(S.compId, l.name ?? list[0]?.competitions?.name, l.country)[1];
  return `${backBar()}<h1 class="ttl">${esc(name)}</h1>
    ${list.length ? grouped(list) : `<div class="empty">Sem jogos desta competição nos próximos dias.</div>`}`;
}
S.sel = []; S.lg = false; // as ligas escolhidas só duram enquanto o app está aberto
const leagueSel = f => !S.sel.length || S.sel.includes(f.competition_id);
function dayList(){
  const out = [];
  for (let i = 0; i < 30; i++){ // hoje + 29 dias; o dia que passa sai e entra um novo
    const d = new Date(Date.now() + i * 86400e3), iso = d.toISOString();
    const wd = new Intl.DateTimeFormat("pt", { timeZone: S.tz, weekday: "short" }).format(d).replace(".", "");
    const dn = new Intl.DateTimeFormat("pt", { timeZone: S.tz, day: "numeric" }).format(d);
    const mo = (i === 0 || dn === "1") ? new Intl.DateTimeFormat("pt", { timeZone: S.tz, month: "short" }).format(d).replace(".", "") : "";
    out.push({ key: dayKey(iso), wd: wd.charAt(0).toUpperCase() + wd.slice(1), dn, mo });
  }
  return out;
}
function byComp(list){
  let h = "", lc = "";
  for (const f of list){
    const c = f.competitions?.name ?? "Outros";
    if (c !== lc){ h += `<div class="cn">${esc(c)}${f.competitions?.country ? " · " + esc(f.competitions.country) : ""}</div>`; lc = c; }
    h += matchCard(f);
  }
  return h;
}
function calView(){
  const days = dayList().slice(0, 7); // 7 dias; a cada dia sai um e entra outro
  if (!days.some(d => d.key === S.day)) S.day = days[0].key;
  const count = new Map(); S.fixtures.filter(leagueSel).forEach(f => { const k = dayKey(f.kickoff_utc); count.set(k, (count.get(k) || 0) + 1); });
  const strip = days.map(d => `<button class="dy" data-day="${esc(d.key)}" aria-pressed="${S.day === d.key}"><span>${esc(d.wd)}</span><b>${esc(d.dn)}</b><em class="mo">${esc(d.mo)}</em><i class="${count.get(d.key) ? "has" : ""}"></i></button>`).join("");
  let list = S.fixtures.filter(f => dayKey(f.kickoff_utc) === S.day && leagueSel(f));
  list.sort((a, b) => (a.competitions?.name ?? "").localeCompare(b.competitions?.name ?? "") || a.kickoff_utc.localeCompare(b.kickoff_utc));
  const names = S.sel.map(id => labelById(id, S.leagues.find(l => l.id === id)?.name, "")[1]).join(" · ");
  const pick = `<div class="row" style="margin:0 0 10px;justify-content:space-between"><span class="note" style="margin:0">${esc(names)}</span><button class="btn alt" data-act="leagues">Selecionar ligas${S.sel.length ? ` (${S.sel.length}/3)` : ""}</button></div>`;
  return `<div class="stripw"><div class="strip" id="strip">${strip}</div>${days.length > 6 ? `<button class="nx" data-act="next" aria-label="Mais dias">→</button>` : ""}</div>
    ${pick}${msgHtml()}` +
    (S.loading ? `<div class="empty">A carregar…</div>` : list.length ? byComp(list) : `<div class="empty">${S.sel.length ? "Sem jogos das ligas selecionadas neste dia." : "Sem jogos neste dia nas competições importadas."}</div>`);
}
function leaguesHtml(){
  if (!S.lg) return;
  const keep = document.querySelector("#ov .sp"), top = keep ? keep.scrollTop : 0, full = S.sel.length >= 3;
  const items = ORDER.map(id => {
    const on = S.sel.includes(id), l = S.leagues.find(x => x.id === id) ?? {}, [c, n] = labelById(id, l.name, l.country);
    return `<button class="lgb" data-act="lgtoggle" data-id="${esc(id)}" aria-pressed="${on}" ${!on && full ? 'aria-disabled="true" style="opacity:.55"' : ""}><span class="ck" aria-hidden="true">${on ? "✓" : ""}</span><span class="ct"><b>${esc(n)}</b><span class="note" style="margin:0">${esc(c)}</span></span></button>`;
  }).join("");
  $("ov").innerHTML = `<div class="ov"><div class="sp lgsp">
    <div class="row" style="justify-content:space-between;margin-bottom:4px"><b style="font-size:15px">Selecionar ligas</b><button class="btn alt" style="padding:4px 10px;font-size:13px" data-act="close">Concluir</button></div>
    <p class="note" style="font-size:12px;margin:2px 0 6px">${full ? "Já escolheste 3 ligas. Tira uma para escolher outra." : "Escolhe até 3 ligas. Sem nenhuma escolhida, o calendário mostra todas."}</p>${items}
    <button class="btn alt" style="width:100%;margin-top:6px;padding:6px;font-size:13px" data-act="lgclear">Limpar seleção</button></div></div>`;
  const sp = document.querySelector("#ov .sp"); if (sp) sp.scrollTop = top;
}
function finalOf(f){
  if (!(Number.isFinite(f.home_goals) && Number.isFinite(f.away_goals))) return null;
  const zero = f.home_goals + f.away_goals === 0; // acabou 0-0: ao intervalo também foi 0-0
  return { h: f.home_goals, a: f.away_goals, hh: f.home_ht ?? (zero ? 0 : null), ah: f.away_ht ?? (zero ? 0 : null) };
}
function histList(){ return S.history; }
const createdKey = u => dayKey(new Date((u && u.created) || 0).toISOString());
function histOk(f){ // true = acertou, false = falhou, null = sem análise ou jogo do VIP (igual ao ✓/✗ do cartão)
  if (!(f.home_goals != null && f.away_goals != null && isDone(f.status) && f.analysis && (!vipPick(f) || vipOpen(f) || vipLost(f)))) return null;
  try { const fin = finalOf(f), sec = sections(f.analysis.result, { h: f.home_team, a: f.away_team })[0]; return sec && fin ? groupHit(sec.groups[0], fin) : null; } catch (e) { return null; }
}
function histStat(arr){ let w = 0, l = 0; arr.forEach(f => { const o = histOk(f); if (o === true) w++; else if (o === false) l++; }); const n = w + l; return { w, l, n, pw: n ? Math.round(w / n * 100) : 0, pl: n ? 100 - Math.round(w / n * 100) : 0 }; }
function taxaView(){
  const all = S.history.map(f => ({ f, o: histOk(f) })).filter(x => x.o !== null), tot = all.length, w = all.filter(x => x.o).length;
  const pct = (a, b) => b ? Math.round(a / b * 100) : 0, bar = (p, c) => `<span class="trk"><span style="width:${p}%;background:${c}"></span></span>`;
  const g = new Map(); all.forEach(x => { const k = x.f.competitions?.name ?? "Outros"; const e = g.get(k) || { w: 0, n: 0 }; e.n++; if (x.o) e.w++; g.set(k, e); });
  const lg = [...g.entries()].sort((a, b) => b[1].n - a[1].n).map(([k, e]) => `<div class="rp"><span>${esc(k)}<br><small style="color:var(--mute)">${e.w} de ${e.n}</small></span>${bar(pct(e.w, e.n), "var(--ok)")}<strong>${pct(e.w, e.n)}%</strong></div>`).join("");
  const days = []; for (let i = 6; i >= 0; i--){ const d = new Date(Date.now() - i * 86400e3), k = dayKey(d.toISOString()), xs = all.filter(x => dayKey(x.f.kickoff_utc) === k);
    days.push({ wd: new Intl.DateTimeFormat("pt", { timeZone: S.tz, weekday: "short" }).format(d).replace(".", ""), n: xs.length, p: pct(xs.filter(x => x.o).length, xs.length) }); }
  const cols = days.map(d => `<div style="flex:1;text-align:center;font-size:11px;color:var(--mute)"><div style="height:80px;display:flex;align-items:flex-end;justify-content:center"><div style="width:70%;height:${d.n ? Math.max(d.p, 6) : 2}%;background:${d.n ? (d.p >= 50 ? "var(--ok)" : "var(--bad)") : "var(--line)"};border-radius:4px 4px 0 0"></div></div><b style="color:var(--ink)">${d.n ? d.p + "%" : "–"}</b><br>${esc(d.wd)}</div>`).join("");
  return `${backBar()}<h1 class="ttl">Taxa de acerto</h1><p class="sub">Quantas vezes o "Resultado final" da análise acertou nos jogos já terminados.</p>` + (tot
    ? `<div class="row" style="gap:8px;margin:0 0 12px"><div style="flex:1;text-align:center;border:1px solid var(--ok);color:var(--ok);border-radius:10px;padding:12px 4px;font-weight:800;font-size:22px">${pct(w, tot)}%<div style="font-size:11px;font-weight:600">acertos · ${w} de ${tot}</div></div></div>
      <div class="sec">Últimos 7 dias</div><div style="display:flex;gap:4px;margin:8px 0 14px">${cols}</div><div class="sec">Por liga</div>${lg}`
    : `<div class="empty">Ainda não há jogos terminados com análise para calcular.</div>`);
}
function histView(){
  const ck = createdKey(cur()), list = histList().filter(f => dayKey(f.kickoff_utc) >= ck); // só jogos a partir do dia em que a conta foi criada
  const top = "";
  const days = []; // calendário dos últimos 7 dias (hoje e os 6 anteriores)
  for (let i = 0; i < 7; i++){
    const d = new Date(Date.now() - i * 86400e3), dn = new Intl.DateTimeFormat("pt", { timeZone: S.tz, day: "numeric" }).format(d);
    const wd = new Intl.DateTimeFormat("pt", { timeZone: S.tz, weekday: "short" }).format(d).replace(".", "");
    const mo = (i === 0 || dn === "1") ? new Intl.DateTimeFormat("pt", { timeZone: S.tz, month: "short" }).format(d).replace(".", "") : "";
    days.unshift({ key: dayKey(d.toISOString()), wd: wd.charAt(0).toUpperCase() + wd.slice(1), dn, mo }); // hoje fica à direita, os dias passados à esquerda
  }
  setTimeout(() => { const n = $("hstrip"); if (n) n.scrollLeft = n.scrollWidth; }, 0);
  if (!days.some(d => d.key === S.hday)) S.hday = ([...days].reverse().find(d => list.some(f => dayKey(f.kickoff_utc) === d.key)) || days[days.length - 1]).key; // abre no dia mais recente com jogos
  const cnt = new Map(); list.forEach(f => { const k = dayKey(f.kickoff_utc); cnt.set(k, (cnt.get(k) || 0) + 1); });
  const strip = days.map(d => `<button class="dy" data-hday="${esc(d.key)}" aria-pressed="${S.hday === d.key}"><span>${esc(d.wd)}</span><b>${esc(d.dn)}</b><em class="mo">${esc(d.mo)}</em><i class="${cnt.get(d.key) ? "has" : ""}"></i></button>`).join("");
  const shown = list.filter(f => dayKey(f.kickoff_utc) === S.hday);
  const st = histStat(shown), sum = st.n ? `<div class="row" style="gap:8px;margin:0 0 10px"><div style="flex:1;text-align:center;border:1px solid var(--ok);color:var(--ok);border-radius:10px;padding:8px 4px;font-weight:800">Ganhos ${st.pw}%<div style="font-size:11px;font-weight:600">${st.w} ${st.w === 1 ? "jogo" : "jogos"}</div></div><div style="flex:1;text-align:center;border:1px solid var(--bad);color:var(--bad);border-radius:10px;padding:8px 4px;font-weight:800">Perdidos ${st.pl}%<div style="font-size:11px;font-weight:600">${st.l} ${st.l === 1 ? "jogo" : "jogos"}</div></div></div>` : "";
  return `<h1 class="ttl">Histórico</h1><button class="btn alt" data-nav="taxa" style="width:100%;margin:0 0 8px">📈 Taxa de acerto</button><div class="stripw"><div class="strip" id="hstrip">${strip}</div></div>${sum}${top}${updLine()}${msgHtml()}` + (shown.length ? grouped(shown, "hist")
    : `<div class="empty">${list.length ? "Sem jogos terminados neste dia." : "Ainda não há jogos terminados. Os jogos passam para aqui assim que terminam."}</div>`);
}
const favG = id => S.favs.some(x => x.id === "g:" + id);
const favStar = f => isDone(f.status) ? "" : `<button type="button" class="fv" data-favgame="${esc(f.id)}" aria-label="${favG(f.id) ? "Remover dos favoritos" : "Adicionar aos favoritos"}" aria-pressed="${favG(f.id)}">${favG(f.id) ? "★" : "☆"}</button>`;
function favCard(f){
  const top = `${dayKey(f.kickoff_utc)} ${fmtHour(f.kickoff_utc)}`;
  return `<article class="match"><button class="x" style="color:var(--amber);font-size:22px" data-favdel="${esc(f.id)}" aria-label="Remover dos favoritos">★</button><div class="dt">${esc(top)}</div>
    <div class="cn" style="margin:0 0 6px">${esc(f.league)}</div>
    <div class="teams"><div class="t"><span>${esc(f.home_team)}</span></div><div class="vs">vs</div><div class="t r"><span>${esc(f.away_team)}</span></div></div>
    <div class="meta"><span class="st">Favorito</span><button class="btn amber" data-favopen="${esc(f.id)}">Ver análise</button></div></article>`;
}
function favView(){
  const list = S.favs.slice().sort((a, b) => a.kickoff_utc.localeCompare(b.kickoff_utc));
  return `<h1 class="ttl">Favoritos</h1><p class="sub">Jogos que guardaste com a estrela ☆ ou analisaste na lupa.</p>` +
    (list.length ? list.map(favCard).join("") : `<div class="empty">Ainda não tens favoritos. Toca na estrela ☆ de qualquer jogo para o guardar aqui.</div>`);
}
const VIP_MIN = 0.5, SUP_MIN = 0.6, SUP_ROWS = 70; // VIP: vitória 50%+; Super VIP: vitória 60%+ e só mostra linhas de 70%+
const AVISOS = ["ESSAS ANÁLISES SÃO APENAS ESTIMATIVAS NÃO GARANTIAS DE VITÓRIA, CADA JOGO É UM JOGO.",
  "APOSTE APENAS O QUE PODES PERDER E COM RESPONSABILIDADES.",
  "NÃO USE TODAS AS PROBABILIDADES USE A QUE ACHARES MELHOR.",
  "PARA MAIS SEGURANÇA USE GANHA OU EMPATA.",
  "APOSTAS SÓ PARA MAIORES DE 18 ANOS E ONDE FOR PERMITIDO POR LEI.",
  "DEFINE ANTES UM LIMITE DE VALOR E DE TEMPO E RESPEITA-O. NUNCA AUMENTES O VALOR PARA RECUPERAR PERDAS.",
  "RESULTADOS PASSADOS NÃO GARANTEM RESULTADOS FUTUROS. LESÕES, CASTIGOS, CANSAÇO E MUDANÇAS DE ÚLTIMA HORA NÃO ENTRAM NO CÁLCULO.",
  "SE SENTIRES QUE PERDES O CONTROLO, PÁRA E FALA COM ALGUÉM DE CONFIANÇA."];
function avisoView(){
  return `<h1 class="ttl">Aviso</h1>` + AVISOS.map(t => `<div class="card avc">${esc(t)}</div>`).join("");
}
function vipPick(f, min = VIP_MIN){
  const r = f.analysis?.result?.result; if (!r || !Number.isFinite(r.home) || !Number.isFinite(r.away)) return null;
  const p = Math.max(r.home, r.away); if (p < min) return null;
  const n = lr([r.home, r.draw ?? Math.max(0, 1 - r.home - r.away), r.away]);
  return { team: r.home >= r.away ? f.home_team : f.away_team, pct: r.home >= r.away ? n[0] : n[2], side: r.home >= r.away ? "h" : "a" };
}
// jogo do VIP: só abre a quem tem VIP e, nos jogos futuros, só dentro dos dias de VIP que lhe restam
function vipOpen(f){
  const u = cur(); if (!u || !canVip(u)) return false;
  if (isDone(f.status)) return true;
  return dayList().slice(0, vipDays(u)).some(d => d.key === dayKey(f.kickoff_utc));
}
// jogo do VIP já terminado em que a escolha FALHOU: deixa de ser "VIP" e volta a ser um jogo normal no histórico
function vipLost(f){ const p = vipPick(f), fin = isDone(f.status) ? finalOf(f) : null; if (!p || !fin) return false; return !(p.side === "h" ? fin.h > fin.a : fin.a > fin.h); }
const vipLocked = f => !!vipPick(f) && !vipOpen(f) && !vipLost(f);
function pastDays(n){ // os últimos n dias, do mais antigo (esquerda) até hoje (direita)
  const out = [];
  for (let i = n - 1; i >= 0; i--){
    const d = new Date(Date.now() - i * 86400e3), iso = d.toISOString();
    const wd = new Intl.DateTimeFormat("pt", { timeZone: S.tz, weekday: "short" }).format(d).replace(".", "");
    const dn = new Intl.DateTimeFormat("pt", { timeZone: S.tz, day: "numeric" }).format(d);
    const mo = (i === n - 1 || dn === "1") ? new Intl.DateTimeFormat("pt", { timeZone: S.tz, month: "short" }).format(d).replace(".", "") : "";
    out.push({ key: dayKey(iso), wd: wd.charAt(0).toUpperCase() + wd.slice(1), dn, mo });
  }
  return out;
}
function vipDays(u){
  const ax = access(u); if (u.admin || !ax.exp) return 7;
  return Math.max(1, Math.min(7, Math.ceil((ax.exp - Date.now()) / DAYMS))); // até 7 dias; vai diminuindo com os dias que restam
}
function vipTabs(sup){
  const t = S.vtab === "res" ? "res" : "vip", b = (v, l) => `<button type="button" class="vtb" data-s="vtab" data-v="${v}" aria-pressed="${t === v}">${l}</button>`;
  return `<div class="vtabs">${b("vip", sup ? "Super VIP" : "VIP")}${b("res", "Resultados")}</div>`;
}
function vipView(kind){
  const sup = kind === "svip", pk = f => vipPick(f, sup ? SUP_MIN : VIP_MIN), tabs = () => vipTabs(sup), grp = (l, h) => vipGrouped(l, h, sup ? SUP_MIN : VIP_MIN);
  const u = cur(); if (kind === "svip" && !(u && u.admin)){ S.view = "home"; return homeView(); }
  if (!u || !canVip(u)) return `<div class="empty" style="font-weight:800;color:var(--ink);font-size:18px">NÃO TENS ACESSO AO VIP</div>`;
  if (S.vtab === "res"){
    const won = f => { const fin = finalOf(f), p = pk(f); return fin ? (p.side === "h" ? fin.h > fin.a : fin.a > fin.h) : null; };
    const fin = S.history.filter(f => pk(f) && won(f) !== null); // análises VIP já terminadas (todos os 7 dias, sem depender do dia de criação da conta)
    const past = pastDays(7); if (!past.some(d => d.key === S.vwday)) S.vwday = past[past.length - 1].key;
    const cnt = new Map(); fin.forEach(f => { const k = dayKey(f.kickoff_utc); cnt.set(k, (cnt.get(k) || 0) + 1); });
    const strip = past.map(d => `<button class="dy" data-s="vwday" data-k="${esc(d.key)}" aria-pressed="${S.vwday === d.key}"><span>${esc(d.wd)}</span><b>${esc(d.dn)}</b><em class="mo">${esc(d.mo)}</em><i class="${cnt.get(d.key) ? "has" : ""}"></i></button>`).join("");
    const day = fin.filter(f => dayKey(f.kickoff_utc) === S.vwday), w = day.filter(f => won(f)).length, l = day.length - w, pc = n => day.length ? Math.round(n * 100 / day.length) : 0;
    const stat = `<div class="stat" style="grid-template-columns:repeat(2,1fr)"><div><b style="color:var(--ok)">${pc(w)}%</b>Ganhos (${w})</div><div><b style="color:var(--bad)">${pc(l)}%</b>Perdas (${l})</div></div>`;
    const list = day.slice().sort((a, b) => b.kickoff_utc.localeCompare(a.kickoff_utc));
    return tabs() + `<div class="stripw"><div class="strip">${strip}</div></div>` + stat + msgHtml() + (list.length ? grp(list, true) : `<div class="empty">Sem resultados neste dia.</div>`);
  }
  const days = dayList().slice(0, vipDays(u));
  if (!days.some(d => d.key === S.vday)) S.vday = days[0].key;
  const today = dayKey(new Date().toISOString());
  const all = S.fixtures.filter(f => !["PST", "CANC"].includes(f.status) && !isDone(f.status) && (isLive(f.status) || dayKey(f.kickoff_utc) >= today) && pk(f));
  const count = new Map(); all.forEach(f => { const k = dayKey(f.kickoff_utc); count.set(k, (count.get(k) || 0) + 1); });
  const strip = days.map(d => `<button class="dy" data-vday="${esc(d.key)}" aria-pressed="${S.vday === d.key}"><span>${esc(d.wd)}</span><b>${esc(d.dn)}</b><em class="mo">${esc(d.mo)}</em><i class="${count.get(d.key) ? "has" : ""}"></i></button>`).join("");
  const list = all.filter(f => (isLive(f.status) && dayKey(f.kickoff_utc) < today ? today : dayKey(f.kickoff_utc)) === S.vday).sort((a, b) => (a.competitions?.name ?? "").localeCompare(b.competitions?.name ?? "") || a.kickoff_utc.localeCompare(b.kickoff_utc));
  return tabs() + `<div class="stripw"><div class="strip" id="vstrip">${strip}</div></div>${msgHtml()}` +
    (list.length ? grp(list) : `<div class="empty">Sem jogos para o ${sup ? "Super VIP" : "VIP"}</div>`);
}
function vipGrouped(list, hist, min = VIP_MIN){
  let h = "", lc = "", ld = "";
  for (const f of list){
    if (hist){ const d = dayKey(f.kickoff_utc); if (d !== ld){ h += `<h2 class="day">${esc(fmtDay(f.kickoff_utc))}</h2>`; ld = d; lc = ""; } }
    const c = f.competitions?.name ?? "Outros";
    if (c !== lc){ h += `<div class="cn">${esc(c)}${f.competitions?.country ? " · " + esc(f.competitions.country) : ""}</div>`; lc = c; }
    const p = vipPick(f, min), fin = hist ? finalOf(f) : null;
    const mark = fin ? ((p.side === "h" ? fin.h > fin.a : fin.a > fin.h) ? ` <span style="color:var(--ok)">✓</span>` : ` <span style="color:var(--bad)">✗</span>`) : "";
    h += matchCard(f).replace(/<div class="meta"><span>(<span class="st[^>]*>[^<]*<\/span>)<\/span>/, (m, badge) => `<div class="meta"><span style="font-weight:700;color:var(--ink)">${isLive(f.status) ? badge + " " : ""}${esc(p.team)} vitória: ${p.pct}%${mark}</span>`);
  }
  return h;
}
const backBar = () => `<div class="row" style="margin-bottom:4px;justify-content:flex-end"><button class="dbk" data-act="back" aria-label="Fechar">✕</button></div>`;
function goBack(){
  S.drawer = false; S.search = false; S.lg = false; $("ov").innerHTML = "";
  const i = history.state && history.state.i;
  if (i > 0) { try { history.back(); return; } catch {} }
  S.view = "home"; S.compId = null; try { history.replaceState({ v: "home", c: null, i: 0 }, ""); } catch {}
  startBusy(); render(); window.scrollTo && window.scrollTo(0, 0);
}
/* ---------- Combinação (só administrador): ficha com 2 análises por jogo ---------- */
const CB_PARTES = 70, CB_GOLOS = 82; // mínimos: "Marca duas partes" 70% e "Mais de 1,5 golos" 82%
function cbPick(f){
  const an = f.analysis, r = an && !an.generic ? an.result : null;
  if (!r || !r.bothHalves || !r.totals) return null;
  const h = r.bothHalves.home?.yes, a = r.bothHalves.away?.yes, g = r.totals.over_1_5;
  if (![h, a, g].every(Number.isFinite)) return null;
  const hp = Math.round(h * 100), ap = Math.round(a * 100), gp = Math.round(g * 100);
  // "Marca duas partes": Sim ou Não de cada equipa; fica a opção com a maior percentagem
  const opts = [{ side: "h", v: "Sim", p: hp }, { side: "h", v: "Não", p: 100 - hp }, { side: "a", v: "Sim", p: ap }, { side: "a", v: "Não", p: 100 - ap }];
  const best = opts.reduce((m, x) => (x.p > m.p ? x : m), opts[0]);
  if (best.p < CB_PARTES || gp < CB_GOLOS) return null; // os dois mínimos têm de se cumprir no mesmo jogo
  return { team: best.side === "h" ? f.home_team : f.away_team, side: best.side, v: best.v, p: best.p, g: gp };
}
function cbRes(f){ // {b: marca nas duas partes, g: mais de 1,5} -> true/false/null
  const p = cbPick(f), fin = p && isDone(f.status) ? finalOf(f) : null; if (!fin) return { b: null, g: null };
  const noHt = fin.hh == null || fin.ah == null;
  const sc = noHt ? null : (p.side === "h" ? fin.hh > 0 && fin.h - fin.hh > 0 : fin.ah > 0 && fin.a - fin.ah > 0);
  const b = sc === null ? null : (p.v === "Sim" ? sc : !sc);
  return { b, g: fin.h + fin.a >= 2 };
}
function cbOk(f){ const r = cbRes(f); if (r.b === false || r.g === false) return false; return r.b === null || r.g === null ? null : true; }
function cbCard(f, hist){
  const p = cbPick(f), fin = hist ? finalOf(f) : null, r = hist ? cbRes(f) : { b: null, g: null }, ok = hist ? cbOk(f) : null;
  const logo = u => u ? `<img src="${esc(u)}" alt="" loading="lazy" referrerpolicy="no-referrer">` : "";
  const dot = o => !hist ? "<span></span>" : `<span class="dot ${o === true ? "g" : o === false ? "r" : "n"}" role="img" aria-label="${o === true ? "Acertou" : o === false ? "Falhou" : "Sem dados para avaliar"}"></span>`;
  const row = (l, n, o, v) => `<div class="rp${v ? " wd" : ""}"><span>${esc(l)}</span>${v ? `<b class="v">${esc(v)}</b>` : ""}<span class="trk"><span style="width:${n}%"></span></span><strong>${n}%</strong>${dot(o)}</div>`;
  const top = f.time_confirmed ? `${dayKey(f.kickoff_utc)} ${fmtHour(f.kickoff_utc)}` : `${dayKey(f.kickoff_utc)} · hora por confirmar`;
  const mk = ok === null || !hist ? "" : `<div class="mk" style="color:var(${ok ? "--ok" : "--bad"})" aria-label="${ok ? "Acertou" : "Falhou"}">${ok ? "✓" : "✗"}</div>`;
  return `<article class="match"><div class="dt">${esc(top)}</div><div class="teams">
    <div class="t">${logo(f.home_logo)}<span>${esc(f.home_team)}</span></div><div class="vsw"><div class="vs">${fin ? `${fin.h} - ${fin.a}` : "vs"}</div>${mk}</div>
    <div class="t r"><span>${esc(f.away_team)}</span>${logo(f.away_logo)}</div></div>
    <div style="margin:8px 0 2px">${row(`${p.team}: Marca duas partes`, p.p, r.b, p.v)}${row("Mais de 1,5 golos", p.g, r.g)}</div>
    <div class="meta"><span><span class="st ${isLive(f.status) ? "live" : ""}">${esc(STATUS[f.status] ?? f.status)}</span></span>
    ${fin ? `<span class="row"><button class="btn" data-an="${esc(f.id)}">Ver estatísticas</button></span>` : ""}</div></article>`;
}
function cbGrouped(list, hist){
  let h = "", lc = "", ld = "";
  for (const f of list){
    if (hist){ const d = dayKey(f.kickoff_utc); if (d !== ld){ h += `<h2 class="day">${esc(fmtDay(f.kickoff_utc))}</h2>`; ld = d; lc = ""; } }
    const c = f.competitions?.name ?? "Outros";
    if (c !== lc){ h += `<div class="cn">${esc(c)}${f.competitions?.country ? " · " + esc(f.competitions.country) : ""}</div>`; lc = c; }
    h += cbCard(f, hist);
  }
  return h;
}
function combView(){
  const u = cur(); if (!(u && u.admin)){ S.view = "home"; return homeView(); }
  const t = S.ctab === "hist" ? "hist" : "now", b = (v, l) => `<button type="button" class="vtb" data-s="ctab" data-v="${v}" aria-pressed="${t === v}">${l}</button>`;
  const tabs = `<div class="vtabs">${b("now", "Combinação")}${b("hist", "Histórico")}</div>`;
  const dayBtn = (d, attr, on, has) => `<button class="dy" ${attr} aria-pressed="${on}"><span>${esc(d.wd)}</span><b>${esc(d.dn)}</b><em class="mo">${esc(d.mo)}</em><i class="${has ? "has" : ""}"></i></button>`;
  if (t === "hist"){
    const fin = S.history.filter(f => cbPick(f) && finalOf(f));
    const past = pastDays(7); if (!past.some(d => d.key === S.cwday)) S.cwday = past[past.length - 1].key;
    const cnt = new Map(); fin.forEach(f => { const k = dayKey(f.kickoff_utc); cnt.set(k, (cnt.get(k) || 0) + 1); });
    const strip = past.map(d => dayBtn(d, `data-s="cwday" data-k="${esc(d.key)}"`, S.cwday === d.key, cnt.get(d.key))).join("");
    const day = fin.filter(f => dayKey(f.kickoff_utc) === S.cwday), oks = day.map(cbOk), w = oks.filter(o => o === true).length, l = oks.filter(o => o === false).length, n = w + l, pc = x => n ? Math.round(x * 100 / n) : 0;
    const stat = n ? `<div class="stat" style="grid-template-columns:repeat(2,1fr)"><div><b style="color:var(--ok)">${pc(w)}%</b>Ganhos (${w})</div><div><b style="color:var(--bad)">${100 - pc(w)}%</b>Perdidos (${l})</div></div>` : "";
    const list = day.slice().sort((a, b2) => b2.kickoff_utc.localeCompare(a.kickoff_utc));
    return tabs + `<div class="stripw"><div class="strip">${strip}</div></div>` + stat + msgHtml() + (list.length ? cbGrouped(list, true) : `<div class="empty">Sem combinações terminadas neste dia.</div>`);
  }
  const days = dayList().slice(0, 7);
  const today = dayKey(new Date().toISOString());
  const all = S.fixtures.filter(f => !["PST", "CANC"].includes(f.status) && !isDone(f.status) && (isLive(f.status) || dayKey(f.kickoff_utc) >= today) && cbPick(f));
  const dk = f => isLive(f.status) && dayKey(f.kickoff_utc) < today ? today : dayKey(f.kickoff_utc);
  const cnt = new Map(); all.forEach(f => { const k = dk(f); cnt.set(k, (cnt.get(k) || 0) + 1); });
  if (!days.some(d => d.key === S.cday)) S.cday = (days.find(d => cnt.has(d.key)) || days[0]).key; // abre no primeiro dia com jogos
  const strip = days.map(d => dayBtn(d, `data-s="cday" data-k="${esc(d.key)}"`, S.cday === d.key, cnt.get(d.key))).join("");
  const list = all.filter(f => dk(f) === S.cday).sort((a, b2) => (a.competitions?.name ?? "").localeCompare(b2.competitions?.name ?? "") || a.kickoff_utc.localeCompare(b2.kickoff_utc));
  const head = list.length ? `<div class="card" style="text-align:center;font-weight:800">Ficha do dia · ${list.length} ${list.length === 1 ? "jogo" : "jogos"} · ${list.length * 2} análises</div>` : "";
  return tabs + `<div class="stripw"><div class="strip">${strip}</div></div>` + msgHtml() + head + (list.length ? cbGrouped(list, false) : `<div class="empty">Nenhum jogo cumpre as duas regras neste dia.</div>`);
}
function view(){ return ({ comb: combView, vip: () => vipView("vip"), svip: () => vipView("svip"), aviso: avisoView, home: homeView, comp: compView, tips: tipsView, cal: calView, fav: favView, hist: histView, taxa: taxaView,
  admin: adminView })[S.view](); }
function pruneFavs(){
  const keep = S.favs.filter(f => f.gid || Date.parse(f.kickoff_utc) >= Date.now() - 86400e3); // favoritos de jogos do app ficam até os removeres
  if (keep.length !== S.favs.length){ S.favs = keep; store.set("favSearch", S.favs); }
}
// o histórico fica guardado neste aparelho: os jogos terminados não desaparecem quando o servidor deixa de os enviar
let keepMap = null;
function keepHistory(m){
  if (!keepMap){ keepMap = new Map(); const v = store.get("histKeep", []); if (Array.isArray(v)) for (const f of v) if (f && f.id) keepMap.set(f.id, f); }
  let changed = false;
  for (const [id, f] of m){ const o = keepMap.get(id); if (!o || (!o.analysis && f.analysis) || o.home_goals !== f.home_goals || o.away_goals !== f.away_goals){ keepMap.set(id, f); changed = true; } }
  for (const [id, f] of keepMap) if (!m.has(id)) m.set(id, f);
  if (changed){
    const lim = Date.now() - 90 * 864e5, list = [...keepMap.values()].filter(f => Date.parse(f.kickoff_utc) >= lim).sort((a, b) => b.kickoff_utc.localeCompare(a.kickoff_utc)).slice(0, 300);
    keepMap = new Map(list.map(f => [f.id, f])); store.set("histKeep", list);
  }
}
function reclassify(){
  pruneFavs();
  const today = dayKey(new Date().toISOString());
  const all = S.raw.map(withEff);
  S.fixtures = all.filter(f => !isDone(f.status));            // jogo terminado sai logo da lista...
  const m = new Map();
  for (const f of all) if (isDone(f.status)) m.set(f.id, f);   // ...e entra logo no histórico
  for (const f0 of S.rawHist){ const f = withEff(f0); if (isDone(f.status) || dayKey(f.kickoff_utc) < today) m.set(f.id, f.analysis || !m.has(f.id) ? f : m.get(f.id)); }
  keepHistory(m);
  S.history = [...m.values()].filter(f => !S.hidden.has(f.id)).sort((a, b) => b.kickoff_utc.localeCompare(a.kickoff_utc));
}
function render(){
  reclassify();
  const u = cur();
  if (!u){ S.soc.was = false; $("ov").innerHTML = ""; $("app").innerHTML = authView(); return; }
  S.soc.was = true;
  if (S.view === "tips"){ S.fade = false; $("app").innerHTML = helpView(); return; }
  const fade = S.fade; S.fade = false;
  $("app").innerHTML = header() + (S.upd === "new" ? `<button class="updbar" data-s="upd">Há uma versão nova do aplicativo. Toca aqui para actualizar.</button>` : "") + `<main class="${fade ? "fi" : ""}">${S.busy ? loaderHtml() : view()}</main>` + nav();
}

/* ---------- Menu (definições) e pesquisa ---------- */
function drawerHtml(){
  if (!S.drawer){ if (!S.search && !S.lg) $("ov").innerHTML = ""; return; }
  const dark = isDark(), u = cur(), B = "width:100%;font-size:18px;padding:14px;margin-bottom:8px";
  const top = u ? `<div class="mrow">${avatar(u, 44)}<b>${esc(u.name)}</b></div>
    ${isAdm(u) ? `<button class="btn" style="${B};background:#d32f2f;color:#fff" data-s="admin">Painel</button>` : ""}<button class="btn" style="${B};background:#ffd600;color:#1b1500" data-s="vip">VIP</button>${u.admin ? `<button class="btn" style="${B};background:linear-gradient(135deg,#f7dc7e,#d4af37 50%,#a67c00);color:#2a1d00" data-s="svip">Super VIP</button><button class="btn" style="${B};background:linear-gradient(135deg,#3b82f6,#1e3a8a);color:#fff" data-s="comb">Combinação</button>` : ""}` : "";
  $("ov").innerHTML = `<div class="ov" data-act="close"><div class="drawer" role="dialog" aria-label="Menu">${top}
    <button class="btn" style="${B};${dark ? "background:#fff;color:#000;border:1px solid #999" : "background:#000;color:#fff;border:1px solid #777"}" data-act="toggle" aria-pressed="${dark}">${dark ? "☀️ Modo claro" : "🌙 Modo escuro"}</button>
    <button class="btn" style="${B};background:#1fa463" data-s="wa">WhatsApp</button>
    <button class="btn" style="${B};background:${S.upd === "ok" ? "#757575" : "#1565c0"};color:#fff" data-s="upd">${S.upd === "ok" ? "Actualizado" : S.upd === "busy" ? "A actualizar…" : S.upd === "off" ? "Sem ligação" : "Actualizar"}</button>
    ${u ? `<button class="btn alt" style="width:100%;margin-top:8px" data-s="logout">Terminar sessão</button>` : ""}</div></div>`;
}
function searchHtml(){
  if (!S.search){ drawerHtml(); return; }
  const fld = (id, label, key) => `<label class="fl" for="${id}">${label}</label><input id="${id}" type="text" autocomplete="off" value="${esc(S.na[key])}">`;
  $("ov").innerHTML = `<div class="ov"><div class="sp">
    <div class="row" style="justify-content:space-between"><b style="font-size:22px">Nova análise</b><button class="btn alt" data-act="close">Fechar</button></div>
    <p class="note">Procura nas 10 competições do app e, quando houver fonte, noutras ligas. Só aparecem jogos já publicados e dentro dos próximos 30 dias.</p>
    ${fld("na-home", "Equipa da casa", "home")}${fld("na-away", "Equipa de fora", "away")}${fld("na-league", "Liga", "league")}
    <button class="btn" style="width:100%;margin-top:14px;font-size:17px;padding:13px" data-act="analyze">Analisar</button><div id="nas"></div></div></div>`;
}
const DAY = 86400e3;
const coded = (code, msg) => Object.assign(new Error(msg || code), { code });
const loose = (a, b) => { a = norm(a).trim(); b = norm(b).trim(); return !!a && !!b && (a.includes(b) || b.includes(a)); };
function errText(e){
  return ({ nosource: "Essa liga não está nas 10 do app e a fonte de dados para outras ligas ainda não está ligada, por isso não é possível procurar o jogo.",
    offline: "Sem ligação à internet. Esta análise precisa de estar online.",
    notfound: "Jogo não encontrado. Só aparecem jogos já publicados e dentro dos próximos 30 dias." })[e.code] || e.message || "Não foi possível fazer a análise.";
}
const nameOk = (typed, name) => { const t = norm(typed).split(/\s+/).filter(w => w.length >= 2), n = norm(name); return t.length > 0 && t.every(w => n.includes(w)); };
const aliasesOf = f => [f.competitions?.name, f.competitions?.country, ...(LABEL[f.competition_id] ?? [])].filter(Boolean);
const leagueOk = (f, typed) => aliasesOf(f).some(a => loose(a, typed));
const knownLeague = typed => ORDER.some(id => [...(LABEL[id] ?? []), S.leagues.find(l => l.id === id)?.name ?? ""].some(a => loose(a, typed)));
// Procura nos jogos das 10 competições (dados já importados e analisados), sempre depois de ir ao servidor
async function lookupInternal(q, now, to){
  if (!(await fetchData())) throw coded("offline");
  reclassify();
  const open = S.fixtures.filter(f => !vipLocked(f) && ["NS", "TBD"].includes(f.status) && Date.parse(f.kickoff_utc) >= now && Date.parse(f.kickoff_utc) <= to);
  const hit = open.filter(f => nameOk(q.home, f.home_team) && nameOk(q.away, f.away_team) && leagueOk(f, q.league)).sort((a, b) => a.kickoff_utc.localeCompare(b.kickoff_utc))[0];
  if (!hit){
    const swapped = open.find(f => nameOk(q.home, f.away_team) && nameOk(q.away, f.home_team) && leagueOk(f, q.league));
    if (swapped) throw coded("swapped", `Encontrei o jogo, mas com a casa e o visitante trocados: casa ${swapped.home_team}, fora ${swapped.away_team}. Troca os campos.`);
    const other = open.find(f => nameOk(q.home, f.home_team) && nameOk(q.away, f.away_team));
    if (other) throw coded("league", `Encontrei esse jogo noutra competição (${other.competitions?.name}). Escreve essa liga para analisar.`);
    return null;
  }
  if (!hit.analysis) hit.analysis = genericAn(hit);
  const qa = hit.analysis.result.quality ?? {};
  return { f: { id: "fx:" + hit.id, home_team: hit.home_team, away_team: hit.away_team, competitions: hit.competitions, kickoff_utc: hit.kickoff_utc, time_confirmed: hit.time_confirmed, status: "NS" },
    an: hit.analysis, q,
    note: `Base: últimos ${qa.homeMatches ?? 5} jogos de cada equipa e confrontos diretos. Fonte: football-data.org (competições do app).` };
}
async function lookup(q){
  const now0 = Date.now(), to0 = now0 + 30 * DAY;
  const internal = await lookupInternal(q, now0, to0);
  if (internal) return internal;
  if (!EXTRA_SOURCE) throw coded(knownLeague(q.league) ? "notfound" : "nosource");
  const now = Date.now(), to = now + 30 * DAY;
  let res;
  try { res = await EXTRA_SOURCE.find({ ...q, from: new Date(now).toISOString(), to: new Date(to).toISOString() }); }
  catch (err){ throw err && err.code ? err : coded("offline"); }
  const ev = res && res.event;
  if (!ev) throw coded("notfound");
  const t = Date.parse(ev.kickoff_utc);
  if (!(t >= now && t <= to)) throw coded("notfound"); // regra do app: só jogos publicados dos próximos 30 dias
  if (ev.league && !loose(ev.league, q.league)) throw coded("league", `Encontrei esse jogo noutra competição (${ev.league}). Escreve essa liga para analisar.`);
  const out = MODEL.analyze({ home: res.homeHistory ?? [], away: res.awayHistory ?? [], h2h: res.h2h ?? res.headToHead ?? [] });
  if (!out.ok) throw coded("insufficient", out.reason);
  const f = { id: "ext:" + ev.id, home_team: ev.home, away_team: ev.away, competitions: { name: ev.league || q.league, country: "" },
    kickoff_utc: ev.kickoff_utc, time_confirmed: ev.time_confirmed !== false, status: "NS" };
  const an = { model_version: MODEL.MODEL_VERSION, created_at: new Date().toISOString(), result: out };
  const note = `Base: últimos ${out.quality.homeMatches} jogos da casa, ${out.quality.awayMatches} do visitante e ${out.quality.h2h} confrontos diretos. Fonte: ${EXTRA_SOURCE.name ?? "externa"}.`;
  return { f, an, note, q };
}
const favButton = f => `<button type="button" class="btn alt" style="width:100%;margin:10px 0" data-favtoggle="${esc(f.id)}">${S.favs.some(x => x.id === f.id) ? "★ Remover dos favoritos" : "☆ Adicionar aos favoritos"}</button>`;
function showExternal(r){
  S.ext = r; const dlg = $("dlg");
  dlg.innerHTML = analysisHtml(r.an, r.f, `<p class="note">${esc(r.note)}</p>${favButton(r.f)}`);
  if (!dlg.open) dlg.showModal();
  showRecent(r.f);
}
async function runNewAnalysis(){
  const q = { home: S.na.home.trim(), away: S.na.away.trim(), league: S.na.league.trim() };
  const say = (t, cls = "") => { const el = $("nas"); if (el) el.innerHTML = t ? `<div class="msg ${cls}" style="${cls ? "background:var(--tint);color:var(--ink)" : ""}">${esc(t)}</div>` : ""; };
  if (!q.home || !q.away || !q.league) return say("Preenche a equipa da casa, a equipa de fora e a liga.");
  if (norm(q.home).trim() === norm(q.away).trim()) return say("A equipa da casa e a de fora têm de ser diferentes.");
  say("A procurar o jogo…", "info");
  try {
    const r = await lookup(q); say(""); showExternal(r);
    S.na = { home: "", away: "", league: "" }; // campos limpos para a próxima pesquisa
    ["na-home", "na-away", "na-league"].forEach(id => { const el = $(id); if (el) el.value = ""; });
  }
  catch (e){ say(errText(e)); }
}
async function openFav(id){
  const fav = S.favs.find(x => x.id === id); if (!fav) return;
  if (fav.gid) return openAnalysis(fav.gid);
  const dlg = $("dlg"); dlg.innerHTML = `<p class="note">A obter a análise mais recente…</p>`; if (!dlg.open) dlg.showModal();
  try { showExternal(await lookup(fav.q)); }
  catch (e){ dlg.innerHTML = `<div class="msg">${esc(errText(e))}</div><button class="btn alt" style="width:100%;margin:10px 0" data-favdel="${esc(id)}">Remover dos favoritos</button><form method="dialog"><button class="btn">Fechar</button></form>`; }
}
function saveFavs(){ store.set("favSearch", S.favs); }

/* ---------- Análise e avaliação (círculos verde/vermelho) ---------- */
const ck = k => k.replace(".", ",");
// arredonda as percentagens de um mercado para inteiros que somam sempre 100
function lr(ps){
  const f = ps.map(p => Math.floor(p * 100 + 1e-9));
  let rest = 100 - f.reduce((a, b) => a + b, 0);
  ps.map((p, i) => [p * 100 - f[i], i]).sort((a, b) => b[0] - a[0]).forEach(([, i]) => { if (rest > 0){ f[i]++; rest--; } });
  return f;
}
// Cada linha: l = texto, p = probabilidade, fn = "isto aconteceu?" (true/false/null se não há dados), v = Sim/Não/Vence, pick = escolha do modelo
// jogo sem análise guardada ou com poucos dados: calcula na mesma (estimativa genérica, baixa fiabilidade)
const genericAn = f => ({ model_version: MODEL.MODEL_VERSION, created_at: new Date().toISOString(), result: MODEL.analyze({ home: [], away: [] }), generic: true, retro: isDone(f.status) });
const poi = (k, l) => { let f = 1; for (let i = 2; i <= k; i++) f *= i; return Math.exp(-l) * Math.pow(l, k) / f; };
function sections(r, nm){
  const H = nm?.h || "Casa", A = nm?.a || "Fora", out = [];
  const topI = items => items.reduce((b, x, i) => (x[1] > items[b][1] ? i : b), 0);
  const excl = (items, yes = () => "Sim") => { const t = topI(items); return items.map(([l, p, fn], i) => ({ l, p, fn, v: i === t ? yes(i) : "Não", pick: i === t })); };
  const one = (l, p, fn, pick) => ({ l, p, fn, v: null, pick });
  const noHt = f => f.hh == null || f.ah == null;
  const win = i => (i === 1 ? "Sim" : "Vence");
  // 1X2: diferença entre as duas equipas < 5 => "Qualquer vence"; 5 a 10 (jogo equilibrado) => Vence/Empata + Talvez Sim; maior => Sim/Não
  { const it = [[H, r.result.home, f => f.h > f.a, "h"], ["Empate", r.result.draw, f => f.h === f.a, "d"], [A, r.result.away, f => f.h < f.a, "a"]];
    const n = lr(it.map(x => x[1])), diff = Math.abs(n[0] - n[2]);
    const favI = n[0] >= n[2] ? 0 : 2, dogI = favI === 0 ? 2 : 0;
    if (diff < 5){
      out.push({ title: "Resultado final", pct: true, groups: [[{ l: "1X2", p: r.result.home + r.result.away, fn: f => f.h !== f.a, v: "Qualquer vence", pick: true }]] });
    } else if (diff <= 10 && n[1] > n[dogI] && n[1] <= n[favI]){
      const fav = it[favI][3] === "h"; // favorita em casa: "Vence/Empata"; favorita fora: "Empate/Vence"
      const rows = it.map(([l, p, fn, k], i) => {
        if (i === favI) return { l, p, fn: fav ? (f => f.h >= f.a) : (f => f.h <= f.a), v: fav ? "Vence/Empata" : "Empate/Vence", pick: true };
        if (k === "d") return { l, p, fn, v: "Talvez Sim", pick: false };
        return { l, p, fn, v: "Não vence", pick: false };
      });
      out.push({ title: "Resultado final", pct: true, groups: [rows] });
    } else {
      out.push({ title: "Resultado final", pct: true, groups: [excl(it.map(([l, p, fn, k]) => [k === "d" ? l : `${l} vence`, p, fn]))] });
    }
  }
  { const rr = r.result, dd = rr.draw ?? Math.max(0, 1 - rr.home - rr.away); // hipótese dupla
    const it = [[`${H} ganha ou Empata`, rr.home + dd, f => f.h >= f.a], ["Qualquer ganha", rr.home + rr.away, f => f.h !== f.a], [`Empata ou ${A} ganha`, dd + rr.away, f => f.h <= f.a]];
    const tp = topI(it), lowI = it.reduce((b, x, i, arr) => (x[1] < arr[b][1] ? i : b), 0); // a de menor percentagem diz Não, as outras dizem Sim
    out.push({ title: "Hipótese dupla", pct: true, groups: it.map(([l, p, fn], i) => [{ l, p, fn, v: i === lowI ? "Não" : "Sim", pick: i === tp }]) });
  }
  const sn = (p, lim) => p >= lim ? "Sim" : "Não"; // abaixo do limite diz Não, a partir do limite diz Sim
  const t = r.totals, tg = [];
  for (const [k, key] of [["0.5", "0_5"], ["1.5", "1_5"], ["2.5", "2_5"], ["3.5", "3_5"]]){
    const over = t["over_" + key], under = t["under_" + key];
    if (over == null) continue;
    const ov = f => f.h + f.a > +k, un = f => f.h + f.a < +k;
    if (under != null){ const o = over >= under; tg.push([{ l: `Mais de ${ck(k)}`, p: over, fn: ov, v: sn(over, 0.21), pick: o }, { l: `Menos de ${ck(k)}`, p: under, fn: un, v: sn(under, 0.21), pick: !o }]); }
    else tg.push([{ l: `Mais de ${ck(k)}`, p: over, fn: ov, v: sn(over, 0.21), pick: over >= 0.5 }]);
  }
  out.push({ title: "Total de golos", pct: true, groups: tg });
  if (r.reach) out.push({ title: "Alcance de golos", pct: true, groups: [[4, r.reach.ge4], [5, r.reach.ge5]].filter(x => x[1] != null).map(([n, p]) => [{ l: `${n}+`, p, fn: f => f.h + f.a >= n, v: sn(p, 0.20), pick: p >= 0.5 }]) });
  const by = r.btts.yes >= r.btts.no;
  out.push({ title: "Ambas as equipas marcam", pct: true, groups: [[one("Sim", r.btts.yes, f => f.h > 0 && f.a > 0, by), one("Não", r.btts.no, f => !(f.h > 0 && f.a > 0), !by)]] });
  out.push({ title: "Resultado ao intervalo", pct: true, groups: [excl([[H, r.halftime.home, f => noHt(f) ? null : f.hh > f.ah], ["Empate", r.halftime.draw, f => noHt(f) ? null : f.hh === f.ah], [A, r.halftime.away, f => noHt(f) ? null : f.hh < f.ah]], win)] });
  const g1 = f => f.hh + f.ah, g2 = f => f.h + f.a - (f.hh + f.ah);
  if (r.productiveHalf) out.push({ title: "Parte mais produtiva", pct: true, groups: [excl([["Primeira parte", r.productiveHalf.first, f => noHt(f) ? null : g1(f) > g2(f)], ["Empate", r.productiveHalf.draw, f => noHt(f) ? null : g1(f) === g2(f)], ["Segunda parte", r.productiveHalf.second, f => noHt(f) ? null : g1(f) < g2(f)]])] });
  if (r.lambda){
    const wh = (l1, l2) => { let w = 0; for (let i = 0; i <= 10; i++) for (let j = 0; j < i; j++) w += poi(i, l1) * poi(j, l2); return w; };
    const anyHalf = (lf, lo) => 1 - (1 - wh(lf * 0.45, lo * 0.45)) * (1 - wh(lf * 0.55, lo * 0.55)); // vence pelo menos uma das partes
    const ph = anyHalf(r.lambda.home, r.lambda.away), pa = anyHalf(r.lambda.away, r.lambda.home);
    const hw = side => f => noHt(f) ? null : side === "h" ? (f.hh > f.ah || (f.h - f.hh) > (f.a - f.ah)) : (f.ah > f.hh || (f.a - f.ah) > (f.h - f.hh));
    out.push({ title: "Vence qualquer parte", pct: true, groups: [
      [{ l: H, p: ph, fn: hw("h"), v: "Sim", pick: ph >= pa }],
      [{ l: A, p: pa, fn: hw("a"), v: "Sim", pick: pa > ph }]] });
  }
  if (r.bothHalves){
    // só aparece o Sim da equipa dada a vitória (resultado final) e o Não da equipa dada a derrota
    const bh = side => f => noHt(f) ? null : (side === "h" ? f.hh > 0 && f.h - f.hh > 0 : f.ah > 0 && f.a - f.ah > 0);
    const no = side => f => { const v = bh(side)(f); return v === null ? null : !v; };
    const ph = r.bothHalves.home.yes, pa = r.bothHalves.away.yes;
    const winH = r.result.home >= r.result.away, winSide = winH ? "h" : "a", loseSide = winH ? "a" : "h";
    const winL = winH ? H : A, loseL = winH ? A : H, winP = winH ? ph : pa, loseP = winH ? pa : ph;
    out.push({ title: "Marca duas partes", pct: true, groups: [
      [{ l: `${winL}: Sim`, p: winP, fn: bh(winSide), v: "Sim", pick: true }],
      [{ l: `${loseL}: Não`, p: 1 - loseP, fn: no(loseSide), v: "Não", pick: true }]] });
  }
  // só aparece uma opção por equipa: a de maior percentagem, com 0 / 1+ / 2+ / 3+
  const bucketTop = (obj, side) => {
    const p0 = obj["0"] ?? 0, p1 = obj["1"] ?? 0, p2 = obj["2"] ?? 0, p3 = obj["3+"] ?? 0;
    const items = [["0", p0, f => f[side] === 0], ["1+", p1 + p2 + p3, f => f[side] >= 1], ["2+", p2 + p3, f => f[side] >= 2], ["3+", p3, f => f[side] >= 3]];
    const tp = topI(items);
    return [one(items[tp][0], items[tp][1], items[tp][2], true)];
  };
  out.push({ title: "Golos da equipa da casa", pct: true, groups: [bucketTop(r.teamGoals.home, "h")] });
  out.push({ title: "Golos da equipa visitante", pct: true, groups: [bucketTop(r.teamGoals.away, "a")] });
  // quem marcou primeiro só é certo se uma das equipas não marcou
  const first = f => (f.h + f.a === 0 ? "none" : f.a === 0 ? "home" : f.h === 0 ? "away" : null);
  out.push({ title: "Quem marca primeiro", pct: true, groups: [excl([[H, r.firstToScore.home, f => { const v = first(f); return v === null ? null : v === "home"; }], ["Sem golos", r.firstToScore.none, f => f.h + f.a === 0], [A, r.firstToScore.away, f => { const v = first(f); return v === null ? null : v === "away"; }]])] });
  return out;
}
const ints = (sec, g) => !sec.pct ? [] : g.length > 1 ? lr(g.map(x => x.p)) : g.map(x => Math.round(x.p * 100));
const occ = (x, fin) => { if (!fin) return null; const o = x.fn(fin); return o === null || o === undefined ? null : o; };
// verde/vermelho: a frase mostrada (ex.: "Empate Não") estava certa?
const rowOk = (x, fin) => { const o = occ(x, fin); return o === null ? null : (String(x.v).startsWith("Não") ? !o : o); };
// o modelo acertou neste mercado? (a opção escolhida aconteceu; se não escolheu nenhuma, nenhuma das linhas aconteceu)
function groupHit(g, fin){
  if (!fin) return null;
  const pk = g.find(x => x.pick);
  if (pk) return occ(pk, fin);
  const os = g.map(x => occ(x, fin));
  return os.some(o => o === null) ? null : os.every(o => !o);
}
const kLogo = (u, n) => u ? `<img src="${esc(u)}" alt="" referrerpolicy="no-referrer">` : `<i aria-hidden="true">${esc((n || "?").trim().charAt(0).toUpperCase())}</i>`;
function cdText(iso){
  const ms = Date.parse(iso) - Date.now(); if (!(ms > 0)) return "";
  const t = Math.floor(ms / 1000), d = Math.floor(t / 86400), h = Math.floor(t % 86400 / 3600), m = Math.floor(t % 3600 / 60), sec = t % 60, p = x => String(x).padStart(2, "0");
  return (d ? d + "d " : "") + `${p(h)}:${p(m)}:${p(sec)}`;
}
function kickHeader(f, fin){
  const day = new Intl.DateTimeFormat("pt", { timeZone: S.tz, weekday: "long", day: "numeric", month: "short" }).format(new Date(f.kickoff_utc));
  const left = cdText(f.kickoff_utc);
  const state = fin ? `Terminado · ${fin.h} - ${fin.a}` : left ? "Faltam" : "Jogo a decorrer";
  return `<div class="kh"><div class="kl">${esc(f.competitions?.name ?? "")}</div><div class="kt">
    <div class="tm">${kLogo(f.home_logo, f.home_team)}<span>${esc(f.home_team)}</span></div>
    <div class="kc"><b>${esc(fmtHour(f.kickoff_utc))}</b><span>${esc(day)}</span><span>${esc(state)}</span>${!fin && left ? `<div class="cd" id="cd" data-t="${esc(f.kickoff_utc)}">${esc(left)}</div>` : ""}</div>
    <div class="tm">${kLogo(f.away_logo, f.away_team)}<span>${esc(f.away_team)}</span></div></div><div id="frm">${recentHtml(f.recent || S.recentMap[f.id])}</div></div>`;
}
// últimos 5 jogos de cada equipa e 2 últimos confrontos (dados em f.recent ou vindos do Worker em /form)
S.recentMap = {};
const sLogo = (u, n) => u ? `<img src="${esc(u)}" alt="" referrerpolicy="no-referrer">` : `<i aria-hidden="true">${esc((n || "?").trim().charAt(0).toUpperCase())}</i>`;
const resLetter = m => { const own = m.side === "a" ? m.ag : m.hg, opp = m.side === "a" ? m.hg : m.ag; return own > opp ? "V" : own < opp ? "D" : "E"; };
function recentHtml(rec){
  if (!rec || !(rec.home?.length || rec.away?.length || rec.h2h?.length)) return "";
  const row = (m, right) => `<div class="fr${right ? " r" : ""}"><span class="fb">${sLogo(m.hl, m.h)}<b>${esc(m.hg)}-${esc(m.ag)}</b>${sLogo(m.al, m.a)}</span><span class="fl ${resLetter(m)}">${resLetter(m)}</span></div>`;
  const col = (l, r) => `<div>${(l || []).slice(0, 5).map(m => row(m, r)).join("")}</div>`;
  return `<div class="frm"><h4>Últimos 5 jogos</h4><div class="fc">${col(rec.home, false)}${col(rec.away, true)}</div>
    ${rec.h2h?.length ? `<h4 style="margin-top:10px">Últimos confrontos</h4><div class="hh">${rec.h2h.slice(0, 2).map(m => `<div>${sLogo(m.hl, m.h)}${sLogo(m.al, m.a)}<span>${esc(m.hg)}-${esc(m.ag)}</span></div>`).join("")}</div>` : ""}</div>`;
}
async function loadRecent(f){
  if (f.recent) return f.recent;
  const id = String(f.id).replace(/\D/g, ""); if (!LIVE_URL || !id) return null;
  if (S.recentMap[f.id]) return S.recentMap[f.id];
  try { const r = await fetch(LIVE_URL.replace(/\/$/, "") + "/form?match=" + id); if (!r.ok) return null; const d = await r.json(); if (d.recent){ S.recentMap[f.id] = d.recent; return d.recent; } } catch {}
  return null;
}
const showRecent = f => loadRecent(f).then(rec => { const el = $("frm"); if (el && rec) el.innerHTML = recentHtml(rec); });
// contagem decrescente em direto (segundos)
setInterval(() => { const el = document.getElementById("cd"); if (!el) return; const t = cdText(el.dataset.t); if (t) el.textContent = t; else { el.remove(); } }, 1000);
function analysisHtml(an, f, extra = "", opts = {}){
  const r = an.result, fin = isDone(f.status) ? finalOf(f) : null;
  const secs = sections(r, { h: f.home_team, a: f.away_team });
  const dot = ok => !fin ? "<span></span>" : `<span class="dot ${ok === true ? "g" : ok === false ? "r" : "n"}" role="img" aria-label="${ok === true ? "Acertou" : ok === false ? "Falhou" : "Sem dados para avaliar"}"></span>`;
  const row = (x, n, sec, sub) => {
    const lab = `<span>${esc(x.l)}${sub ? `<br><small style="color:var(--mute)">${esc(sec.title)}</small>` : ""}</span>`;
    return sec.pct
      ? (x.v ? `<div class="rp wd">${lab}<b class="v">${esc(x.v)}</b><span class="trk"><span style="width:${n}%"></span></span><strong>${n}%</strong>${dot(rowOk(x, fin))}</div>`
             : `<div class="rp">${lab}<span class="trk"><span style="width:${n}%"></span></span><strong>${n}%</strong>${dot(rowOk(x, fin))}</div>`)
      : `<div class="rp nv">${lab}<strong class="v">${esc(x.v ?? "")}</strong>${dot(rowOk(x, fin))}</div>`;
  };
  const min = opts.min || 0;
  const body = secs.map(sec => { const rows = sec.groups.map(g => { const n = ints(sec, g); return g.map((x, i) => [x, n[i]]).filter(([x, p]) => !sec.pct || p >= min || (min > 50 && sec.title === "Resultado final" && x.pick)).map(([x, p]) => row(x, p, sec, false)).join(""); }).join(""); return rows ? `<div class="sec">${esc(sec.title)}</div>` + rows : ""; }).join("");
  // as 5 análises mais prováveis: só a mais provável de cada mercado
  const cand = [];
  for (const sec of secs){ let best = null; for (const g of sec.groups){ const n = ints(sec, g); g.forEach((x, i) => { if (x.pick && !sec.noTop && x.l !== "Mais de 0,5" && n[i] >= min && (!best || x.p > best.x.p)) best = { x, n: n[i], sec }; }); } if (best) cand.push(best); }
  cand.sort((a, b) => b.x.p - a.x.p);
  const topHtml = cand.slice(0, 5).map(c => row(c.x, c.n, c.sec, true)).join("");
  const legend = fin ? `<p class="note"><span class="dot g"></span> certo · <span class="dot r"></span> errado · <span class="dot n"></span> sem dados para avaliar (por exemplo, quem marca primeiro quando as duas equipas marcam). Resultado final: ${fin.h} - ${fin.a}.</p>` : "";
  return `<div class="dtop"><form method="dialog"><button class="dbk" aria-label="Fechar">✕</button></form></div>${kickHeader(f, fin)}${legend}
    <p class="warn">ESSAS ANÁLISES SÃO APENAS ESTIMATIVAS NÃO GARANTIAS DE VITÓRIA, CADA JOGO É UM JOGO.</p>${body}
    ${topHtml ? `<div class="sec">As 5 análises mais prováveis deste jogo</div>${topHtml}` : ""}
    ${extra}
    <form method="dialog"><button class="btn">Fechar</button></form>`;
}
async function openAnalysis(id){
  const dlg = $("dlg"), close = `<form method="dialog"><button class="btn">Fechar</button></form>`;
  const find = () => [...S.fixtures, ...S.history].find(x => x.id === id);
  const paint = f => {
    const fb0 = isDone(f.status) ? "" : `<button type="button" class="btn alt" style="width:100%;margin:10px 0" data-favgame="${esc(f.id)}">${favG(f.id) ? "★ Remover dos favoritos" : "☆ Adicionar aos favoritos"}</button>`;
    const fb = fb0; // botão "Partilhar como imagem" removido
    const sc = dlg.scrollTop;
    dlg.innerHTML = analysisHtml(f.analysis || genericAn(f), f, fb, { min: S.view === "vip" ? 50 : S.view === "svip" ? SUP_ROWS : 0 }); dlg.dataset.gid = id; dlg.dataset.sig = JSON.stringify(f.analysis || 0).length + ":" + f.status; showRecent(f);
    if (sc) dlg.scrollTop = sc;
  };
  const f0 = find();
  if (f0 && vipLocked(f0)) return; // jogo do VIP: só abre a quem tem acesso e dentro dos seus dias
  if (f0) paint(f0); else { dlg.dataset.gid = id; dlg.innerHTML = `<p class="note">A obter a análise mais recente…</p>`; }
  if (!dlg.open) dlg.showModal();
  const ok = await fetchData(); render(); // atualiza em segundo plano: as análises podem ter sido acrescentadas ou atualizadas
  if (!dlg.open || dlg.dataset.gid !== id) return;
  const f = find();
  if (f && vipLocked(f)){ if (dlg.open) dlg.close(); return; }
  if (!f){ if (!f0) dlg.innerHTML = `<div class="msg">${ok ? "Este jogo já não está na lista atual." : "Sem ligação à internet. O app precisa de estar online para mostrar as análises."}</div>${close}`; return; }
  if (!f0 || dlg.dataset.sig !== JSON.stringify(f.analysis || 0).length + ":" + f.status) paint(f);
}

const DEMO_DATA = (() => { const d = JSON.parse("{\"matches\": [{\"id\": \"m1\", \"competition_id\": \"PD\", \"competitions\": {\"name\": \"La Liga\", \"country\": \"Espanha\"}, \"home_team\": \"Barcelona\", \"away_team\": \"Sevilla\", \"kickoff_utc\": \"2026-10-19T18:00:00.000Z\", \"time_confirmed\": true, \"status\": \"NS\", \"analysis\": {\"created_at\": \"2026-10-17T10:28:36.668Z\", \"result\": {\"ok\": true, \"model\": \"poisson-v2\", \"lambda\": {\"home\": 1.7911031276415894, \"away\": 0.7079459002535925}, \"result\": {\"home\": 0.6331940506287799, \"draw\": 0.22441424212943503, \"away\": 0.1423917072417847}, \"totals\": {\"over_0_5\": 0.9178366586551767, \"over_1_5\": 0.7125064403387766, \"over_2_5\": 0.45594129909822373, \"over_3_5\": 0.24221834349522625, \"under_1_5\": 0.28749355966122325, \"under_2_5\": 0.5440587009017759, \"under_3_5\": 0.7577816565047735}, \"btts\": {\"yes\": 0.4227316294113733, \"no\": 0.5772683705886267}, \"halftime\": {\"home\": 0.4490070161327171, \"draw\": 0.4136970829705867, \"away\": 0.1372959008966963}, \"teamGoals\": {\"home\": {\"0\": 0.16677609283762268, \"1\": 0.2987131814973101, \"2\": 0.26751305682380094, \"3+\": 0.26699766884126624}, \"away\": {\"0\": 0.49265512159634595, \"1\": 0.3487731735730682, \"2\": 0.12345626917474412, \"3+\": 0.03511543565584174}}, \"exactScores\": [{\"score\": \"1-0\", \"p\": 0.14716301766019615}, {\"score\": \"2-0\", \"p\": 0.1317920706021759}, {\"score\": \"1-1\", \"p\": 0.10418345502148289}, {\"score\": \"2-1\", \"p\": 0.09330165606874243}, {\"score\": \"0-0\", \"p\": 0.08216334134482307}], \"productiveHalf\": {\"first\": 0.306829058916312, \"draw\": 0.267533496026392, \"second\": 0.42563744505729617}, \"bothHalves\": {\"home\": {\"yes\": 0.3467340505939754, \"no\": 0.6532659494060247}, \"away\": {\"yes\": 0.08798767227369067, \"no\": 0.9120123277263094}}, \"reach\": {\"ge3\": 0.45594129909822373, \"ge4\": 0.24221834349522625, \"ge5\": 0.10869230738558715, \"ge6\": 0.04195468523788899}, \"min10\": {\"home\": 0.15372007167196114, \"draw\": 0.788782365201141, \"away\": 0.057497563126897466}, \"firstToScore\": {\"home\": 0.6578262737670248, \"away\": 0.2600103848881521, \"none\": 0.08216334134482307}, \"quality\": {\"homeMatches\": 8, \"awayMatches\": 8, \"level\": \"razoavel\"}}}, \"_off\": -30, \"recent\": {\"home\": [{\"h\": \"Barcelona\", \"a\": \"Lazio\", \"hg\": 0, \"ag\": 3, \"side\": \"h\"}, {\"h\": \"Celta\", \"a\": \"Barcelona\", \"hg\": 1, \"ag\": 2, \"side\": \"a\"}, {\"h\": \"Cagliari\", \"a\": \"Barcelona\", \"hg\": 1, \"ag\": 1, \"side\": \"a\"}, {\"h\": \"Barcelona\", \"a\": \"Cremonese\", \"hg\": 0, \"ag\": 1, \"side\": \"h\"}, {\"h\": \"Barcelona\", \"a\": \"Atalanta\", \"hg\": 2, \"ag\": 0, \"side\": \"h\"}], \"away\": [{\"h\": \"Paris\", \"a\": \"Sevilla\", \"hg\": 4, \"ag\": 3, \"side\": \"a\"}, {\"h\": \"Sevilla\", \"a\": \"Ofi\", \"hg\": 2, \"ag\": 1, \"side\": \"h\"}, {\"h\": \"Sevilla\", \"a\": \"Auxerre\", \"hg\": 4, \"ag\": 1, \"side\": \"h\"}, {\"h\": \"Lavallois\", \"a\": \"Sevilla\", \"hg\": 1, \"ag\": 0, \"side\": \"a\"}, {\"h\": \"Lyon\", \"a\": \"Sevilla\", \"hg\": 4, \"ag\": 0, \"side\": \"a\"}], \"h2h\": [{\"h\": \"Sevilla\", \"a\": \"Barcelona\", \"hg\": 2, \"ag\": 2, \"side\": \"h\"}, {\"h\": \"Barcelona\", \"a\": \"Sevilla\", \"hg\": 2, \"ag\": 0, \"side\": \"h\"}]}}, {\"id\": \"m2\", \"competition_id\": \"PL\", \"competitions\": {\"name\": \"Premier League\", \"country\": \"Inglaterra\"}, \"home_team\": \"Liverpool\", \"away_team\": \"Spurs\", \"kickoff_utc\": \"2026-10-19T18:00:00.000Z\", \"time_confirmed\": true, \"status\": \"NS\", \"analysis\": {\"created_at\": \"2026-10-17T10:28:36.670Z\", \"result\": {\"ok\": true, \"model\": \"poisson-v2\", \"lambda\": {\"home\": 1.7911031276415894, \"away\": 0.7079459002535925}, \"result\": {\"home\": 0.6331940506287799, \"draw\": 0.22441424212943503, \"away\": 0.1423917072417847}, \"totals\": {\"over_0_5\": 0.9178366586551767, \"over_1_5\": 0.7125064403387766, \"over_2_5\": 0.45594129909822373, \"over_3_5\": 0.24221834349522625, \"under_1_5\": 0.28749355966122325, \"under_2_5\": 0.5440587009017759, \"under_3_5\": 0.7577816565047735}, \"btts\": {\"yes\": 0.4227316294113733, \"no\": 0.5772683705886267}, \"halftime\": {\"home\": 0.4490070161327171, \"draw\": 0.4136970829705867, \"away\": 0.1372959008966963}, \"teamGoals\": {\"home\": {\"0\": 0.16677609283762268, \"1\": 0.2987131814973101, \"2\": 0.26751305682380094, \"3+\": 0.26699766884126624}, \"away\": {\"0\": 0.49265512159634595, \"1\": 0.3487731735730682, \"2\": 0.12345626917474412, \"3+\": 0.03511543565584174}}, \"exactScores\": [{\"score\": \"1-0\", \"p\": 0.14716301766019615}, {\"score\": \"2-0\", \"p\": 0.1317920706021759}, {\"score\": \"1-1\", \"p\": 0.10418345502148289}, {\"score\": \"2-1\", \"p\": 0.09330165606874243}, {\"score\": \"0-0\", \"p\": 0.08216334134482307}], \"productiveHalf\": {\"first\": 0.306829058916312, \"draw\": 0.267533496026392, \"second\": 0.42563744505729617}, \"bothHalves\": {\"home\": {\"yes\": 0.3467340505939754, \"no\": 0.6532659494060247}, \"away\": {\"yes\": 0.08798767227369067, \"no\": 0.9120123277263094}}, \"reach\": {\"ge3\": 0.45594129909822373, \"ge4\": 0.24221834349522625, \"ge5\": 0.10869230738558715, \"ge6\": 0.04195468523788899}, \"min10\": {\"home\": 0.15372007167196114, \"draw\": 0.788782365201141, \"away\": 0.057497563126897466}, \"firstToScore\": {\"home\": 0.6578262737670248, \"away\": 0.2600103848881521, \"none\": 0.08216334134482307}, \"quality\": {\"homeMatches\": 8, \"awayMatches\": 8, \"level\": \"razoavel\"}}}, \"_off\": 1440, \"recent\": {\"home\": [{\"h\": \"Liverpool\", \"a\": \"Lazio\", \"hg\": 0, \"ag\": 3, \"side\": \"h\"}, {\"h\": \"Celta\", \"a\": \"Liverpool\", \"hg\": 1, \"ag\": 2, \"side\": \"a\"}, {\"h\": \"Cagliari\", \"a\": \"Liverpool\", \"hg\": 1, \"ag\": 1, \"side\": \"a\"}, {\"h\": \"Liverpool\", \"a\": \"Cremonese\", \"hg\": 0, \"ag\": 1, \"side\": \"h\"}, {\"h\": \"Liverpool\", \"a\": \"Atalanta\", \"hg\": 2, \"ag\": 0, \"side\": \"h\"}], \"away\": [{\"h\": \"Paris\", \"a\": \"Spurs\", \"hg\": 4, \"ag\": 3, \"side\": \"a\"}, {\"h\": \"Spurs\", \"a\": \"Ofi\", \"hg\": 2, \"ag\": 1, \"side\": \"h\"}, {\"h\": \"Spurs\", \"a\": \"Auxerre\", \"hg\": 4, \"ag\": 1, \"side\": \"h\"}, {\"h\": \"Lavallois\", \"a\": \"Spurs\", \"hg\": 1, \"ag\": 0, \"side\": \"a\"}, {\"h\": \"Lyon\", \"a\": \"Spurs\", \"hg\": 4, \"ag\": 0, \"side\": \"a\"}], \"h2h\": [{\"h\": \"Spurs\", \"a\": \"Liverpool\", \"hg\": 2, \"ag\": 2, \"side\": \"h\"}, {\"h\": \"Liverpool\", \"a\": \"Spurs\", \"hg\": 2, \"ag\": 0, \"side\": \"h\"}]}}, {\"id\": \"m3\", \"competition_id\": \"BL1\", \"competitions\": {\"name\": \"Bundesliga\", \"country\": \"Alemanha\"}, \"home_team\": \"Bayern\", \"away_team\": \"Dortmund\", \"kickoff_utc\": \"2026-10-19T18:00:00.000Z\", \"time_confirmed\": true, \"status\": \"NS\", \"analysis\": {\"created_at\": \"2026-10-17T10:28:36.671Z\", \"result\": {\"ok\": true, \"model\": \"poisson-v2\", \"lambda\": {\"home\": 1.7911031276415894, \"away\": 0.7079459002535925}, \"result\": {\"home\": 0.6331940506287799, \"draw\": 0.22441424212943503, \"away\": 0.1423917072417847}, \"totals\": {\"over_0_5\": 0.9178366586551767, \"over_1_5\": 0.7125064403387766, \"over_2_5\": 0.45594129909822373, \"over_3_5\": 0.24221834349522625, \"under_1_5\": 0.28749355966122325, \"under_2_5\": 0.5440587009017759, \"under_3_5\": 0.7577816565047735}, \"btts\": {\"yes\": 0.4227316294113733, \"no\": 0.5772683705886267}, \"halftime\": {\"home\": 0.4490070161327171, \"draw\": 0.4136970829705867, \"away\": 0.1372959008966963}, \"teamGoals\": {\"home\": {\"0\": 0.16677609283762268, \"1\": 0.2987131814973101, \"2\": 0.26751305682380094, \"3+\": 0.26699766884126624}, \"away\": {\"0\": 0.49265512159634595, \"1\": 0.3487731735730682, \"2\": 0.12345626917474412, \"3+\": 0.03511543565584174}}, \"exactScores\": [{\"score\": \"1-0\", \"p\": 0.14716301766019615}, {\"score\": \"2-0\", \"p\": 0.1317920706021759}, {\"score\": \"1-1\", \"p\": 0.10418345502148289}, {\"score\": \"2-1\", \"p\": 0.09330165606874243}, {\"score\": \"0-0\", \"p\": 0.08216334134482307}], \"productiveHalf\": {\"first\": 0.306829058916312, \"draw\": 0.267533496026392, \"second\": 0.42563744505729617}, \"bothHalves\": {\"home\": {\"yes\": 0.3467340505939754, \"no\": 0.6532659494060247}, \"away\": {\"yes\": 0.08798767227369067, \"no\": 0.9120123277263094}}, \"reach\": {\"ge3\": 0.45594129909822373, \"ge4\": 0.24221834349522625, \"ge5\": 0.10869230738558715, \"ge6\": 0.04195468523788899}, \"min10\": {\"home\": 0.15372007167196114, \"draw\": 0.788782365201141, \"away\": 0.057497563126897466}, \"firstToScore\": {\"home\": 0.6578262737670248, \"away\": 0.2600103848881521, \"none\": 0.08216334134482307}, \"quality\": {\"homeMatches\": 8, \"awayMatches\": 8, \"level\": \"razoavel\"}}}, \"_off\": 3000, \"recent\": {\"home\": [{\"h\": \"Bayern\", \"a\": \"Lazio\", \"hg\": 0, \"ag\": 3, \"side\": \"h\"}, {\"h\": \"Celta\", \"a\": \"Bayern\", \"hg\": 1, \"ag\": 2, \"side\": \"a\"}, {\"h\": \"Cagliari\", \"a\": \"Bayern\", \"hg\": 1, \"ag\": 1, \"side\": \"a\"}, {\"h\": \"Bayern\", \"a\": \"Cremonese\", \"hg\": 0, \"ag\": 1, \"side\": \"h\"}, {\"h\": \"Bayern\", \"a\": \"Atalanta\", \"hg\": 2, \"ag\": 0, \"side\": \"h\"}], \"away\": [{\"h\": \"Paris\", \"a\": \"Dortmund\", \"hg\": 4, \"ag\": 3, \"side\": \"a\"}, {\"h\": \"Dortmund\", \"a\": \"Ofi\", \"hg\": 2, \"ag\": 1, \"side\": \"h\"}, {\"h\": \"Dortmund\", \"a\": \"Auxerre\", \"hg\": 4, \"ag\": 1, \"side\": \"h\"}, {\"h\": \"Lavallois\", \"a\": \"Dortmund\", \"hg\": 1, \"ag\": 0, \"side\": \"a\"}, {\"h\": \"Lyon\", \"a\": \"Dortmund\", \"hg\": 4, \"ag\": 0, \"side\": \"a\"}], \"h2h\": [{\"h\": \"Dortmund\", \"a\": \"Bayern\", \"hg\": 2, \"ag\": 2, \"side\": \"h\"}, {\"h\": \"Bayern\", \"a\": \"Dortmund\", \"hg\": 2, \"ag\": 0, \"side\": \"h\"}]}}, {\"id\": \"m4\", \"competition_id\": \"SA\", \"competitions\": {\"name\": \"S\u00e9rie A\", \"country\": \"It\u00e1lia\"}, \"home_team\": \"Inter\", \"away_team\": \"Milan\", \"kickoff_utc\": \"2026-10-29T18:00:00.000Z\", \"time_confirmed\": true, \"status\": \"NS\", \"analysis\": {\"created_at\": \"2026-10-17T10:28:36.671Z\", \"result\": {\"ok\": true, \"model\": \"poisson-v2\", \"lambda\": {\"home\": 1.7911031276415894, \"away\": 0.7079459002535925}, \"result\": {\"home\": 0.6331940506287799, \"draw\": 0.22441424212943503, \"away\": 0.1423917072417847}, \"totals\": {\"over_0_5\": 0.9178366586551767, \"over_1_5\": 0.7125064403387766, \"over_2_5\": 0.45594129909822373, \"over_3_5\": 0.24221834349522625, \"under_1_5\": 0.28749355966122325, \"under_2_5\": 0.5440587009017759, \"under_3_5\": 0.7577816565047735}, \"btts\": {\"yes\": 0.4227316294113733, \"no\": 0.5772683705886267}, \"halftime\": {\"home\": 0.4490070161327171, \"draw\": 0.4136970829705867, \"away\": 0.1372959008966963}, \"teamGoals\": {\"home\": {\"0\": 0.16677609283762268, \"1\": 0.2987131814973101, \"2\": 0.26751305682380094, \"3+\": 0.26699766884126624}, \"away\": {\"0\": 0.49265512159634595, \"1\": 0.3487731735730682, \"2\": 0.12345626917474412, \"3+\": 0.03511543565584174}}, \"exactScores\": [{\"score\": \"1-0\", \"p\": 0.14716301766019615}, {\"score\": \"2-0\", \"p\": 0.1317920706021759}, {\"score\": \"1-1\", \"p\": 0.10418345502148289}, {\"score\": \"2-1\", \"p\": 0.09330165606874243}, {\"score\": \"0-0\", \"p\": 0.08216334134482307}], \"productiveHalf\": {\"first\": 0.306829058916312, \"draw\": 0.267533496026392, \"second\": 0.42563744505729617}, \"bothHalves\": {\"home\": {\"yes\": 0.3467340505939754, \"no\": 0.6532659494060247}, \"away\": {\"yes\": 0.08798767227369067, \"no\": 0.9120123277263094}}, \"reach\": {\"ge3\": 0.45594129909822373, \"ge4\": 0.24221834349522625, \"ge5\": 0.10869230738558715, \"ge6\": 0.04195468523788899}, \"min10\": {\"home\": 0.15372007167196114, \"draw\": 0.788782365201141, \"away\": 0.057497563126897466}, \"firstToScore\": {\"home\": 0.6578262737670248, \"away\": 0.2600103848881521, \"none\": 0.08216334134482307}, \"quality\": {\"homeMatches\": 8, \"awayMatches\": 8, \"level\": \"razoavel\"}}}, \"_off\": 7200, \"recent\": {\"home\": [{\"h\": \"Inter\", \"a\": \"Lazio\", \"hg\": 0, \"ag\": 3, \"side\": \"h\"}, {\"h\": \"Celta\", \"a\": \"Inter\", \"hg\": 1, \"ag\": 2, \"side\": \"a\"}, {\"h\": \"Cagliari\", \"a\": \"Inter\", \"hg\": 1, \"ag\": 1, \"side\": \"a\"}, {\"h\": \"Inter\", \"a\": \"Cremonese\", \"hg\": 0, \"ag\": 1, \"side\": \"h\"}, {\"h\": \"Inter\", \"a\": \"Atalanta\", \"hg\": 2, \"ag\": 0, \"side\": \"h\"}], \"away\": [{\"h\": \"Paris\", \"a\": \"Milan\", \"hg\": 4, \"ag\": 3, \"side\": \"a\"}, {\"h\": \"Milan\", \"a\": \"Ofi\", \"hg\": 2, \"ag\": 1, \"side\": \"h\"}, {\"h\": \"Milan\", \"a\": \"Auxerre\", \"hg\": 4, \"ag\": 1, \"side\": \"h\"}, {\"h\": \"Lavallois\", \"a\": \"Milan\", \"hg\": 1, \"ag\": 0, \"side\": \"a\"}, {\"h\": \"Lyon\", \"a\": \"Milan\", \"hg\": 4, \"ag\": 0, \"side\": \"a\"}], \"h2h\": [{\"h\": \"Milan\", \"a\": \"Inter\", \"hg\": 2, \"ag\": 2, \"side\": \"h\"}, {\"h\": \"Inter\", \"a\": \"Milan\", \"hg\": 2, \"ag\": 0, \"side\": \"h\"}]}}, {\"id\": \"m5\", \"competition_id\": \"PD\", \"competitions\": {\"name\": \"La Liga\", \"country\": \"Espanha\"}, \"home_team\": \"Valencia\", \"away_team\": \"Betis\", \"kickoff_utc\": \"2026-11-15T18:00:00.000Z\", \"time_confirmed\": true, \"status\": \"NS\", \"analysis\": {\"created_at\": \"2026-10-17T10:28:36.673Z\", \"result\": {\"ok\": true, \"model\": \"poisson-v2\", \"lambda\": {\"home\": 1.7911031276415894, \"away\": 0.7079459002535925}, \"result\": {\"home\": 0.6331940506287799, \"draw\": 0.22441424212943503, \"away\": 0.1423917072417847}, \"totals\": {\"over_0_5\": 0.9178366586551767, \"over_1_5\": 0.7125064403387766, \"over_2_5\": 0.45594129909822373, \"over_3_5\": 0.24221834349522625, \"under_1_5\": 0.28749355966122325, \"under_2_5\": 0.5440587009017759, \"under_3_5\": 0.7577816565047735}, \"btts\": {\"yes\": 0.4227316294113733, \"no\": 0.5772683705886267}, \"halftime\": {\"home\": 0.4490070161327171, \"draw\": 0.4136970829705867, \"away\": 0.1372959008966963}, \"teamGoals\": {\"home\": {\"0\": 0.16677609283762268, \"1\": 0.2987131814973101, \"2\": 0.26751305682380094, \"3+\": 0.26699766884126624}, \"away\": {\"0\": 0.49265512159634595, \"1\": 0.3487731735730682, \"2\": 0.12345626917474412, \"3+\": 0.03511543565584174}}, \"exactScores\": [{\"score\": \"1-0\", \"p\": 0.14716301766019615}, {\"score\": \"2-0\", \"p\": 0.1317920706021759}, {\"score\": \"1-1\", \"p\": 0.10418345502148289}, {\"score\": \"2-1\", \"p\": 0.09330165606874243}, {\"score\": \"0-0\", \"p\": 0.08216334134482307}], \"productiveHalf\": {\"first\": 0.306829058916312, \"draw\": 0.267533496026392, \"second\": 0.42563744505729617}, \"bothHalves\": {\"home\": {\"yes\": 0.3467340505939754, \"no\": 0.6532659494060247}, \"away\": {\"yes\": 0.08798767227369067, \"no\": 0.9120123277263094}}, \"reach\": {\"ge3\": 0.45594129909822373, \"ge4\": 0.24221834349522625, \"ge5\": 0.10869230738558715, \"ge6\": 0.04195468523788899}, \"min10\": {\"home\": 0.15372007167196114, \"draw\": 0.788782365201141, \"away\": 0.057497563126897466}, \"firstToScore\": {\"home\": 0.6578262737670248, \"away\": 0.2600103848881521, \"none\": 0.08216334134482307}, \"quality\": {\"homeMatches\": 8, \"awayMatches\": 8, \"level\": \"razoavel\"}}}, \"_off\": 17280, \"recent\": {\"home\": [{\"h\": \"Valencia\", \"a\": \"Lazio\", \"hg\": 0, \"ag\": 3, \"side\": \"h\"}, {\"h\": \"Celta\", \"a\": \"Valencia\", \"hg\": 1, \"ag\": 2, \"side\": \"a\"}, {\"h\": \"Cagliari\", \"a\": \"Valencia\", \"hg\": 1, \"ag\": 1, \"side\": \"a\"}, {\"h\": \"Valencia\", \"a\": \"Cremonese\", \"hg\": 0, \"ag\": 1, \"side\": \"h\"}, {\"h\": \"Valencia\", \"a\": \"Atalanta\", \"hg\": 2, \"ag\": 0, \"side\": \"h\"}], \"away\": [{\"h\": \"Paris\", \"a\": \"Betis\", \"hg\": 4, \"ag\": 3, \"side\": \"a\"}, {\"h\": \"Betis\", \"a\": \"Ofi\", \"hg\": 2, \"ag\": 1, \"side\": \"h\"}, {\"h\": \"Betis\", \"a\": \"Auxerre\", \"hg\": 4, \"ag\": 1, \"side\": \"h\"}, {\"h\": \"Lavallois\", \"a\": \"Betis\", \"hg\": 1, \"ag\": 0, \"side\": \"a\"}, {\"h\": \"Lyon\", \"a\": \"Betis\", \"hg\": 4, \"ag\": 0, \"side\": \"a\"}], \"h2h\": [{\"h\": \"Betis\", \"a\": \"Valencia\", \"hg\": 2, \"ag\": 2, \"side\": \"h\"}, {\"h\": \"Valencia\", \"a\": \"Betis\", \"hg\": 2, \"ag\": 0, \"side\": \"h\"}]}}], \"history\": [{\"id\": \"h1\", \"competition_id\": \"PD\", \"competitions\": {\"name\": \"La Liga\", \"country\": \"Espanha\"}, \"home_team\": \"Barcelona\", \"away_team\": \"Real Madrid\", \"kickoff_utc\": \"2026-10-16T18:00:00.000Z\", \"time_confirmed\": true, \"status\": \"FT\", \"home_goals\": 3, \"away_goals\": 1, \"home_ht\": 1, \"away_ht\": 0, \"analysis\": {\"created_at\": \"2026-10-17T10:28:36.662Z\", \"result\": {\"ok\": true, \"model\": \"poisson-v2\", \"lambda\": {\"home\": 1.7911031276415894, \"away\": 0.7079459002535925}, \"result\": {\"home\": 0.6331940506287799, \"draw\": 0.22441424212943503, \"away\": 0.1423917072417847}, \"totals\": {\"over_0_5\": 0.9178366586551767, \"over_1_5\": 0.7125064403387766, \"over_2_5\": 0.45594129909822373, \"over_3_5\": 0.24221834349522625, \"under_1_5\": 0.28749355966122325, \"under_2_5\": 0.5440587009017759, \"under_3_5\": 0.7577816565047735}, \"btts\": {\"yes\": 0.4227316294113733, \"no\": 0.5772683705886267}, \"halftime\": {\"home\": 0.4490070161327171, \"draw\": 0.4136970829705867, \"away\": 0.1372959008966963}, \"teamGoals\": {\"home\": {\"0\": 0.16677609283762268, \"1\": 0.2987131814973101, \"2\": 0.26751305682380094, \"3+\": 0.26699766884126624}, \"away\": {\"0\": 0.49265512159634595, \"1\": 0.3487731735730682, \"2\": 0.12345626917474412, \"3+\": 0.03511543565584174}}, \"exactScores\": [{\"score\": \"1-0\", \"p\": 0.14716301766019615}, {\"score\": \"2-0\", \"p\": 0.1317920706021759}, {\"score\": \"1-1\", \"p\": 0.10418345502148289}, {\"score\": \"2-1\", \"p\": 0.09330165606874243}, {\"score\": \"0-0\", \"p\": 0.08216334134482307}], \"productiveHalf\": {\"first\": 0.306829058916312, \"draw\": 0.267533496026392, \"second\": 0.42563744505729617}, \"bothHalves\": {\"home\": {\"yes\": 0.3467340505939754, \"no\": 0.6532659494060247}, \"away\": {\"yes\": 0.08798767227369067, \"no\": 0.9120123277263094}}, \"reach\": {\"ge3\": 0.45594129909822373, \"ge4\": 0.24221834349522625, \"ge5\": 0.10869230738558715, \"ge6\": 0.04195468523788899}, \"min10\": {\"home\": 0.15372007167196114, \"draw\": 0.788782365201141, \"away\": 0.057497563126897466}, \"firstToScore\": {\"home\": 0.6578262737670248, \"away\": 0.2600103848881521, \"none\": 0.08216334134482307}, \"quality\": {\"homeMatches\": 8, \"awayMatches\": 8, \"level\": \"razoavel\"}}}, \"_off\": -1560}, {\"id\": \"h2\", \"competition_id\": \"PL\", \"competitions\": {\"name\": \"Premier League\", \"country\": \"Inglaterra\"}, \"home_team\": \"Man City\", \"away_team\": \"Arsenal\", \"kickoff_utc\": \"2026-10-15T18:00:00.000Z\", \"time_confirmed\": true, \"status\": \"FT\", \"home_goals\": 1, \"away_goals\": 3, \"home_ht\": 0, \"away_ht\": 2, \"analysis\": {\"created_at\": \"2026-10-17T10:28:36.667Z\", \"result\": {\"ok\": true, \"model\": \"poisson-v2\", \"lambda\": {\"home\": 1.7911031276415894, \"away\": 0.7079459002535925}, \"result\": {\"home\": 0.6331940506287799, \"draw\": 0.22441424212943503, \"away\": 0.1423917072417847}, \"totals\": {\"over_0_5\": 0.9178366586551767, \"over_1_5\": 0.7125064403387766, \"over_2_5\": 0.45594129909822373, \"over_3_5\": 0.24221834349522625, \"under_1_5\": 0.28749355966122325, \"under_2_5\": 0.5440587009017759, \"under_3_5\": 0.7577816565047735}, \"btts\": {\"yes\": 0.4227316294113733, \"no\": 0.5772683705886267}, \"halftime\": {\"home\": 0.4490070161327171, \"draw\": 0.4136970829705867, \"away\": 0.1372959008966963}, \"teamGoals\": {\"home\": {\"0\": 0.16677609283762268, \"1\": 0.2987131814973101, \"2\": 0.26751305682380094, \"3+\": 0.26699766884126624}, \"away\": {\"0\": 0.49265512159634595, \"1\": 0.3487731735730682, \"2\": 0.12345626917474412, \"3+\": 0.03511543565584174}}, \"exactScores\": [{\"score\": \"1-0\", \"p\": 0.14716301766019615}, {\"score\": \"2-0\", \"p\": 0.1317920706021759}, {\"score\": \"1-1\", \"p\": 0.10418345502148289}, {\"score\": \"2-1\", \"p\": 0.09330165606874243}, {\"score\": \"0-0\", \"p\": 0.08216334134482307}], \"productiveHalf\": {\"first\": 0.306829058916312, \"draw\": 0.267533496026392, \"second\": 0.42563744505729617}, \"bothHalves\": {\"home\": {\"yes\": 0.3467340505939754, \"no\": 0.6532659494060247}, \"away\": {\"yes\": 0.08798767227369067, \"no\": 0.9120123277263094}}, \"reach\": {\"ge3\": 0.45594129909822373, \"ge4\": 0.24221834349522625, \"ge5\": 0.10869230738558715, \"ge6\": 0.04195468523788899}, \"min10\": {\"home\": 0.15372007167196114, \"draw\": 0.788782365201141, \"away\": 0.057497563126897466}, \"firstToScore\": {\"home\": 0.6578262737670248, \"away\": 0.2600103848881521, \"none\": 0.08216334134482307}, \"quality\": {\"homeMatches\": 8, \"awayMatches\": 8, \"level\": \"razoavel\"}}}, \"_off\": -3120}, {\"id\": \"h3\", \"competition_id\": \"PL\", \"competitions\": {\"name\": \"Premier League\", \"country\": \"Inglaterra\"}, \"home_team\": \"Chelsea\", \"away_team\": \"Everton\", \"kickoff_utc\": \"2026-10-14T18:00:00.000Z\", \"time_confirmed\": true, \"status\": \"FT\", \"home_goals\": 0, \"away_goals\": 0, \"home_ht\": 0, \"away_ht\": 0, \"analysis\": {\"created_at\": \"2026-10-17T10:28:36.667Z\", \"result\": {\"ok\": true, \"model\": \"poisson-v2\", \"lambda\": {\"home\": 1.7911031276415894, \"away\": 0.7079459002535925}, \"result\": {\"home\": 0.6331940506287799, \"draw\": 0.22441424212943503, \"away\": 0.1423917072417847}, \"totals\": {\"over_0_5\": 0.9178366586551767, \"over_1_5\": 0.7125064403387766, \"over_2_5\": 0.45594129909822373, \"over_3_5\": 0.24221834349522625, \"under_1_5\": 0.28749355966122325, \"under_2_5\": 0.5440587009017759, \"under_3_5\": 0.7577816565047735}, \"btts\": {\"yes\": 0.4227316294113733, \"no\": 0.5772683705886267}, \"halftime\": {\"home\": 0.4490070161327171, \"draw\": 0.4136970829705867, \"away\": 0.1372959008966963}, \"teamGoals\": {\"home\": {\"0\": 0.16677609283762268, \"1\": 0.2987131814973101, \"2\": 0.26751305682380094, \"3+\": 0.26699766884126624}, \"away\": {\"0\": 0.49265512159634595, \"1\": 0.3487731735730682, \"2\": 0.12345626917474412, \"3+\": 0.03511543565584174}}, \"exactScores\": [{\"score\": \"1-0\", \"p\": 0.14716301766019615}, {\"score\": \"2-0\", \"p\": 0.1317920706021759}, {\"score\": \"1-1\", \"p\": 0.10418345502148289}, {\"score\": \"2-1\", \"p\": 0.09330165606874243}, {\"score\": \"0-0\", \"p\": 0.08216334134482307}], \"productiveHalf\": {\"first\": 0.306829058916312, \"draw\": 0.267533496026392, \"second\": 0.42563744505729617}, \"bothHalves\": {\"home\": {\"yes\": 0.3467340505939754, \"no\": 0.6532659494060247}, \"away\": {\"yes\": 0.08798767227369067, \"no\": 0.9120123277263094}}, \"reach\": {\"ge3\": 0.45594129909822373, \"ge4\": 0.24221834349522625, \"ge5\": 0.10869230738558715, \"ge6\": 0.04195468523788899}, \"min10\": {\"home\": 0.15372007167196114, \"draw\": 0.788782365201141, \"away\": 0.057497563126897466}, \"firstToScore\": {\"home\": 0.6578262737670248, \"away\": 0.2600103848881521, \"none\": 0.08216334134482307}, \"quality\": {\"homeMatches\": 8, \"awayMatches\": 8, \"level\": \"razoavel\"}}}, \"_off\": -4680}], \"leagues\": [{\"id\": \"CL\", \"name\": \"CL\", \"country\": \"\", \"ok\": true}, {\"id\": \"PL\", \"name\": \"PL\", \"country\": \"\", \"ok\": true}, {\"id\": \"PD\", \"name\": \"PD\", \"country\": \"\", \"ok\": true}, {\"id\": \"ELC\", \"name\": \"ELC\", \"country\": \"\", \"ok\": true}, {\"id\": \"BL1\", \"name\": \"BL1\", \"country\": \"\", \"ok\": true}, {\"id\": \"SA\", \"name\": \"SA\", \"country\": \"\", \"ok\": true}, {\"id\": \"DED\", \"name\": \"DED\", \"country\": \"\", \"ok\": true}, {\"id\": \"PPL\", \"name\": \"PPL\", \"country\": \"\", \"ok\": true}, {\"id\": \"BSA\", \"name\": \"BSA\", \"country\": \"\", \"ok\": true}, {\"id\": \"FL1\", \"name\": \"FL1\", \"country\": \"\", \"ok\": true}], \"lastSuccessAt\": \"2026-10-17T10:28:36.673Z\", \"lastFinalAt\": \"2026-10-17T04:28:36.654Z\"}"), n = Date.now(); for (const m of [...d.matches, ...d.history]){ m.kickoff_utc = new Date(n + m._off * 60000).toISOString(); delete m._off; } d.lastSuccessAt = new Date(n - 600000).toISOString(); return d; })();
const DEMO_USER = { id: "demo", name: "Visitante", email: "demo@demo", photo: "", friends: [], admin: true, banUntil: 0, created: Date.now() - 400 * 86400e3 };
/* =====================================================================
   CONTAS, PERFIL, AMIGOS, CHAT E PAINEL
   ATENÇÃO: nesta versão os dados ficam no armazenamento do próprio aparelho
   (localStorage). Serve para testar e demonstrar. Para os utilizadores se
   verem entre aparelhos diferentes, e para o e-mail com código ser enviado
   de verdade, é preciso ligar um servidor (ver MAIL_ENDPOINT e as funções
   reloadDB/saveDB, que são o único ponto de acesso aos dados).
   ===================================================================== */
const ADMIN_EMAIL = "abelmaridao@gmail.com";
const MAIL_ENDPOINT = null; // URL do teu serviço de envio de e-mail; null = modo demonstração (código mostrado no ecrã)
const API_URL = "https://contas.abelpemba939.workers.dev"; // endereço do accounts-worker.js (ex.: "https://contas.teu-nome.workers.dev"). null = modo local (só neste aparelho)
const DBK = "eb_db_v1", SESK = "eb_session", MEK = "eb_me";
const emptyDB = () => ({ users: [], resets: {}, allow: [], tadmins: [], deleted: [] });
const rawDB = () => { const d = store.get(DBK, null); if (!(d && d.users)) return emptyDB(); if (!Array.isArray(d.allow)) d.allow = []; if (!Array.isArray(d.tadmins)) d.tadmins = []; if (!Array.isArray(d.deleted)) d.deleted = []; return d; };
let DBc = rawDB();
const saveDB = () => { if (!API_URL) store.set(DBK, DBc); };
const reloadDB = () => { if (!API_URL) DBc = rawDB(); };
// ligação ao servidor de contas (modo partilhado entre aparelhos)
async function api(op, body){
  try {
    const t = store.get(SESK, null);
    const r = await fetch(API_URL.replace(/\/$/, "") + "/" + op, { method: "POST", headers: { "Content-Type": "application/json", ...(t ? { Authorization: "Bearer " + t } : {}) }, body: JSON.stringify(body || {}) });
    let d = {}; try { d = await r.json(); } catch {}
    return { ...d, status: r.status };
  } catch { return { status: 0, error: "Sem ligação ao servidor. Tenta outra vez." }; }
}
const banMsg = (t, who) => `${who} está banida até ${tm(t)}.`;
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const rnd = () => { try { return crypto.getRandomValues(new Uint32Array(1))[0]; } catch { return Math.floor(Math.random() * 4294967295); } };
const validEmail = e => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e);
const validName = n => n.length >= 3 && n.length <= 20 && /^[\p{L}\p{N}_. -]+$/u.test(n);
const tm = t => { const iso = new Date(t).toISOString(); return dayKey(iso) === dayKey(new Date().toISOString()) ? fmtHour(iso) : fmtFull(iso); };
const userById = id => DBc.users.find(x => x.id === id);
const WHATSAPP_URL = "https://chat.whatsapp.com/C8DfJGozZr90IlVDU8H1Kt?s=cl&p=a&mlu=4&ilr=4"; // link do grupo de WhatsApp (ex.: "https://chat.whatsapp.com/xxxxxxxx")
const DAYMS = 86400e3;
const vHid = new Set(); store.set("hiddenVip", []); // jogos do VIP já não se apagam: os que tinham sido removidos voltam aos seus dias
const saveVHid = () => {};
const VDAYS = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 15, 20, 25, 30];
const vdayOpts = (sel, max = 99) => VDAYS.filter(n => n <= max).map(n => `<option value="${n}"${n === sel ? " selected" : ""}>${n} ${n === 1 ? "dia" : "dias"}</option>`).join("");
const allowOf = e => (DBc.allow || []).find(a => a.email === e);
// acesso do utilizador: validade (0 = sem fim) e permissão de ver o VIP; o administrador tem sempre tudo
function access(u){
  if (!u) return { exp: 0, vip: false };
  if (u.admin) return { exp: 0, vip: true };
  if (API_URL) return { exp: u.exp || 0, vip: (u.exp || 0) > Date.now() };
  const a = allowOf(u.email); return a ? { exp: a.exp || 0, vip: a.exp > Date.now() } : { exp: 0, vip: false };
}
const canVip = u => !!u && access(u).vip;
const expMsg = t => `O teu acesso terminou em ${fmtFull(new Date(t).toISOString())}. Fala com o administrador.`;

function clearF(){ S.soc.f = { id: "", email: "", name: "", pw: "", code: "", pw2: "" }; }
S.soc = { mode: "login", err: "", info: "", mail: null, was: false, showSearch: false, q: "", pwForm: false, pmsg: null, banFor: null,
  f: { id: "", email: "", name: "", pw: "", code: "", pw2: "" } };

async function hashPw(pw, salt){
  try {
    const enc = new TextEncoder();
    const k = await crypto.subtle.importKey("raw", enc.encode(pw), "PBKDF2", false, ["deriveBits"]);
    const b = await crypto.subtle.deriveBits({ name: "PBKDF2", salt: enc.encode(salt), iterations: 100000, hash: "SHA-256" }, k, 256);
    return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, "0")).join("");
  } catch {
    let h = 2166136261; const s = salt + "|" + pw;
    for (let i = 0; i < s.length; i++){ h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
    return "f" + (h >>> 0).toString(16);
  }
}
// utilizador com sessão válida (conta existe e não está banida)
function cur(){ return DEMO_USER; }
function cur_original(){
  if (API_URL){
    const m = S.soc.me; if (!m) return null;
    if (m.banUntil > Date.now()){ dropSession(banMsg(m.banUntil, "A tua conta")); return null; }
    return m;
  }
  const id = store.get(SESK, null); if (!id) return null;
  const u = userById(id);
  if (!u){ store.set(SESK, null); return null; }
  if (u.banUntil > Date.now()){ store.set(SESK, null); S.soc.mode = "login"; S.soc.err = `A tua conta está banida até ${tm(u.banUntil)}.`; return null; }
  return u;
}
function dropSession(msg){ store.set(SESK, null); store.set(MEK, null); S.soc.me = null; S.pwPlain = ""; S.soc.mode = "login"; S.soc.err = msg || ""; S.soc.info = ""; clearF(); S.view = "home"; S.drawer = false; }
const startSession = r => { store.set(SESK, r.token); store.set(MEK, r.user); S.soc.me = r.user; S.pwPlain = S.soc.f.pw; clearF(); S.soc.err = ""; S.soc.info = ""; S.view = "home"; startBusy(); render(); };
if (API_URL){ try { store.set(DBK, null); if (!store.get(MEK, null)) store.set(SESK, null); } catch (e) {} } // contas antigas (só no aparelho) são descartadas: só valem contas criadas no servidor
if (API_URL) S.soc.me = store.get(SESK, null) ? store.get(MEK, null) : null;
const avatar = (u, s = 40) => u.photo ? `<img class="av" style="--s:${s}px" src="${esc(u.photo)}" alt="">` : `<span class="av" style="--s:${s}px" aria-hidden="true">${esc((u.name || "?").trim().charAt(0).toUpperCase())}</span>`;

/* ----- ecrã de entrada ----- */
function authView(){
  const s = S.soc, f = s.f, m = s.mode;
  const fld = (k, label, type = "text", ac = "off") => { const i = `<input id="a-${k}" data-f="${k}" name="x${k}${Math.random().toString(36).slice(2, 6)}" type="${type}" autocomplete="${type === "password" ? "new-password" : "off"}" autocapitalize="none" spellcheck="false" value="${esc(f[k])}">`; return `<label class="fl" for="a-${k}">${label}</label>${type === "password" ? eyeWrap(i) : i}`; };
  const lnk = (v, t) => `<button type="button" class="link" data-s="mode" data-v="${v}">${t}</button>`;
  let title, body;
  if (m === "register"){
    title = "Criar conta";
    body = `<form novalidate data-sf="register">${fld("email", "E-mail (tem de ser válido)", "email", "email")}${fld("name", "Nome de utilizador", "text", "username")}${fld("pw", "Palavra-passe (mínimo 6 caracteres)", "password", "new-password")}
      <button class="btn" style="width:100%;margin-top:14px;padding:13px">Criar conta</button></form>${lnk("login", "Já tenho conta. Entrar")}`;
  } else {
    title = "Entrar";
    body = `<form novalidate data-sf="login">${fld("id", "E-mail", "text", "username")}${fld("pw", "Palavra-passe", "password", "current-password")}
      <button class="btn" style="width:100%;margin-top:14px;padding:13px">Entrar</button></form>${lnk("register", "Criar conta")}`;
  }
  return `<header class="top"><div style="width:40px"></div><div class="brand"><span class="mark" aria-hidden="true">🦁</span><span>Elephalpit <em>Bet</em></span></div><div style="width:40px"></div></header>
    <div class="auth"><h1 class="ttl">${title}</h1>
    ${s.err ? `<div class="msg" role="alert">${esc(s.err)}</div>` : ""}${s.info ? `<div class="msg ok">${esc(s.info)}</div>` : ""}
    <div class="card">${body}</div></div>`;
}
const err = t => { S.soc.err = t; S.soc.info = ""; render(); return false; };
async function doRegister(){
  const f = S.soc.f, e = f.email.trim().toLowerCase(), n = f.name.trim();
  if (!validEmail(e)) return err("Escreve um e-mail válido.");
  if (!validName(n)) return err("O nome de utilizador deve ter 3 a 20 caracteres (letras, números, espaço, _ . -).");
  if (f.pw.length < 6) return err("A palavra-passe deve ter pelo menos 6 caracteres.");
  const salt = uid(), hash = await hashPw(f.pw, salt);
  if (API_URL){
    const r = await api("register", { email: e, name: n, salt, hash });
    return r.ok ? startSession(r) : err(r.error || "Não foi possível criar a conta.");
  }
  reloadDB();
  if ((DBc.deleted || []).includes(e)) return err("Este e-mail foi removido pelo administrador e não pode voltar a ser usado.");
  if (DBc.users.some(u => u.email === e)) return err("Este e-mail já está registado.");
  if (DBc.users.some(u => norm(u.name) === norm(n))) return err("Este nome de utilizador já existe.");
  const u = { id: uid(), email: e, name: n, salt, hash, photo: "", friends: [], admin: e === ADMIN_EMAIL, banUntil: 0, created: Date.now() };
  DBc.users.push(u); saveDB(); store.set(SESK, u.id);
  S.pwPlain = S.soc.f.pw; clearF(); S.soc.err = ""; S.soc.info = ""; S.view = "home"; startBusy(); render();
}
async function doLogin(){
  const { id, pw } = S.soc.f, key = id.trim().toLowerCase();
  if (!validEmail(key) || !pw) return err("Escreve o e-mail e a palavra-passe.");
  if (API_URL){
    const s1 = await api("salt", { id: key }); if (!s1.salt) return err(s1.error || "Sem ligação ao servidor. Tenta outra vez.");
    const r = await api("login", { id: key, hash: await hashPw(pw, s1.salt) });
    if (r.ok) return startSession(r);
    return err(r.error === "banned" ? banMsg(r.banUntil, "Esta conta") : (r.error || "E-mail ou palavra-passe incorretos."));
  }
  reloadDB();
  const u = DBc.users.find(x => x.email === key);
  const ok = u && u.hash === await hashPw(pw, u.salt);
  if (!ok) return err("E-mail ou palavra-passe incorretos.");
  if (u.banUntil > Date.now()) return err(`Esta conta está banida até ${tm(u.banUntil)}.`);
  store.set(SESK, u.id); S.pwPlain = S.soc.f.pw; clearF(); S.soc.err = ""; S.soc.info = ""; S.view = "home"; startBusy(); render();
}
async function sendMail(to, code){
  if (MAIL_ENDPOINT){
    try { const r = await fetch(MAIL_ENDPOINT, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ to, subject: "Código de recuperação - Elephalpit Bet", code }) }); if (r.ok) return; } catch {}
  }
  S.soc.mail = { to, code }; // modo demonstração
}
async function doForgot1(){
  const e = S.soc.f.email.trim().toLowerCase();
  if (!validEmail(e)) return err("Escreve um e-mail válido.");
  S.soc.mail = null;
  if (API_URL){
    const r = await api("forgot1", { email: e }); if (!r.ok) return err(r.error || "Sem ligação ao servidor.");
    if (r.demoCode) S.soc.mail = { to: e, code: r.demoCode };
  } else {
  reloadDB();
  if (DBc.users.some(u => u.email === e)){
    const code = String(rnd() % 900000 + 100000), h = await hashPw(code, e);
    reloadDB(); DBc.resets[e] = { h, exp: Date.now() + 600000, tries: 0 }; saveDB();
    await sendMail(e, code);
  }
  }
  S.soc.mode = "forgot2"; S.soc.err = "";
  S.soc.info = "Se este e-mail estiver registado, foi enviado um código de 6 dígitos (válido 10 minutos).";
  render();
}
async function doForgot2(){
  const e = S.soc.f.email.trim().toLowerCase(), code = S.soc.f.code.trim(), pw2 = S.soc.f.pw2;
  if (pw2.length < 6) return err("A nova palavra-passe deve ter pelo menos 6 caracteres.");
  const h = await hashPw(code, e), salt = uid(), nh = await hashPw(pw2, salt);
  if (API_URL){
    const r = await api("forgot2", { email: e, code, salt, hash: nh }); if (!r.ok) return err(r.error || "Sem ligação ao servidor.");
    Object.assign(S.soc.f, { id: e, pw: "", code: "", pw2: "" }); S.soc.mail = null; S.soc.mode = "login"; S.soc.err = "";
    S.soc.info = "Palavra-passe alterada. Já podes entrar."; return render();
  }
  reloadDB();
  const r = DBc.resets[e];
  if (!r || r.exp < Date.now()) return err("Código inválido ou expirado. Pede um novo.");
  if (r.tries >= 5){ delete DBc.resets[e]; saveDB(); return err("Demasiadas tentativas. Pede um novo código."); }
  if (r.h !== h){ r.tries++; saveDB(); return err("Código incorreto."); }
  const u = DBc.users.find(x => x.email === e); if (!u) return err("Conta não encontrada.");
  u.salt = salt; u.hash = nh; delete DBc.resets[e]; saveDB();
  Object.assign(S.soc.f, { id: e, pw: "", code: "", pw2: "" }); S.soc.mail = null; S.soc.mode = "login"; S.soc.err = "";
  S.soc.info = "Palavra-passe alterada. Já podes entrar."; render();
}

/* ----- painel do administrador ----- */
// papéis: administrador principal (u.admin) e administrador temporário (convidado, com dias)
const tadmOf = u => { if (!u || u.admin) return { on: false, exp: 0 }; const exp = API_URL ? (u.texp || 0) : (((DBc.tadmins || []).find(t => t.email === u.email) || {}).exp || 0); return { on: exp > Date.now(), exp }; };
const isAdm = u => !!u && (!!u.admin || tadmOf(u).on);
const tadmLeft = u => (u && u.admin) ? 30 : Math.max(0, Math.ceil((tadmOf(u).exp - Date.now()) / DAYMS)); // dias que ainda pode convidar
const dword = n => n === 1 ? "dia" : "dias";
function scopeUsers(me){ // principal vê todos; temporário só os que convidou
  if (me.admin) return DBc.users;
  const mine = new Set((DBc.allow || []).filter(a => a.by === me.email).map(a => a.email));
  return DBc.users.filter(u => mine.has(u.email));
}
function statHtml(me){
  const now = Date.now(), us = scopeUsers(me), al = DBc.allow || [];
  const vips = us.filter(u => { const a = al.find(x => x.email === u.email); return a && a.exp > now; }).length;
  return `<div><b>${us.length}</b>${me.admin ? "utilizadores" : "convidados"}</div><div><b>${vips}</b>com VIP</div><div><b>${us.filter(x => x.banUntil > now).length}</b>banidos</div>`;
}
function tadmRows(){
  const now = Date.now(), l = (DBc.tadmins || []).filter(t => t.exp > now);
  if (!l.length) return `<p class="note" style="margin:6px 0 0">Nenhum administrador temporário.</p>`;
  return l.map(t => { const d = Math.max(1, Math.ceil((t.exp - now) / DAYMS)); return `<div class="urow"><b>${esc(t.email)}</b><br><small style="color:var(--mute)">restam ${d} ${dword(d)}</small><div class="row"><button class="mbtn" style="background:var(--bad)" data-s="untadm" data-e="${esc(t.email)}">Remover</button></div></div>`; }).join("");
}
function adminView(){
  const me = cur(), s = S.soc;
  if (!isAdm(me)) return `<div class="empty">Sem permissão.</div>`;
  const left = tadmLeft(me), main = !!me.admin;
  const target = main && s.banFor && userById(s.banFor);
  const banForm = target ? `<form class="card" data-sf="ban"><b>Banir ${esc(target.name)}</b><div class="row" style="margin-top:8px"><input name="n" type="number" min="1" max="3650" value="1" aria-label="Duração"><select name="u" aria-label="Unidade"><option value="60000">minutos</option><option value="3600000" selected>horas</option><option value="86400000">dias</option></select></div>
    <div class="row" style="margin-top:10px"><button class="btn">Confirmar ban</button><button type="button" class="btn alt" data-s="banx">Cancelar</button></div></form>` : "";
  const addForm = left > 0 ? `<form class="card" data-sf="allow" novalidate><b>Convidar para o VIP</b>
    <label class="fl" for="al-e">E-mail do utilizador</label><input id="al-e" name="e" type="email" autocomplete="off">
    <label class="fl" for="al-d">Dias de VIP</label><select id="al-d" name="d">${vdayOpts(7, left)}</select>
    <button class="btn" style="width:100%;margin-top:12px;padding:12px">Convidar</button></form>` : `<div class="card"><b>Já não tens dias para convidar.</b></div>`;
  const dias = main ? "" : `<div class="card"><b>Os teus dias para convidar: ${left}</b><p class="note" style="margin:4px 0 0">Não podes convidar mais dias do que os que te restam.</p></div>`;
  const bulk = main ? `<form class="card" data-sf="vipall"><b>Convidar todos ao VIP</b><p class="note" style="margin:4px 0 8px">Só quem ainda não tem VIP.</p><div class="row"><select name="d" aria-label="Dias">${vdayOpts(1, 3)}</select><button class="btn">Convidar todos</button></div></form>` : "";
  const tad = main ? `<form class="card" data-sf="tadm" novalidate><b>Administrador temporário</b>
    <label class="fl" for="ta-e">E-mail do utilizador</label><input id="ta-e" name="e" type="email" autocomplete="off">
    <label class="fl" for="ta-d">Dias como administrador</label><select id="ta-d" name="d">${vdayOpts(7)}</select>
    <button class="btn" style="width:100%;margin-top:12px;padding:12px">Convidar administrador</button><div id="adtl" style="margin-top:8px">${tadmRows()}</div></form>` : "";
  return `<div class="stat" id="adstat">${statHtml(me)}</div>
    ${s.amsg ? `<div class="msg ${s.amsg[0] === "!" ? "" : "ok"}" role="status">${esc(s.amsg.replace(/^!/, ""))}</div>` : ""}${dias}${addForm}${bulk}${tad}${banForm}<section class="card"><h3 style="margin-top:0">Utilizadores</h3>
    <div class="sbar"><input id="adq" type="search" placeholder="Pesquisar utilizador…" autocomplete="off" value="${esc(s.aq || "")}" aria-label="Pesquisar utilizador"><span class="lupa">${ICON.search}</span></div>
    <div id="adlist">${adminRows(me)}</div></section>`;
}
function adminRows(me){
  const now = Date.now(), q = norm(S.soc.aq || "").trim(), al = DBc.allow || [], left = tadmLeft(me);
  const list = scopeUsers(me).filter(u => !q || norm(u.name).includes(q) || norm(u.email).includes(q));
  if (!list.length) return `<p class="note">Nenhum utilizador encontrado.</p>`;
  const dt = t => fmtFull(new Date(t).toISOString());
  return list.map(u => {
    const a = al.find(x => x.email === u.email), on = !!(a && a.exp > now), b = u.banUntil > now, self = u.id === me.id, E = esc(u.email);
    const vip = u.admin ? "VIP sempre" : on ? "VIP até " + dt(a.exp) : a ? "VIP terminou" : "sem VIP";
    const vipBtns = left > 0 ? `<select class="vsel" style="width:auto;padding:6px" aria-label="Dias de VIP">${vdayOpts(7, left)}</select><button class="mbtn" data-s="renew" data-e="${E}" data-on="${on ? 1 : 0}">${on ? "Adicionar dias" : "Dar VIP"}</button>` : "";
    const main = me.admin ? `${b ? `<button class="mbtn" data-s="unban" data-id="${u.id}">Remover ban</button>` : `<button class="mbtn" data-s="banopen" data-id="${u.id}">Banir</button>`}<button class="mbtn" style="background:var(--bad)" data-s="deluser" data-id="${u.id}">Excluir conta</button>` : "";
    return `<div class="urow"><b>${esc(u.name)}</b>${u.admin ? `<span class="tag">ADMIN</span>` : ""}<br><small style="color:var(--mute)">${E} · ${b ? "Banido até " + esc(tm(u.banUntil)) : "Ativo"} · ${esc(vip)}</small>
      ${self ? "" : `<div class="row">${vipBtns}${a ? `<button class="mbtn" data-s="rmallow" data-e="${E}">Remover VIP</button>` : ""}${main}</div>`}</div>`;
  }).join("");
}
const mainOnly = () => { reloadDB(); const u = cur(); return u && u.admin ? u : null; };
function adminOnly(){ reloadDB(); const u = cur(); return isAdm(u) ? u : null; }

/* ----- ações (cliques e formulários) ----- */
const ACT = {
  mode: d => { S.soc.mode = d.v; S.soc.err = ""; S.soc.info = ""; if (d.v !== "forgot2") S.soc.mail = null; render(); },
  logout: () => { if (API_URL){ api("logout"); dropSession(""); return render(); } S.pwPlain = ""; store.set(SESK, null); S.soc.mode = "login"; S.soc.err = ""; S.soc.info = ""; clearF(); S.view = "home"; S.drawer = false; render(); },
  eye: (d, el) => { const i = el.parentNode.querySelector("input"); if (!i) return; const show = i.type === "password"; i.type = show ? "text" : "password"; el.innerHTML = show ? EYE_OFF : EYE; el.setAttribute("aria-label", show ? "Esconder palavra-passe" : "Mostrar palavra-passe"); },
  admin: () => { if (!isAdm(cur())) return; go("admin"); refreshAdmin(); },
  tipq: d => askAssistant(d.q),
  vip: () => { reloadDB(); if (cur()){ S.vtab = "vip"; go("vip"); } },
  svip: () => { reloadDB(); if (cur() && cur().admin){ S.vtab = "vip"; go("svip"); } },
  comb: () => { reloadDB(); if (cur() && cur().admin){ S.ctab = "now"; go("comb"); } },
  ctab: d => { S.ctab = d.v; render(); },
  cday: d => { S.cday = d.k; render(); },
  cwday: d => { S.cwday = d.k; render(); },
  vtab: d => { S.vtab = d.v; render(); },
  vwday: d => { S.vwday = d.k; render(); },
  upd: () => { if (S.upd === "busy") return; if (S.upd === "ok"){ checkUpdate().then(() => { if (S.upd === "new") doUpdate(); }); return; } doUpdate(); },
  wa: () => { if (WHATSAPP_URL) window.open(WHATSAPP_URL, "_blank", "noopener"); else if (window.alert) window.alert("O link do grupo ainda não foi configurado."); },
  vdel: d => { if (window.confirm && !window.confirm("Remover este jogo do histórico VIP para sempre?")) return; vHid.add(d.id); saveVHid(); render(); },
  vclear: () => {
    if (window.confirm && !window.confirm("Limpar esta lista? Não dá para desfazer.")) return;
    const win = S.vtab === "win";
    S.history.forEach(f => { const p = vipPick(f), fin = finalOf(f); if (!p || !fin) return; const w = p.side === "h" ? fin.h > fin.a : fin.a > fin.h; if (w === win) vHid.add(f.id); }); saveVHid(); render();
  },
  renew: (d, el) => { if (!adminOnly()) return; const sel = el.parentNode.querySelector("select"), n = +(sel && sel.value); if (!VDAYS.includes(n)) return; allowSave(d.e, { days: n }, d.on === "1" ? `Adicionados ${n} ${dword(n)} ao VIP de ${d.e}.` : `VIP de ${d.e} definido para ${n} ${dword(n)}.`); },
  rmallow: d => {
    const me = adminOnly(); if (!me) return;
    if (API_URL){ api("admin/unallow", { email: d.e }).then(r => { S.soc.amsg = r.ok ? "VIP removido." : "!" + (r.error || "Erro."); refreshAdmin(); render(); }); return; }
    const a = allowOf(d.e); if (!a || (!me.admin && a.by !== me.email)) return;
    DBc.allow = DBc.allow.filter(x => x.email !== d.e); S.soc.amsg = "VIP removido."; saveDB(); render();
  },
  untadm: d => {
    if (!mainOnly()) return;
    if (API_URL){ api("admin/untadmin", { email: d.e }).then(r => { S.soc.amsg = r.ok ? "Administrador temporário removido." : "!" + (r.error || "Erro."); refreshAdmin(); render(); }); return; }
    DBc.tadmins = DBc.tadmins.filter(x => x.email !== d.e); S.soc.amsg = "Administrador temporário removido."; saveDB(); render();
  },
  banopen: d => { if (!mainOnly()) return; S.soc.banFor = d.id; render(); },
  banx: () => { S.soc.banFor = null; render(); },
  unban: d => { if (API_URL){ api("admin/unban", { id: d.id }).then(refreshAdmin); return; } if (!mainOnly()) return; const t = userById(d.id); if (t){ t.banUntil = 0; saveDB(); } render(); },
  deluser: d => {
    if (!mainOnly() || d.id === cur().id) return;
    const t = userById(d.id); if (!t) return;
    if (window.confirm && !window.confirm(`Excluir a conta de ${t.name} para sempre? Não dá para desfazer.`)) return;
    if (API_URL){ api("admin/delete", { id: d.id }).then(refreshAdmin); return; }
    DBc.users = DBc.users.filter(x => x.id !== d.id);
    DBc.users.forEach(x => { x.friends = (x.friends || []).filter(i => i !== d.id); });
    DBc.allow = DBc.allow.filter(a => a.email !== t.email); DBc.tadmins = DBc.tadmins.filter(a => a.email !== t.email); // sai do VIP e do banimento
    DBc.deleted = [...(DBc.deleted || []), t.email];
    delete DBc.resets[t.email]; saveDB(); render();
  }
};
// dá VIP a um utilizador que já tem conta. O principal escolhe qualquer prazo; o temporário só até aos dias que lhe restam
function allowSave(email, o, okMsg){
  const me = adminOnly(); if (!me) return;
  const msg = t => { S.soc.amsg = t; render(); };
  if (API_URL){ api("admin/allow", { email, ...o }).then(r => { if (r.ok){ S.soc.amsg = okMsg || "Guardado."; refreshAdmin(); render(); } else msg("!" + (r.error || "Erro.")); }); return; }
  reloadDB(); const now = Date.now(), t = DBc.users.find(u => u.email === email);
  if (!t) return msg("!Este e-mail ainda não tem conta.");
  if (t.admin) return msg("!Esta conta é do administrador principal.");
  if (!me.admin){
    const left = tadmLeft(me); if (o.days > left) return msg(`!Só podes convidar até ${left} ${dword(left)}.`);
    const a0 = allowOf(email); if (a0 && a0.exp > now && a0.by !== me.email) return msg("!Este utilizador já tem VIP.");
  }
  let a = allowOf(email); if (!a){ a = { email, exp: 0, by: "", created: now }; DBc.allow.push(a); }
  a.exp = Math.max(a.exp || 0, now) + o.days * DAYMS; a.by = me.admin ? "" : me.email;
  saveDB(); msg(okMsg || "Guardado.");
}
function vipAll(days){ // só o principal; só quem ainda não tem VIP
  if (!mainOnly() || ![1, 2, 3].includes(days)) return;
  const done = n => { S.soc.amsg = n ? `VIP dado a ${n} utilizador${n === 1 ? "" : "es"} por ${days} ${dword(days)}.` : "Todos já têm VIP."; refreshAdmin(); render(); };
  if (API_URL){ api("admin/vipall", { days }).then(r => r.ok ? done(r.n) : (S.soc.amsg = "!" + (r.error || "Erro."), render())); return; }
  reloadDB(); const now = Date.now(); let n = 0;
  DBc.users.forEach(u => { if (u.admin || u.banUntil > now) return; const a = allowOf(u.email); if (a && a.exp > now) return; if (a){ a.exp = now + days * DAYMS; a.by = ""; } else DBc.allow.push({ email: u.email, exp: now + days * DAYMS, by: "", created: now }); n++; });
  saveDB(); done(n);
}
function tadmSave(email, days){
  if (!mainOnly()) return;
  const msg = t => { S.soc.amsg = t; render(); }, ok = `${email} é administrador temporário por ${days} ${dword(days)}.`;
  if (API_URL){ api("admin/tadmin", { email, days }).then(r => r.ok ? (S.soc.amsg = ok, refreshAdmin(), render()) : msg("!" + (r.error || "Erro."))); return; }
  reloadDB(); const t = DBc.users.find(u => u.email === email);
  if (!t) return msg("!Este e-mail ainda não tem conta.");
  if (t.admin) return msg("!Esta conta já é a do administrador principal.");
  let a = DBc.tadmins.find(x => x.email === email); if (!a){ a = { email, exp: 0, created: Date.now() }; DBc.tadmins.push(a); }
  a.exp = Date.now() + days * DAYMS; saveDB(); msg(ok);
}
const FORM = {
  allow: f => {
    if (!adminOnly()) return;
    const e = f.elements.e.value.trim().toLowerCase(), d = +f.elements.d.value;
    if (!validEmail(e)){ S.soc.amsg = "!Escreve um e-mail válido."; return render(); }
    if (!VDAYS.includes(d)) return;
    allowSave(e, { days: d }, `${e} convidado para o VIP por ${d} ${dword(d)}.`);
  },
  vipall: f => vipAll(+f.elements.d.value),
  tadm: f => {
    const e = f.elements.e.value.trim().toLowerCase(), d = +f.elements.d.value;
    if (!validEmail(e)){ S.soc.amsg = "!Escreve um e-mail válido."; return render(); }
    if (VDAYS.includes(d)) tadmSave(e, d);
  },
  ask: f => { const v = f.elements.tq.value; f.elements.tq.value = ""; askAssistant(v); },
  login: () => doLogin(), register: () => doRegister(), forgot1: () => doForgot1(), forgot2: () => doForgot2(),
  ban: f => {
    if (!mainOnly()) return;
    const n = Math.min(3650, Math.max(1, Math.floor(+f.elements.n.value || 1))), ms = n * (+f.elements.u.value || 3600000);
    const t = userById(S.soc.banFor); if (!t || t.id === cur().id) return;
    if (API_URL){ api("admin/ban", { id: t.id, until: Date.now() + ms }).then(() => { S.soc.banFor = null; render(); refreshAdmin(); }); return; }
    t.banUntil = Date.now() + ms; saveDB(); S.soc.banFor = null; render();
  }
};
document.addEventListener("click", e => { const el = e.target.closest("[data-s]"); if (el && ACT[el.dataset.s]){ e.preventDefault(); ACT[el.dataset.s](el.dataset, el, e); } });
document.addEventListener("submit", e => { const f = e.target.closest("[data-sf]"); if (f && FORM[f.dataset.sf]){ e.preventDefault(); FORM[f.dataset.sf](f); } });
document.addEventListener("input", e => {
  const t = e.target;
  if (t.dataset && t.dataset.f) S.soc.f[t.dataset.f] = t.value;
  if (t.id === "adq"){ S.soc.aq = t.value; reloadDB(); const me = cur(), el = $("adlist"); if (el && isAdm(me)) el.innerHTML = adminRows(me); }
});
// lista de utilizadores (servidor): atualiza o número e a lista em tempo real
async function refreshAdmin(){
  if (!API_URL) return; const me = cur(); if (!isAdm(me)) return;
  const r = await api("admin/list"); if (!r.ok) return;
  DBc.users = r.users; DBc.allow = r.allow || []; DBc.tadmins = r.tadmins || []; if (S.view !== "admin") return;
  const el = $("adstat"), ls = $("adlist"), tl = $("adtl"); if (el) el.innerHTML = statHtml(me);
  if (ls && !S.soc.banFor) ls.innerHTML = adminRows(me);
  if (tl) tl.innerHTML = tadmRows();
}
// sessão no servidor: conta apagada ou banida perde o acesso em poucos segundos
async function checkSession(){
  if (!API_URL || !store.get(SESK, null)) return;
  const r = await api("me"); if (r.status === 0) return;
  if (r.ok){ S.soc.me = r.user; store.set(MEK, r.user); return; }
  if (r.status === 403 && r.error === "banned") dropSession(banMsg(r.banUntil, "A tua conta"));
  else if (r.status === 401) dropSession("A tua sessão terminou ou a conta foi removida.");
  else return;
  render();
}
if (API_URL){ setInterval(checkSession, 4000); setInterval(() => { if (isAdm(cur()) && S.view === "admin" && document.visibilityState === "visible") refreshAdmin(); }, 4000); checkSession(); }
// atualização periódica: banimentos aplicam-se em tempo real
setInterval(() => { reloadDB(); if (!cur() && S.soc.was) render(); }, 3000);
window.addEventListener("storage", e => { if (e.key === DBK || e.key === SESK){ reloadDB(); if (!cur()){ if (S.soc.was) render(); } else if (!S.soc.was) render(); } });

/* ---------- Navegação e eventos ---------- */
const TRANSITION_MS = 0; // transição entre ecrãs: 0 segundos (instantânea)
let busyTimer = null;
function startBusy(){
  clearTimeout(busyTimer); S.busy = false; S.fade = false; // sem espera nem animação entre ecrãs
}
const loaderHtml = () => `<div class="ldr" role="status" aria-live="polite"></div>`;
function go(view, compId){
  if (view === S.view && (compId ?? null) === S.compId){ S.drawer = false; S.search = false; S.lg = false; $("ov").innerHTML = ""; return; }
  S.view = view; S.compId = compId ?? null; S.drawer = false; S.search = false; drawerHtml();
  try { history.pushState({ v: view, c: compId ?? null, i: ((history.state && history.state.i) || 0) + 1 }, ""); } catch {}
  startBusy(); render(); window.scrollTo && window.scrollTo(0, 0);
}
window.addEventListener("popstate", e => { const s = e.state || { v: "home", c: null }; S.view = s.v; S.compId = s.c; S.drawer = false; S.search = false; S.lg = false; $("ov").innerHTML = ""; startBusy(); render(); window.scrollTo && window.scrollTo(0, 0); });
document.addEventListener("click", e => {
  const el = e.target.closest("[data-nav],[data-comp],[data-tab],[data-day],[data-vday],[data-hday],[data-an],[data-del],[data-favtoggle],[data-favgame],[data-favdel],[data-favopen],[data-act]"); if (!el) return;
  const d = el.dataset;
  if (d.act === "close"){ if (e.target !== el && el.classList.contains("ov") && e.target.closest(".drawer")) return; S.drawer = false; S.search = false; S.lg = false; $("ov").innerHTML = ""; return; }
  if (d.act === "leagues"){ S.lg = true; S.drawer = false; S.search = false; leaguesHtml(); return; }
  if (d.act === "lgtoggle"){
    if (S.sel.includes(d.id)) S.sel = S.sel.filter(x => x !== d.id); else if (S.sel.length < 3) S.sel = [...S.sel, d.id];
    store.set("calLeagues", S.sel); leaguesHtml(); render(); return;
  }
  if (d.act === "lgclear"){ S.sel = []; store.set("calLeagues", S.sel); leaguesHtml(); render(); return; }
  if (d.act === "back") return goBack();
  if (d.act === "clearhist"){
    if (window.confirm && !window.confirm("Limpar todo o histórico? Não dá para desfazer.")) return;
    S.history.forEach(f => S.hidden.add(f.id)); store.set("hiddenHist", [...S.hidden]); keepMap = new Map(); store.set("histKeep", []); return render();
  }
  if (d.act === "drawer"){ S.drawer = true; S.search = false; drawerHtml(); checkUpdate(); return; }
  if (d.act === "search"){ S.search = true; S.drawer = false; searchHtml(); return; }
  if (d.act === "next"){ const st = $("strip"); if (st && st.scrollBy) st.scrollBy({ left: 240, behavior: "smooth" }); return; }
  if (d.act === "analyze") return runNewAnalysis();
  if (d.favgame){
    const f = [...S.fixtures, ...S.history].find(x => x.id === d.favgame); if (!f || isDone(f.status)) return;
    if (favG(f.id)) S.favs = S.favs.filter(x => x.id !== "g:" + f.id);
    else S.favs = [...S.favs, { id: "g:" + f.id, gid: f.id, home_team: f.home_team, away_team: f.away_team, league: f.competitions?.name ?? "", kickoff_utc: f.kickoff_utc }];
    saveFavs(); const dl = $("dlg"); if (dl.open){ const b = dl.querySelector("[data-favgame]"); if (b){ b.textContent = favG(f.id) ? "★ Remover dos favoritos" : "☆ Adicionar aos favoritos"; } }
    return render();
  }
  if (d.favopen) return openFav(d.favopen);
  if (d.favtoggle){
    const r = S.ext; if (!r || r.f.id !== d.favtoggle) return;
    if (S.favs.some(x => x.id === r.f.id)) S.favs = S.favs.filter(x => x.id !== r.f.id);
    else S.favs = [...S.favs, { id: r.f.id, home_team: r.f.home_team, away_team: r.f.away_team, league: r.f.competitions.name, kickoff_utc: r.f.kickoff_utc, q: r.q }];
    saveFavs(); showExternal(r); render(); return;
  }
  if (d.favdel){
    if (window.confirm && !window.confirm("Remover este jogo dos favoritos?")) return;
    S.favs = S.favs.filter(x => x.id !== d.favdel); saveFavs();
    const dlg = $("dlg"); if (dlg.open && dlg.close) dlg.close();
    return render();
  }
  if (d.del){ if (window.confirm && !window.confirm("Remover este jogo do histórico para sempre? Não dá para desfazer.")) return; S.hidden.add(d.del); store.set("hiddenHist", [...S.hidden]); return render(); }
  if (d.act === "toggle"){ setTheme(isDark() ? "light" : "dark"); return; }
  if (d.hday){ const st = $("hstrip"), sc = st ? st.scrollLeft : 0; S.hday = d.hday; render(); const n = $("hstrip"); if (n) n.scrollLeft = sc; return; }
  if (d.vday){ const st = $("vstrip"), sc = st ? st.scrollLeft : 0; S.vday = d.vday; render(); const n = $("vstrip"); if (n) n.scrollLeft = sc; return; }
  if (d.day){ const st = $("strip"), sc = st ? st.scrollLeft : 0; S.day = d.day; render(); const n = $("strip"); if (n) n.scrollLeft = sc; return; }
  if (d.nav) return go(d.nav);
  if (d.comp) return go("comp", d.comp);
  if (d.tab){ S.tab = d.tab; return render(); }
  if (d.an) return openAnalysis(d.an);
});
document.addEventListener("input", e => { const k = ({ "na-home": "home", "na-away": "away", "na-league": "league" })[e.target.id]; if (k) S.na[k] = e.target.value; });
document.addEventListener("change", e => {
  if (e.target.id === "fcomp"){ S.comp = e.target.value; render(); }
});


// ---- actualização do aplicativo: compara o index.html que está aberto com a versão mais recente no GitHub ----
S.upd = "x"; // "ok" = actualizado · "new" = há versão nova · "x" = ainda não confirmado · "busy" · "off"
async function checkUpdate(){
  const before = S.upd;
  try {
    const u = location.origin + location.pathname;
    const [a, b] = await Promise.all([fetch(u, { cache: "force-cache" }).then(r => r.text()), fetch(u + "?_=" + Date.now(), { cache: "no-store" }).then(r => { if (!r.ok) throw 0; return r.text(); })]);
    S.upd = a === b ? "ok" : "new";
  } catch (e) { if (S.upd !== "busy") S.upd = "x"; }
  if (S.upd !== before){ if (S.drawer) drawerHtml(); render(); }
}
async function doUpdate(){
  if (navigator.onLine === false){ S.upd = "off"; drawerHtml(); setTimeout(() => { if (S.upd === "off"){ S.upd = "x"; drawerHtml(); } }, 2500); return; }
  S.upd = "busy"; drawerHtml();
  const u = location.origin + location.pathname;
  try { await fetch(u, { cache: "reload" }); } catch (e) {}                       // traz a versão nova e guarda-a
  try { if (window.caches) for (const k of await caches.keys()) await caches.delete(k); } catch (e) {}
  try { await fetch("fixtures.json?_=" + Date.now(), { cache: "reload" }); } catch (e) {}
  location.replace(u + location.hash);
}
setTimeout(checkUpdate, 1500); setInterval(checkUpdate, 60000);
document.addEventListener("visibilitychange", () => { if (document.visibilityState === "visible"){ load(); checkUpdate(); } });
window.addEventListener("online", load);
// transições automáticas: começa -> Ao vivo, termina -> Histórico (sem precisar de atualizar a página)
const stateSig = () => { reclassify(); return dayKey(new Date().toISOString()) + "|" + S.fixtures.map(f => f.id + f.status + f.home_goals + f.away_goals + "").join(",") + "|" + S.history.length; };
const AUTO_VIEWS = ["home", "comp", "cal", "fav", "hist", "vip", "svip", "comb"];
let lastSig = "";
const checkState = () => { if (!cur()) return; const g = stateSig(); const first = lastSig === ""; if (g !== lastSig){ lastSig = g; if (!first && AUTO_VIEWS.includes(S.view)) render(); } };
setInterval(checkState, 15000);
const hotNow = () => { const now = Date.now(); return S.raw.some(f => !isDone(f.status) && Math.abs(Date.parse(f.kickoff_utc) - now) < 3 * 3600e3); };
// durante um jogo (ou perto do apito): placar e minuto reais de 20 em 20 s (fonte em tempo real) e o fixtures.json de minuto a minuto
setInterval(async () => { if (document.visibilityState !== "visible" || !cur() || !hotNow()) return; if (await fetchLive()) checkState(); }, 20000);
setInterval(async () => { if (document.visibilityState !== "visible" || !cur() || !hotNow()) return; await fetchData(); checkState(); }, 60000);
// calendário automático: volta a ler o fixtures.json de 1 em 1 minuto (e ao voltar ao separador), sem recarregar a página
let lastPull = Date.now();
const pullCal = async () => { lastPull = Date.now(); await fetchData(); checkState(); };
setInterval(() => { if (document.visibilityState === "visible" && cur() && Date.now() - lastPull > 55000) pullCal(); }, 60000);
document.addEventListener("visibilitychange", () => { if (document.visibilityState === "visible" && cur() && Date.now() - lastPull > 30000) pullCal(); });
try { history.replaceState({ v: "home", c: null, i: 0 }, ""); } catch {}
applyTheme();
load();
setInterval(load, 30 * 60 * 1000);
