class_name CarData
extends RefCounted
## Os 10 carros do jogo. Cada um tem estatísticas diferentes (diferenças reais de condução).
## Para adicionar um carro novo basta acrescentar uma linha em ALL.
##
## kmh   = velocidade máxima base          accel = aceleração (m/s²)      brake = travagem (m/s²)
## steer = rotação máxima da direção (°/s)  grip  = aderência lateral (0-1): baixo = derrapa mais
## len/wid/hgt/cabin/wing = forma do modelo 3D procedural

const ALL: Array = [
	{"id": "pemba_gt", "name": "PEMBA GT", "tag": ["Equilibrado. Ideal para começar.", "Balanced. Great to start."], "price": 0, "kmh": 200.0, "accel": 7.0, "brake": 17.0, "steer": 95.0, "grip": 0.90, "mass": 1300.0, "len": 4.4, "wid": 1.90, "hgt": 0.55, "cabin": 0.45, "wing": 0},
	{"id": "maputo_s", "name": "MAPUTO S", "tag": ["Ágil nas curvas.", "Agile in corners."], "price": 0, "kmh": 190.0, "accel": 7.4, "brake": 18.0, "steer": 110.0, "grip": 0.95, "mass": 1150.0, "len": 4.1, "wid": 1.85, "hgt": 0.52, "cabin": 0.50, "wing": 1},
	{"id": "luanda_x", "name": "LUANDA X", "tag": ["Aceleração explosiva.", "Explosive acceleration."], "price": 1800, "kmh": 205.0, "accel": 9.0, "brake": 17.0, "steer": 90.0, "grip": 0.88, "mass": 1250.0, "len": 4.3, "wid": 1.90, "hgt": 0.50, "cabin": 0.45, "wing": 1},
	{"id": "zambezi_rs", "name": "ZAMBEZI RS", "tag": ["Pura velocidade final.", "Pure top speed."], "price": 2600, "kmh": 235.0, "accel": 6.6, "brake": 16.0, "steer": 85.0, "grip": 0.86, "mass": 1350.0, "len": 4.6, "wid": 1.95, "hgt": 0.50, "cabin": 0.40, "wing": 2},
	{"id": "kilimanjaro", "name": "KILIMANJARO", "tag": ["Estável, com travões fortes.", "Stable with strong brakes."], "price": 3400, "kmh": 215.0, "accel": 7.2, "brake": 22.0, "steer": 92.0, "grip": 0.98, "mass": 1400.0, "len": 4.5, "wid": 1.95, "hgt": 0.55, "cabin": 0.50, "wing": 0},
	{"id": "serengeti", "name": "SERENGETI", "tag": ["Equilíbrio de corrida.", "Race balance."], "price": 4500, "kmh": 225.0, "accel": 8.0, "brake": 20.0, "steer": 98.0, "grip": 0.93, "mass": 1250.0, "len": 4.3, "wid": 1.90, "hgt": 0.48, "cabin": 0.45, "wing": 1},
	{"id": "cabinda_r", "name": "CABINDA R", "tag": ["Derrapa com estilo.", "Drifts with style."], "price": 5600, "kmh": 220.0, "accel": 8.4, "brake": 18.0, "steer": 115.0, "grip": 0.80, "mass": 1200.0, "len": 4.2, "wid": 1.85, "hgt": 0.50, "cabin": 0.50, "wing": 1},
	{"id": "nacala_gtr", "name": "NACALA GTR", "tag": ["Super-desportivo equilibrado.", "Balanced supercar."], "price": 7200, "kmh": 245.0, "accel": 8.2, "brake": 21.0, "steer": 100.0, "grip": 0.95, "mass": 1350.0, "len": 4.5, "wid": 1.98, "hgt": 0.45, "cabin": 0.45, "wing": 2},
	{"id": "benguela_v12", "name": "BENGUELA V12", "tag": ["Potência bruta.", "Raw power."], "price": 9000, "kmh": 265.0, "accel": 9.0, "brake": 20.0, "steer": 88.0, "grip": 0.90, "mass": 1450.0, "len": 4.7, "wid": 2.00, "hgt": 0.42, "cabin": 0.45, "wing": 2},
	{"id": "pemba_hyper", "name": "PEMBA HYPER", "tag": ["O rei da pista.", "King of the track."], "price": 12000, "kmh": 285.0, "accel": 10.0, "brake": 24.0, "steer": 105.0, "grip": 0.97, "mass": 1300.0, "len": 4.6, "wid": 2.00, "hgt": 0.40, "cabin": 0.40, "wing": 2},
]

# Valores máximos usados para desenhar as barras da garagem
const MAX_KMH := 320.0
const MAX_ACCEL := 12.0
const MAX_BRAKE := 28.0
const MAX_STEER := 125.0


static func by_id(id: String) -> Dictionary:
	for c in ALL:
		if c["id"] == id:
			return c
	return ALL[0]


static func index_of(id: String) -> int:
	for i in ALL.size():
		if ALL[i]["id"] == id:
			return i
	return 0


static func tag(def: Dictionary) -> String:
	var t: Array = def["tag"]
	return t[1] if Settings.language == 1 else t[0]
