extends Node
## Cena principal. Os sistemas do jogo são autoloads (ver project.godot): o GameManager abre o menu sozinho.
## Argumento de linha de comandos "--selftest" corre o teste automático (ver tests/SelfTest.gd).


func _ready() -> void:
	if "--shots" in OS.get_cmdline_user_args():
		add_child(preload("res://tests/Shots.gd").new())
	if "--selftest" in OS.get_cmdline_user_args():
		var t := preload("res://tests/SelfTest.gd").new()
		add_child(t)
