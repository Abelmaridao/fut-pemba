class_name CarController
extends RigidBody3D
## CarController: física arcade do carro (aceleração, travagem, direção, aderência, travão de mão).
## Cada carro tem estatísticas próprias (CarData + melhorias), por isso conduzem de forma diferente.
## A frente do carro aponta para -Z.
##
## Para o controlar: preenche o dicionário "drive" em cada frame:
##   throttle 0..1, brake 0..1, steer -1..1 (direita positiva), reverse (bool), handbrake (bool)

const IDLE := {"throttle": 0.0, "brake": 0.0, "steer": 0.0, "reverse": false, "handbrake": false}

var stats: Dictionary = {"max_ms": 55.0, "accel": 7.0, "brake": 17.0, "steer": 95.0, "grip": 0.9, "mass": 1300.0}
var drive: Dictionary = IDLE.duplicate()
var visual: CarVisual
var controllable: bool = true

var speed_kmh: float = 0.0
var forward_speed: float = 0.0
var grounded: bool = false
var slip: float = 0.0            # 0..1, usado para o som dos pneus
var player_name: String = ""

var _yaw: float = 0.0
var _spin: float = 0.0
var _last_speed: float = 0.0
var _pitch: float = 0.0
var _roll: float = 0.0
var _last_fs: float = 0.0


func setup(def: Dictionary, sv: Dictionary, vis: CarVisual) -> void:
	stats = CarSelection.stats(def, sv)
	mass = float(stats["mass"])
	visual = vis
	add_child(vis)

	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(float(def["wid"]), 0.9, float(def["len"]))
	cs.shape = shape
	cs.position = Vector3(0, 0.5, 0)
	add_child(cs)

	var pm := PhysicsMaterial.new()
	pm.friction = 0.0   # a aderência é calculada por nós em _integrate_forces
	pm.bounce = 0.05
	physics_material_override = pm
	axis_lock_angular_x = true
	axis_lock_angular_z = true
	linear_damp = 0.0
	angular_damp = 0.0
	continuous_cd = true
	can_sleep = false


func _integrate_forces(state: PhysicsDirectBodyState3D) -> void:
	var dt: float = state.step
	var b: Basis = state.transform.basis
	var fwd: Vector3 = -b.z
	var right: Vector3 = b.x
	var v: Vector3 = state.linear_velocity
	var fs: float = v.dot(fwd)
	var ls: float = v.dot(right)
	var inp: Dictionary = drive if controllable else IDLE
	var max_ms: float = float(stats["max_ms"])
	var ratio: float = clampf(absf(fs) / max_ms, 0.0, 1.0)
	grounded = _ground_check(state)
	slip = 0.0

	var thr: float = float(inp["throttle"])
	var brk: float = float(inp["brake"])
	var rev: bool = bool(inp["reverse"])
	var hb: bool = bool(inp["handbrake"])

	if grounded:
		# Acelerar: força diminui perto da velocidade máxima
		if thr > 0.01:
			if fs < 0.0:
				v += fwd * float(stats["brake"]) * thr * dt   # a andar para trás: acelerar trava primeiro
			elif fs < max_ms:
				var a: float = float(stats["accel"]) * thr * (1.0 - pow(fs / max_ms, 2.2))
				v += fwd * a * dt
		# Marcha-atrás / travar
		if rev and fs <= 0.5 and thr < 0.01:
			if fs > -max_ms * 0.28:
				v -= fwd * float(stats["accel"]) * 0.6 * dt
		elif (brk > 0.01 or rev) and fs > 0.5:
			var bf: float = maxf(brk, 1.0 if rev else 0.0)
			v -= fwd * minf(float(stats["brake"]) * bf * dt, fs)
			slip = maxf(slip, bf * ratio)
		# Resistência (rolamento + ar)
		var drag: float = (0.9 if thr < 0.01 else 0.25) + 0.0032 * fs * fs
		v -= fwd * signf(fs) * minf(drag * dt, absf(fs))
		# Aderência lateral: mais baixa = derrapa mais. O travão de mão quase solta o eixo traseiro.
		var grip_rate: float = 1.4 if hb else float(stats["grip"]) * 14.0
		v -= right * ls * (1.0 - exp(-grip_rate * dt))
		slip = maxf(slip, clampf(absf(ls) / 8.0, 0.0, 1.0) * clampf(ratio * 2.0, 0.0, 1.0))
		if hb:
			v -= fwd * fs * 0.9 * dt
			slip = maxf(slip, ratio)
		# Direção: precisa de movimento; fica mais "pesada" a alta velocidade
		var sf: float = clampf(fs / 6.0, -1.0, 1.0) * (1.0 - 0.45 * ratio) * (1.6 if hb else 1.0)
		var target_yaw: float = -float(inp["steer"]) * deg_to_rad(float(stats["steer"])) * sf
		_yaw = lerpf(_yaw, target_yaw, 1.0 - exp(-12.0 * dt))
		state.angular_velocity = Vector3(0.0, _yaw, 0.0)
	else:
		_yaw = state.angular_velocity.y

	# Limite de velocidade horizontal
	var hv := Vector2(v.x, v.z)
	if hv.length() > max_ms * 1.03:
		hv = hv.normalized() * max_ms * 1.03
		v.x = hv.x
		v.z = hv.y
	state.linear_velocity = v

	forward_speed = fs
	speed_kmh = Vector2(v.x, v.z).length() * 3.6
	# Som de colisão: queda brusca de velocidade num único passo
	var sp: float = Vector2(v.x, v.z).length()
	if _last_speed - sp > 5.0:
		Audio.crash((_last_speed - sp) / 20.0)
	_last_speed = sp


func _ground_check(state: PhysicsDirectBodyState3D) -> bool:
	var space: PhysicsDirectSpaceState3D = state.get_space_state()
	var o: Vector3 = state.transform.origin
	var q := PhysicsRayQueryParameters3D.create(o + Vector3.UP * 0.5, o + Vector3.DOWN * 0.6)
	q.exclude = [get_rid()]
	return not space.intersect_ray(q).is_empty()


func _process(delta: float) -> void:
	if visual == null:
		return
	_spin += forward_speed / visual.wheel_radius * delta
	var steer: float = float(drive["steer"]) if controllable else 0.0
	for i in 4:
		(visual.spinners[i] as Node3D).rotation.x = -_spin
	for i in 2:
		(visual.pivots[i] as Node3D).rotation.y = lerp_angle((visual.pivots[i] as Node3D).rotation.y, -steer * 0.45, 1.0 - exp(-14.0 * delta))
	# Inclinação visual da carroçaria (curvas e acelerações)
	var accel: float = (forward_speed - _last_fs) / maxf(delta, 0.0001)
	_last_fs = forward_speed
	var ratio: float = clampf(absf(forward_speed) / float(stats["max_ms"]), 0.0, 1.0)
	var want_roll: float = steer * ratio * 0.06
	var want_pitch: float = clampf(accel * 0.002, -0.05, 0.05)
	_roll = lerpf(_roll, want_roll, 1.0 - exp(-6.0 * delta))
	_pitch = lerpf(_pitch, want_pitch, 1.0 - exp(-6.0 * delta))
	visual.body_root.rotation = Vector3(_pitch, 0.0, _roll)
