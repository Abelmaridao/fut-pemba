class_name ProceduralCar
extends RefCounted
## Cria o modelo 3D de qualquer carro por código (caixas, cilindros e materiais), a partir da definição em CarData
## e da personalização guardada (cor, jantes, pintura). Recursos provisórios, bem organizados: mais tarde podes
## trocar por modelos feitos no Blender sem mexer na arquitectura (basta devolver outro CarVisual).
## Convenção do Godot: a frente do carro aponta para -Z.


static func _mat(c: Color, rough: float = 0.4, metal: float = 0.0, emis: Color = Color(0, 0, 0, 0)) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	m.metallic = metal
	if emis.a > 0.0:
		m.emission_enabled = true
		m.emission = emis
		m.emission_energy_multiplier = 1.6
	return m


static func _box(parent: Node3D, size: Vector3, pos: Vector3, mat: Material, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mesh := BoxMesh.new()
	mesh.size = size
	return _inst(parent, mesh, pos, mat, rot)


static func _cyl(parent: Node3D, radius: float, height: float, pos: Vector3, mat: Material, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mesh := CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = height
	mesh.radial_segments = 20
	mesh.rings = 1
	return _inst(parent, mesh, pos, mat, rot)


static func _inst(parent: Node3D, mesh: Mesh, pos: Vector3, mat: Material, rot: Vector3) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	mi.rotation = rot
	parent.add_child(mi)
	return mi


static func build(def: Dictionary, sv: Dictionary) -> CarVisual:
	var v := CarVisual.new()
	v.body_root = Node3D.new()
	v.add_child(v.body_root)
	var body: Node3D = v.body_root

	var L: float = def["len"]
	var W: float = def["wid"]
	var H: float = def["hgt"]
	var R: float = v.wheel_radius
	var color: Color = CarSelection.COLORS[int(sv["color"])]
	var finish: int = int(sv["finish"])
	var rough: float = [0.22, 0.85, 0.25, 0.22][finish]
	var metal: float = [0.30, 0.0, 0.95, 0.30][finish]
	var paint := _mat(color, rough, metal)
	var dark := _mat(Color(0.03, 0.03, 0.04), 0.5, 0.2)
	var glass := _mat(Color(0.05, 0.09, 0.14), 0.05, 0.5)

	# Carroçaria: traseira alta + capô mais baixo
	var bottom: float = 0.28
	var rear_len: float = L * 0.72
	var nose_len: float = L * 0.28
	var nose_h: float = H * 0.72
	_box(body, Vector3(W, H, rear_len), Vector3(0, bottom + H * 0.5, L * 0.5 - rear_len * 0.5), paint)
	_box(body, Vector3(W, nose_h, nose_len), Vector3(0, bottom + nose_h * 0.5, -(L * 0.5 - nose_len * 0.5)), paint)
	var top: float = bottom + H

	# Cabine (vidros) + tejadilho
	var cab_len: float = L * float(def["cabin"])
	var cab_h: float = H * 0.85
	_box(body, Vector3(W * 0.80, cab_h, cab_len), Vector3(0, top + cab_h * 0.5, L * 0.08), glass)
	_box(body, Vector3(W * 0.74, 0.05, cab_len * 0.78), Vector3(0, top + cab_h + 0.02, L * 0.08), paint)

	# Spoiler frontal, difusor, faróis e luzes traseiras
	_box(body, Vector3(W * 1.04, 0.05, 0.42), Vector3(0, 0.22, -L * 0.5 - 0.04), dark)
	_box(body, Vector3(W * 0.9, 0.12, 0.30), Vector3(0, 0.30, L * 0.5), dark)
	var head := _mat(Color(1, 1, 0.9), 0.2, 0.0, Color(1.0, 0.95, 0.75, 1.0))
	for sx in [-1.0, 1.0]:
		_box(body, Vector3(0.36, 0.10, 0.06), Vector3(sx * W * 0.31, bottom + nose_h - 0.08, -L * 0.5), head)
	var tail := _mat(Color(0.8, 0.0, 0.0), 0.3, 0.0, Color(1.0, 0.05, 0.05, 1.0))
	_box(body, Vector3(W * 0.8, 0.09, 0.06), Vector3(0, bottom + H * 0.6, L * 0.5 + 0.01), tail)

	# Aileron
	var wing: int = int(def["wing"])
	if wing > 0:
		var wh: float = 0.30 if wing == 1 else 0.52
		for sx in [-1.0, 1.0]:
			_box(body, Vector3(0.05, wh, 0.07), Vector3(sx * W * 0.3, top + wh * 0.5, L * 0.5 - 0.28), dark)
		_box(body, Vector3(W * 0.96, 0.05, 0.50), Vector3(0, top + wh, L * 0.5 - 0.28), dark)

	# Riscas de corrida (pintura 3)
	if finish == 3:
		var stripe := _mat(Color(0.97, 0.97, 0.97), 0.3, 0.1)
		for sx in [-1.0, 1.0]:
			_box(body, Vector3(W * 0.11, 0.012, rear_len), Vector3(sx * W * 0.10, top + 0.007, L * 0.5 - rear_len * 0.5), stripe)
			_box(body, Vector3(W * 0.11, 0.012, nose_len), Vector3(sx * W * 0.10, bottom + nose_h + 0.007, -(L * 0.5 - nose_len * 0.5)), stripe)

	# Rodas: pivô (direção) -> spinner (rotação) -> pneu + jante
	var tire := _mat(Color(0.02, 0.02, 0.02), 0.9, 0.0)
	var rim_style: int = int(sv["rim"])
	var rim_color: Color = [Color(0.80, 0.82, 0.86), Color(0.75, 0.77, 0.82), Color(0.95, 0.75, 0.2), Color(0.95, 0.95, 0.97), Color(0.1, 0.9, 1.0)][rim_style]
	var rim_mat := _mat(rim_color, 0.25, 0.9, rim_color if rim_style == 4 else Color(0, 0, 0, 0))
	var hub := _mat(Color(0.06, 0.06, 0.08), 0.5, 0.3)
	var spokes: int = [0, 5, 8, 6, 0][rim_style]
	var zs: Array = [-L * 0.31, -L * 0.31, L * 0.31, L * 0.31]
	var xs: Array = [-(W * 0.5 - 0.06), (W * 0.5 - 0.06), -(W * 0.5 - 0.06), (W * 0.5 - 0.06)]
	for i in 4:
		var pivot := Node3D.new()
		pivot.position = Vector3(xs[i], R, zs[i])
		v.add_child(pivot)
		var spin := Node3D.new()
		pivot.add_child(spin)
		v.pivots.append(pivot)
		v.spinners.append(spin)
		var side: float = signf(xs[i])
		_cyl(spin, R, 0.28, Vector3.ZERO, tire, Vector3(0, 0, PI * 0.5))
		if spokes == 0:
			_cyl(spin, R * 0.62, 0.30, Vector3(side * 0.005, 0, 0), rim_mat, Vector3(0, 0, PI * 0.5))
		else:
			_cyl(spin, R * 0.62, 0.30, Vector3(side * 0.005, 0, 0), hub, Vector3(0, 0, PI * 0.5))
			for k in spokes:
				var a: float = TAU * k / spokes
				_box(spin, Vector3(0.03, R * 1.1, 0.05), Vector3(side * 0.152, 0, 0), rim_mat, Vector3(a, 0, 0))
		_cyl(spin, R * 0.18, 0.31, Vector3(side * 0.008, 0, 0), hub, Vector3(0, 0, PI * 0.5))
	return v
