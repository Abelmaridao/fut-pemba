extends Node
## AudioManager (autoload "Audio")
## Todos os sons são sintetizados por código (sem ficheiros): motor, travagem, colisão, botões, vitória e música.
## Mais tarde podes trocar qualquer um por um ficheiro .ogg/.wav real sem mexer no resto do jogo.

const RATE := 22050
const MUSIC_RATE := 11025

var _music: AudioStreamPlayer
var _engine: AudioStreamPlayer
var _brake: AudioStreamPlayer
var _sfx: Array[AudioStreamPlayer] = []
var _sfx_i: int = 0
var _click: AudioStreamWAV
var _crash: AudioStreamWAV
var _win: AudioStreamWAV
var _music_stream: AudioStreamWAV
var _music_wanted: bool = false
var _thread: Thread


func _ready() -> void:
	_music = _player()
	_engine = _player()
	_brake = _player()
	for i in 4:
		_sfx.append(_player())

	_click = _make(0.07, func(t: float) -> float: return sin(t * 1400.0 * TAU) * exp(-t * 55.0) * 0.6)
	_crash = _make(0.45, func(t: float) -> float:
		return (randf() * 2.0 - 1.0) * exp(-t * 9.0) * 0.9 + sin(t * 70.0 * TAU) * exp(-t * 12.0) * 0.6)
	_win = _make(1.4, func(t: float) -> float:
		var notes := [523.25, 659.25, 783.99, 1046.5]
		var i: int = mini(3, int(t / 0.28))
		var lt: float = t - i * 0.28
		return sin(lt * float(notes[i]) * TAU) * exp(-lt * 3.0) * 0.5)
	# Motor: 55 Hz com harmónicos; 1 s = 55 ciclos exactos, por isso o loop é contínuo.
	var eng := func(t: float) -> float:
		var p: float = t * 55.0 * TAU
		var s: float = sin(p) + 0.55 * sin(2.0 * p) + 0.35 * sin(3.0 * p) + 0.22 * sin(4.0 * p) + 0.12 * sin(7.0 * p)
		return s * 0.22 + (randf() * 2.0 - 1.0) * 0.03
	_engine.stream = _make(1.0, eng, true)
	# Pneus a chiar (frequências inteiras em ciclos para loop sem corte).
	var brk := func(t: float) -> float:
		return (sin(t * 1800.0 * TAU) * 0.5 + sin(t * 2300.0 * TAU) * 0.35) * (0.6 + 0.4 * randf()) * 0.4
	_brake.stream = _make(0.5, brk, true)

	# A música é criada numa thread para não travar o arranque em telemóveis fracos.
	_thread = Thread.new()
	_thread.start(_build_music)
	refresh_volumes()


func _player() -> AudioStreamPlayer:
	var p := AudioStreamPlayer.new()
	add_child(p)
	return p


## Gera um clip mono de 16 bits. fn recebe o tempo em segundos e devolve amostra (-1..1).
func _make(seconds: float, fn: Callable, loop: bool = false, rate: int = RATE) -> AudioStreamWAV:
	var n: int = maxi(1, int(rate * seconds))
	var data := PackedByteArray()
	data.resize(n * 2)
	for i in n:
		var v: float = clampf(float(fn.call(float(i) / rate)), -1.0, 1.0)
		data.encode_s16(i * 2, int(v * 32767.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.stereo = false
	w.data = data
	if loop:
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = n
	return w


## Música do menu: 4 acordes (Am, F, C, G), 4 s cada, loop de 16 s.
func _build_music() -> void:
	var chords := [
		[220.0, 261.63, 329.63], [174.61, 220.0, 261.63],
		[261.63, 329.63, 392.0], [196.0, 246.94, 293.66]]
	var fn := func(t: float) -> float:
		var ci: int = mini(3, int(t / 4.0))
		var lt: float = t - ci * 4.0
		var env: float = clampf(lt / 0.6, 0.0, 1.0) * clampf((4.0 - lt) / 0.6, 0.0, 1.0)
		var s := 0.0
		for f in chords[ci]:
			s += sin(t * float(f) * TAU) * 0.12
		var step: float = fmod(lt, 0.5)
		s += sin(t * float(chords[ci][0]) * 0.5 * TAU) * exp(-step * 6.0) * 0.35
		return s * env * 0.8
	var w := _make(16.0, fn, true, MUSIC_RATE)
	call_deferred("_music_ready", w)


func _music_ready(w: AudioStreamWAV) -> void:
	if _thread:
		_thread.wait_to_finish()
		_thread = null
	_music_stream = w
	if _music_wanted:
		play_music(true)


func refresh_volumes() -> void:
	if _music == null:
		return
	_music.volume_db = linear_to_db(maxf(0.0001, Settings.music_vol * 0.6))
	for p in _sfx:
		p.volume_db = linear_to_db(maxf(0.0001, Settings.sfx_vol))


func click() -> void:
	_play(_click, 0.8)


func win() -> void:
	_play(_win, 1.0)


func crash(vol: float) -> void:
	_play(_crash, clampf(vol, 0.0, 1.0))


func _play(stream: AudioStream, vol: float) -> void:
	if _sfx.is_empty():
		return
	var p: AudioStreamPlayer = _sfx[_sfx_i]
	_sfx_i = (_sfx_i + 1) % _sfx.size()
	p.stream = stream
	p.volume_db = linear_to_db(maxf(0.0001, Settings.sfx_vol * vol))
	p.play()


func play_music(on: bool) -> void:
	_music_wanted = on
	if not on:
		_music.stop()
		return
	if _music_stream == null:
		return  # ainda a ser criada; toca assim que ficar pronta
	if _music.stream != _music_stream:
		_music.stream = _music_stream
	if not _music.playing:
		_music.play()


## Som do motor: o tom sobe com a velocidade (pitch01 = 0..1) e o volume com o acelerador.
func set_engine(on: bool, pitch01: float, throttle: float) -> void:
	if not on:
		_engine.stop()
		_brake.stop()
		return
	if not _engine.playing:
		_engine.play()
	_engine.pitch_scale = lerpf(0.8, 3.6, clampf(pitch01, 0.0, 1.0))
	_engine.volume_db = linear_to_db(maxf(0.0001, Settings.sfx_vol * lerpf(0.25, 0.6, clampf(throttle, 0.0, 1.0))))


## Chiar dos pneus (travagem forte / derrapagem). 0 = silêncio.
func set_brake(intensity: float) -> void:
	if intensity > 0.05:
		if not _brake.playing:
			_brake.play()
		_brake.volume_db = linear_to_db(maxf(0.0001, Settings.sfx_vol * clampf(intensity, 0.0, 1.0) * 0.5))
	elif _brake.playing:
		_brake.stop()


func _exit_tree() -> void:
	if _thread:
		_thread.wait_to_finish()
