extends Node
## NetworkManager (autoload "Net")
## ETAPA 4 (ainda não implementado). Aqui ficará a camada de rede local, sem Internet:
##  - criar servidor ENet (UDP) numa porta fixa (47801) para até 8 jogadores;
##  - descoberta de salas por UDP broadcast na rede Wi-Fi / hotspot (porta 47800);
##  - ligação ao anfitrião por endereço IP.
const IMPLEMENTED := false
const DISCOVERY_PORT := 47800
const GAME_PORT := 47801
const MAX_PLAYERS := 8
