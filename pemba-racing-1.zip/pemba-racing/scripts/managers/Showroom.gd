class_name Showroom
extends RefCounted
## Cenário de exposição (usado no menu e na garagem): chão escuro com anel azul e luzes vermelha/azul.


static func build(parent: Node3D) -> Dictionary:
	parent.add_child(TrackManager.make_environment(Color(0.02, 0.03, 0.07), Color(0.04, 0.05, 0.10), 0.35, false))

	var ring_mat := StandardMaterial3D.new()
	ring_mat.albedo_color = Color(0.05, 0.3, 0.9)
	ring_mat.emission_enabled = true
	ring_mat.emission = Color(0.1, 0.45, 1.0)
	ring_mat.emission_energy_multiplier = 2.0
	var ring := MeshInstance3D.new()
	var rm := CylinderMesh.new()
	rm.top_radius = 15.5
	rm.bottom_radius = 15.5
	rm.height = 0.02
	rm.radial_segments = 48
	ring.mesh = rm
	ring.material_override = ring_mat
	ring.position.y = -0.011
	parent.add_child(ring)

	var floor_mat := StandardMaterial3D.new()
	floor_mat.albedo_color = Color(0.03, 0.03, 0.05)
	floor_mat.roughness = 0.35
	floor_mat.metallic = 0.6
	var fl := MeshInstance3D.new()
	var fm := CylinderMesh.new()
	fm.top_radius = 14.5
	fm.bottom_radius = 14.5
	fm.height = 0.02
	fm.radial_segments = 48
	fl.mesh = fm
	fl.material_override = floor_mat
	parent.add_child(fl)

	var key := DirectionalLight3D.new()
	key.rotation_degrees = Vector3(-45, 30, 0)
	key.light_energy = 0.5
	key.shadow_enabled = Settings.shadows_enabled()
	parent.add_child(key)

	var red := OmniLight3D.new()
	red.light_color = Color(1.0, 0.1, 0.15)
	red.light_energy = 5.0
	red.omni_range = 26.0
	parent.add_child(red)
	var blue := OmniLight3D.new()
	blue.light_color = Color(0.1, 0.4, 1.0)
	blue.light_energy = 5.0
	blue.omni_range = 26.0
	parent.add_child(blue)
	return {"red": red, "blue": blue}
