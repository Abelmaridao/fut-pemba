class_name AIController
extends Node
## AIController - ETAPA 3 (ainda não implementado).
## Vai controlar adversários: seguir o circuito, fazer curvas, acelerar e travar, competir pela primeira posição,
## evitar sair da pista e ter vários níveis de dificuldade. Vai usar o mesmo dicionário "drive" do CarController,
## por isso um carro da IA conduz exactamente como um carro do jogador.
const IMPLEMENTED := false
