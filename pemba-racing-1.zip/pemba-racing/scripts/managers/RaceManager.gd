class_name RaceManager
extends Node
## RaceManager: ecrã de corrida. ETAPA 1 = TESTE DE CONDUÇÃO na pista de testes: o teu carro (o selecionado na garagem),
## controlos de telemóvel, 3 câmaras, velocidade em km/h, indicador de velocidade, cronómetro e menu de pausa.
## ETAPA 2/3: voltas, linha de chegada, classificação, adversários (AIController), resultados.

var _world: Node3D
var _track: TrackManager
var _cam: CameraManager
var car: CarController
var controls: MobileControls
var _ui: CanvasLayer
var _speed_l: Label
var _time_l: Label
var _cam_l: Label
var _gauge: ProgressBar
var _pause_panel: Control = null
var _time: float = 0.0
var paused: bool = false


func _ready() -> void:
	_world = Node3D.new()
	add_child(_world)
	_track = TrackManager.new()
	_world.add_child(_track)
	_track.build_test_arena()

	var def: Dictionary = CarData.by_id(str(Game.save["selected"]))
	var sv := CarSelection.get_car(def["id"])
	car = CarController.new()
	car.setup(def, sv, ProceduralCar.build(def, sv))
	car.transform = _track.spawn_transform
	_world.add_child(car)

	_cam = CameraManager.new()
	_world.add_child(_cam)
	_cam.set_target(car)
	_cam.set_mode(CameraManager.Mode.REAR)

	_ui = CanvasLayer.new()
	add_child(_ui)
	controls = MobileControls.new()
	_ui.add_child(controls)
	controls.camera_pressed.connect(_on_camera)
	controls.pause_pressed.connect(toggle_pause)
	_build_hud()


func _exit_tree() -> void:
	Audio.set_engine(false, 0.0, 0.0)
	get_tree().paused = false


func _build_hud() -> void:
	var host := Control.new()
	host.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_ui.add_child(host)
	U.full(host)
	var root := U.safe_root(host)
	var tp := U.panel(U.DARK, 20)
	root.add_child(tp)
	U.place(tp, Vector2(0, 0), Vector2(0, 0), Vector2(340, 80))
	_time_l = U.label("00:00.0", 44, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER)
	tp.add_child(_time_l)
	U.full(_time_l)
	var title := U.label(U.t("PISTA DE TESTES  ·  ETAPA 1", "TEST TRACK  ·  STAGE 1"), 30, Color(1, 1, 1, 0.7))
	root.add_child(title)
	U.place(title, Vector2(0.5, 0), Vector2(0, 8), Vector2(700, 40))
	_cam_l = U.label("", 28, Color(0.6, 0.8, 1.0))
	root.add_child(_cam_l)
	U.place(_cam_l, Vector2(0.5, 0), Vector2(0, 50), Vector2(400, 36))

	# Velocímetro
	var sp := U.panel(U.DARK, 24)
	root.add_child(sp)
	U.place(sp, Vector2(0.5, 1), Vector2(0, 0), Vector2(380, 170))
	_speed_l = U.label("0", 90, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER)
	sp.add_child(_speed_l)
	U.place(_speed_l, Vector2(0.5, 0), Vector2(0, 6), Vector2(360, 100))
	var unit := U.label("km/h", 30, Color(0.7, 0.8, 1.0), HORIZONTAL_ALIGNMENT_CENTER, false)
	sp.add_child(unit)
	U.place(unit, Vector2(0.5, 0), Vector2(0, 100), Vector2(360, 36))
	_gauge = ProgressBar.new()
	_gauge.show_percentage = false
	_gauge.min_value = 0.0
	_gauge.max_value = 1.0
	_gauge.add_theme_stylebox_override("background", U.box(Color(1, 1, 1, 0.12), 8))
	_gauge.add_theme_stylebox_override("fill", U.box(U.RED, 8))
	sp.add_child(_gauge)
	U.place(_gauge, Vector2(0.5, 1), Vector2(0, 14), Vector2(340, 18))
	_update_cam_label()


func _update_cam_label() -> void:
	_cam_l.text = U.t("Câmara: ", "Camera: ") + _cam.mode_name()


func _on_camera() -> void:
	if paused:
		return
	_cam.cycle()
	_update_cam_label()
	Audio.click()


func _process(delta: float) -> void:
	if paused:
		return
	_time += delta
	car.drive = controls.read(delta)
	_time_l.text = U.fmt_time(_time)
	_speed_l.text = str(int(round(car.speed_kmh)))
	var maxkmh: float = float(car.stats["max_ms"]) * 3.6
	_gauge.value = clampf(car.speed_kmh / maxkmh, 0.0, 1.0)
	var ratio: float = clampf(car.speed_kmh / maxkmh, 0.0, 1.0)
	Audio.set_engine(true, ratio, float(car.drive["throttle"]))
	Audio.set_brake(car.slip if car.grounded else 0.0)


# ---------- Pausa ----------
func toggle_pause() -> void:
	paused = not paused
	get_tree().paused = paused
	if paused:
		Audio.set_engine(false, 0.0, 0.0)
		_show_pause()
	elif _pause_panel != null:
		_pause_panel.queue_free()
		_pause_panel = null


func _show_pause() -> void:
	_pause_panel = Control.new()
	_pause_panel.process_mode = Node.PROCESS_MODE_ALWAYS
	var layer := CanvasLayer.new()
	layer.layer = 5
	layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(layer)
	layer.add_child(_pause_panel)
	U.full(_pause_panel)
	# o painel é apagado junto com a sua camada
	_pause_panel.tree_exited.connect(func() -> void: layer.queue_free())
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.7)
	_pause_panel.add_child(dim)
	U.full(dim)
	var p := U.panel(Color(0.05, 0.09, 0.19, 0.98), 30)
	_pause_panel.add_child(p)
	U.place(p, Vector2(0.5, 0.5), Vector2.ZERO, Vector2(700, 640))
	var t := U.label(U.t("PAUSA", "PAUSED"), 64, Color(1, 0.3, 0.3), HORIZONTAL_ALIGNMENT_CENTER)
	p.add_child(t)
	U.place(t, Vector2(0.5, 0), Vector2(0, 24), Vector2(600, 90))
	var b1 := U.button(U.t("CONTINUAR", "RESUME"), U.RED, Vector2(560, 100), 44, toggle_pause)
	p.add_child(b1)
	U.place(b1, Vector2(0.5, 0), Vector2(0, 150), Vector2(560, 100))
	var b2 := U.button(U.t("REINICIAR", "RESTART"), U.BLUE, Vector2(560, 100), 44, _restart)
	p.add_child(b2)
	U.place(b2, Vector2(0.5, 0), Vector2(0, 275), Vector2(560, 100))
	var b3 := U.button(U.t("MENU PRINCIPAL", "MAIN MENU"), U.GRAY, Vector2(560, 100), 44, func() -> void: Game.go_menu())
	p.add_child(b3)
	U.place(b3, Vector2(0.5, 0), Vector2(0, 400), Vector2(560, 100))


func _restart() -> void:
	toggle_pause()
	_time = 0.0
	car.transform = _track.spawn_transform
	car.linear_velocity = Vector3.ZERO
	car.angular_velocity = Vector3.ZERO
	_cam.snap()
