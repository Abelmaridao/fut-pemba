class_name CameraManager
extends Node3D
## CameraManager: câmara do jogo com 3 modos para a corrida + modo livre (menu e garagem).
##  REAR     = traseira, acompanha o carro por trás
##  INTERIOR = vista de dentro do carro
##  TOP      = vista elevada

enum Mode { FREE, REAR, INTERIOR, TOP }

var cam: Camera3D
var mode: int = Mode.FREE
var target: Node3D = null


func _ready() -> void:
	cam = Camera3D.new()
	cam.current = true
	cam.near = 0.1
	cam.far = 800.0
	add_child(cam)


func set_target(t: Node3D) -> void:
	target = t
	snap()


func set_mode(m: int) -> void:
	mode = m
	match m:
		Mode.REAR:
			cam.fov = 70.0
		Mode.INTERIOR:
			cam.fov = 85.0
		Mode.TOP:
			cam.fov = 55.0
		_:
			cam.fov = 60.0
	snap()


## Alterna entre as 3 câmaras: traseira -> interior -> superior.
func cycle() -> void:
	var next: int = Mode.REAR if mode == Mode.FREE else (mode % 3) + 1
	set_mode(next)


func mode_name() -> String:
	match mode:
		Mode.REAR:
			return U.t("TRASEIRA", "REAR")
		Mode.INTERIOR:
			return U.t("INTERIOR", "COCKPIT")
		Mode.TOP:
			return U.t("SUPERIOR", "TOP")
	return ""


func snap() -> void:
	if target != null and mode != Mode.FREE and is_instance_valid(target) and cam != null:
		_update(1.0)


func _process(delta: float) -> void:
	if target != null and is_instance_valid(target) and mode != Mode.FREE:
		_update(1.0 - exp(-7.0 * delta))


func _update(k: float) -> void:
	var tb: Basis = target.global_transform.basis
	var tp: Vector3 = target.global_position
	match mode:
		Mode.REAR:
			var want: Vector3 = tp + tb.z * 7.0 + Vector3.UP * 3.2
			cam.global_position = cam.global_position.lerp(want, k)
			cam.look_at(tp + Vector3.UP * 1.2, Vector3.UP)
		Mode.INTERIOR:
			cam.global_transform = target.global_transform * Transform3D(Basis(), Vector3(0, 1.3, 0.15))
		Mode.TOP:
			var want2: Vector3 = tp + Vector3.UP * 26.0 + tb.z * 7.0
			cam.global_position = cam.global_position.lerp(want2, k)
			cam.look_at(tp, -tb.z)
