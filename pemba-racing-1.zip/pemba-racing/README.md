# PEMBA RACING 🏎️

Jogo de corridas 3D para Android, feito em **Godot 4.3** (GDScript). O APK é gerado automaticamente pelo **GitHub Actions**:
não precisas de instalar o Unity, o Godot nem nada no computador.

## Estado do projecto (por etapas)

| Etapa | O que tem | Estado |
|---|---|---|
| **1** | Estrutura, menu principal 3D, garagem com 10 carros, carro conduzível, 3 câmaras, controlos de telemóvel, áudio, configurações, pista de testes | ✅ **Feita e testada** (45 testes automáticos) |
| 2 | Primeira pista com voltas, linha de chegada, cronómetro, posição | ⏳ próxima |
| 3 | Adversários com inteligência artificial | ⏳ |
| 4 | Multiplayer offline (Wi-Fi / hotspot) até 8 jogadores | ⏳ (no menu aparece como "não implementado") |
| 5 | Campeonato e as 5 pistas | ⏳ (no menu aparece como "não implementado") |
| 6 | Otimização e versão final | ⏳ |

> Nada é simulado: o que ainda não existe diz-se claramente no próprio jogo.

## O que já funciona na Etapa 1
- **Menu** com fundo 3D animado, logótipo, botões animados. JOGAR, GARAGEM, CONFIGURAÇÕES e SAIR funcionam.
- **Garagem**: 10 carros com características diferentes, rodar o carro (arrastar), aproximar/afastar (+ / -), cores, jantes, pintura,
  melhorias de velocidade/aceleração/travagem com moedas, compra e selecção de carros. Tudo fica guardado.
- **Teste de condução** (botão JOGAR): acelerar, travar, marcha-atrás, travão de mão, direção (botões, volante ou inclinação),
  3 câmaras (traseira, interior, superior), velocidade em km/h, indicador de velocidade, cronómetro, pausa.
- **Configurações**: qualidade gráfica (baixa/média/alta), volume da música e dos efeitos, sensibilidade, tipo de controlo, idioma (PT/EN).
- **Áudio** criado por código (motor, travagem, colisão, botões, vitória, música).

## Como pôr no GitHub e gerar o APK (sem Unity)

### Caminho A: pelo telemóvel ou computador, sem instalar nada
1. Cria o repositório em https://github.com/new com o nome `pemba-racing` (marca **Add a README file** para ele começar com o ramo `main`).
2. No repositório: **Add file → Create new file**. No nome escreve `.github/workflows/desempacotar.yml`, cola o conteúdo do ficheiro `desempacotar.yml` e carrega em **Commit changes**.
3. Repete o passo 2 com o nome `.github/workflows/android.yml` e o conteúdo do ficheiro `android.yml`.
4. **Add file → Upload files** e carrega o ficheiro `pemba-racing.zip` (sem o descompactar). Carrega em **Commit changes**.
5. Vai ao separador **Actions**. O fluxo **Desempacotar projeto** corre sozinho e põe todos os ficheiros no repositório (1 minuto).
6. Depois vai a **Actions → Gerar APK Android → Run workflow**. Espera uns 5 a 10 minutos.
7. Abre a execução concluída e, em **Artifacts**, descarrega **PembaRacing-APK**. Descompacta e instala o `PembaRacing.apk` no telemóvel
   (permite "instalar apps desconhecidas" quando o Android pedir).

### Caminho B: no computador (arrastar e largar)
Descompacta o zip, cria o repositório, carrega todos os ficheiros (inclui a pasta `.github`) e corre **Actions → Gerar APK Android**.

## Controlos
- **Telemóvel:** botões no ecrã (multi-toque: acelerar + virar ao mesmo tempo). Em Configurações escolhes direção por botões, volante virtual ou inclinação (experimental).
- **Computador (para testar):** W/S ou setas = acelerar/travar e marcha-atrás, A/D = direção, Espaço = travão de mão, C = câmara, P ou Esc = pausa.

## Testes automáticos
O projecto tem um teste que abre o menu, a garagem (compra, personalização, melhorias), conduz o carro (acelerar, virar, travar,
marcha-atrás, travão de mão), alterna as câmaras e a pausa. Corre sozinho no GitHub (job **Testes automáticos**) e, se tiveres o Godot 4.3:

```
godot --headless --path . --fixed-fps 60 -- --selftest
```

## Arquitectura (14 sistemas independentes)
`scripts/managers/`: MainMenuManager, GameManager, MultiplayerManager (Etapa 4), NetworkManager (Etapa 4), CarSelectionManager,
RaceManager, TrackManager, CameraManager, AIController (Etapa 3), GarageManager, AudioManager, SettingsManager, ChampionshipManager (Etapa 5).
`scripts/cars/`: CarController (física), ProceduralCar (modelo 3D por código). `scripts/data/CarData.gd`: os 10 carros (para adicionar um carro, acrescenta uma linha).
`scripts/ui/MobileControls.gd`: controlos de toque. `tests/`: teste automático.

## Limitações conhecidas
- Os carros e o cenário são **recursos provisórios** feitos por código (caixas e cilindros). A arquitectura permite trocar por modelos do Blender mais tarde (ficheiros `.glb`).
- O jogo foi testado no Godot em modo sem ecrã e com capturas de ecrã por software. **Ainda não foi testado num telemóvel real**: o primeiro APK serve para isso.
- O modo de direção por inclinação é experimental.
